# Ayeryhoy: calibración diaria de COCOTAXI 2.3.1

## Qué cambió con tu aclaración

Frank confirma que una oferta de 200 pasa como 200 al historial, aunque el total diario no coincide con la suma. Por tanto usamos **oferta ≈ importe del historial** como supuesto explícito y calibramos contra **Total ganancias − propinas**. No se exige conocer el neto final de cada viaje.

Se revisaron las fotografías del historial y de los totales del 17 y 18. La simulación trata cada fila positiva como un viaje aceptado; los ceros no generan ingresos. Se transcribieron 59 filas, 51 positivas. No se inventaron tiempos ni se aseguró que esos viajes superarían realmente el filtro por hora.

## Entrenamiento disponible: 17/09/2026

- 46 registros visibles, 42 positivos y cuatro a cero.
- Importe total de referencia: **11.061,89 UYU**.
- Total ganancias: **11.010 UYU**; propinas: **60 UYU**.
- Objetivo a estimar: **10.950 UYU**.
- Factor exacto ajustado: `10950 / 11061.89 = 0,989885091968913…`.
- Factor inicial instalado, redondeado: **0,99**.

Se aplicó cada factor a cada importe y se redondeó cada pago a centavos antes de sumar:

| Factor | Suma estimada sin propina | Diferencia frente a 10.950 |
|---|---:|---:|
| 0.80 | 8849.51 | -2100.49 |
| 0.90 | 9955.74 | -994.26 |
| 0.95 | 10508.80 | -441.20 |
| 0.98 | 10840.68 | -109.32 |
| 0.99 | 10951.30 | 1.30 |
| 1 | 11061.89 | 111.89 |

**Con 0,99 da 10.951,30: diferencia de +1,30 UYU (aprox. 0,012%).** Multiplicar la suma de golpe daría 10.951,27; la diferencia de tres centavos procede del redondeo individual. Con el factor exacto da 10.950,00; esa coincidencia es esperable porque se obtuvo del mismo cierre.

Esto es un **ajuste con un día agregado**, no 42 observaciones independientes de pago neto ni una prueba de precisión futura. Tampoco prueba que Cabify cobre una comisión del 1%: el factor resume descuentos y devoluciones juntos. Por ello se instala como estimación inicial, no como comisión universal.

## Aplicación uno por uno: 18/09, comparación del período visible

Hay 13 filas enteras, nueve positivas, que suman 2.471,59. Aplicando el factor inicial sin volver a ajustarlo, suman **2.446,88**, frente a **2.833** en el resumen. Diferencia descriptiva: −386,12. La siguiente fila está cortada, pero eso no prueba que falte un viaje: podría estar en la otra imagen. No se atribuye automáticamente la diferencia a viajes faltantes. **Si estas capturas contienen todo el historial hasta ese momento, 0,99 subestima hoy en 386,12 (13,63%) y falla esta comprobación.** El factor implícito de hoy sería 2833/2471,59 = 1,146225709. No es consistente con el 0,989885 del 17.

Falta verificar la integridad y correspondencia de un segundo período para medir un error fuera del entrenamiento con certeza. El 18 ya aporta una contradicción visible al uso universal de 0,99. Los resúmenes del 10 al 16 no incluyen sus historiales completos, así que no permiten calcular otro factor oferta→pago.

## Por qué no forzar una sola fórmula con ambos totales

El 17 implica 0,989885 y el 18 visible implica 1,146226. No hay un solo multiplicador que haga coincidir ambos. Ajustar un modelo complejo con solo dos totales podría hacerlos encajar, pero no demostraría que predice el siguiente viaje. Por eso 0,99 permanece como referencia provisional del 17, y el aprendizaje diario sirve para actualizarla con registros completos; no se declara que ya está acertada para hoy.

El total de hoy se descompone en base 2.468, extras 152 y Stars 212: 2.832 por componentes redondeados, frente a 2.833 mostrado. La suma del historial (2.471,59) está cerca de la base, pero esa cercanía no demuestra que ambos conceptos sean iguales: ayer base/historial es muy diferente. Hace falta comprobar el desglose de viajes o cierres adicionales; no sumar extras y Stars dos veces.

## Comisión reducida y devoluciones

El 17 muestra precio base 9.459, extras 665, Stars 825 y propinas 60. Los componentes redondeados suman 11.009 y el total mostrado es 11.010. Stars está incluido en el total: **no se suma nuevamente al estimado**.

En los resúmenes del 10 al 16, Stars/(base+extras) es 0,08167781356 agregado. Usándolo con base y extras ya liquidados se obtienen 10.950,91 el 17 y 2.834 el 18. Es una comprobación contable condicional; aplicarlo directamente a las ofertas volvería a mezclar bases. Con un único cierre emparejado no se pueden identificar por separado todas las comisiones y devoluciones.

## Fórmula instalada

```
Pago estimado del viaje = redondear_centavos(importe ofertado × k)
Ingreso neto/h del ciclo = 60 × (pago estimado − costes) / (recogida + trayecto + esperas)
Promedio de sesión estimado = 60 × acumulado de viajes finalizados / minutos conectados
```

Inicialmente `k=0,99`. Una oferta de 200 se estima en **198**; con un ciclo de 12 minutos y costes cero serían **990/h**. El promedio de sesión incluye el tiempo conectado sin viaje.

Tras registrar cierres completos verificados de los últimos 28 días:

```
k = Σ(total ganancias − propinas − bonos extraordinarios − reembolsos) / Σ(importes del historial de esos mismos días)
```

Se usa un cociente de sumas, no el promedio simple de porcentajes de días grandes y pequeños. Los descuentos y las devoluciones ordinarias como Stars quedan dentro del total comparable. Los bonos extraordinarios se excluyen para no anticipar condiciones aún incumplidas; si se cobran, se registran aparte y una sola vez. Los gastos del vehículo se restan después: no forman parte de lo pagado por Cabify.

La app empieza con la estimación provisional y la sustituye al haber cierres elegibles. Para entrenar exige fecha anterior a hoy y confirmación explícita de historial completo, mismo período y equivalencia con ofertas. Los cierres parciales se guardan sin entrenar. Corregir un cierre lo reemplaza, y quitar la marca lo retira del aprendizaje. Guardar un cierre no añade dinero otra vez al historial de la sesión ni transforma asignaciones estimadas en cobros individuales verificados.

## Archivos reproducibles

- `viaje_por_viaje.csv`: 59 filas, oferta asumida, pago estimado, acumulado por día, contraste con factor exacto y tiempos máximos condicionales según objetivo/demanda.
- `comparacion_formulas.csv`: todas las alternativas y sus sumas.
- `results.json`: cifras y advertencias de validez.
- `ayeryhoy_data.json`: transcripción y archivo fuente.
- `simulate.py`: repetir con `python validation/simulate.py --target 700`.

El factor actual se ajustó al período fotografiado del 17, tratado como completo con las capturas disponibles. Una omisión, pago tardío, cambio de Stars o diferencia entre oferta e historial puede cambiar el factor. La app muestra que es una estimación; no hay todavía intervalo de confianza justificable con un solo cierre.
