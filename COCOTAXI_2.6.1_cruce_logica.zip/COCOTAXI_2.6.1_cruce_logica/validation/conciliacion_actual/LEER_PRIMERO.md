# Cruce de facturaciones COCOTAXI — conclusión corregida

## Resultado principal

El 18 de septiembre, hasta la captura de las 06:55, nueve filas positivas del historial suman $2.471,59. El último viaje del 17, a las 23:48, es de $361,91. Al atribuir ese viaje al acumulado del 18, la suma es $2.833,50, frente a $2.833 mostrados por Cabify. No aparece partida de propinas ni incentivo en ese resumen.

No hace falta multiplicar los importes por 1,146 ni por 1,11 para explicar la diferencia. Esos factores absorberían un viaje de otro día. El patrón encaja con que el historial use la fecha de inicio/solicitud y las ganancias la fecha de finalización/liquidación. Es una inferencia respaldada por varias coincidencias independientes: las fotos NO muestran las horas de fin y por tanto no prueban formalmente esa regla.

## Comprobación en otros períodos

| Período | Historial de la fecha | Viaje del día anterior incorporado | Propinas retiradas | Premio separado | Reconstrucción sin propinas | Ganancias sin propinas |
|---|---:|---:|---:|---:|---:|---:|
| 27 junio, mañana | 5.728,58 | 272,82 (26/06 23:47) | 0 | 1.200 | 7.201,40 | 7.201 |
| 28 junio, mañana | 4.198,18 | 266,06 (27/06 23:45) | 75 | 0 | 4.389,24 | 4.389 |
| 2 julio, mañana | 2.045,33 | 270,36 (01/07 23:52) | 45 | 0 | 2.270,69 | 2.270 |
| 18 septiembre, mañana | 2.471,59 | 361,91 (17/09 23:48) | 0 | 0 | 2.833,50 | 2.833 |

Las diferencias son menores a $1 frente a una pantalla que muestra importes enteros. No se ha demostrado si Cabify trunca o usa otra regla de visualización; no se presume redondeo convencional.

Otra comprobación: 30 de junio, historial visible $3.046,84 menos el último viaje de las 23:47 ($294,97) = $2.751,87, frente a $2.751. Encaja con que ese último viaje se liquide al día siguiente; no se dispone de su hora de finalización.

En el tramo del 1 de julio de 06:58 a 19:11, los viajes visibles suman $6.098,98 y la diferencia entre acumulados es $6.099, manteniéndose las propinas en $30 en ambos cortes. No se necesita otro multiplicador.
En el tramo del 2 de julio de 06:58 a 19:40, el historial suma $5.065,67 y las ganancias crecen $5.066. Las propinas crecen $60: al excluirlas de ambos lados quedan $5.005,67 y $5.006. Esta coincidencia indica que no se deben descontar propinas de un solo lado si el historial ya las contiene.

## Viaje a viaje del 18 con factor 1,00

| Registro | Importe | Acumulado reconstruido |
|---|---:|---:|
| 17/09 23:48 — candidato a liquidarse el 18 | 361,91 | 361,91 |
| 18/09 00:17 | 235,92 | 597,83 |
| 18/09 00:27 | 297,51 | 895,34 |
| 18/09 01:01 | 441,07 | 1.336,41 |
| 18/09 02:54 | 173,47 | 1.509,88 |
| 18/09 03:12 | 275,04 | 1.784,92 |
| 18/09 04:28 | 186,08 | 1.971,00 |
| 18/09 04:49 | 282,25 | 2.253,25 |
| 18/09 05:06 | 249,92 | 2.503,17 |
| 18/09 05:44 | 330,33 | 2.833,50 |

Cuatro filas con $0 (00:11, 00:22, 01:32, 05:05) no suman. La diferencia es $0,50, aproximadamente 0,018% del total mostrado. Es una conciliación retrospectiva de importes, NO una prueba de precisión futura de 99,982%. No se pueden simular recomendaciones aceptar/rechazar reales sin los tiempos y las ofertas originales; se supone que se realizaron todos los viajes con importe positivo.

## Correcciones respecto del análisis anterior

- El factor 0,99 se obtuvo mezclando importes por fecha sin resolver los viajes que cruzan medianoche. No está justificado como descuento de Cabify.
- El candidato 1,11, encontrado al separar madrugadas, también queda descartado como explicación del desajuste: absorbía el viaje anterior en el coeficiente.
- factu2 no contenía una foto intermedia. Carpeta 2/20260628_073623.jpg aporta ocho filas por $1.942,45. La suma del 28 es $4.198,18. Los viajes marcados Ayer no se suman todos al total del 28; solo se estudia la posible transferencia del último viaje.
- En factu3, $6.657,79 mezclaba 19 viajes del 27 ($5.728,58) con cuatro del 26 ($929,21). Para reconstruir el acumulado de la mañana del 27 basta el último del 26 ($272,82) y añadir el premio separado de $1.200: $7.201,40.
- El 27/06 también aparece posteriormente con $9.275. No sustituye al acumulado temprano de $7.201 para comparar un historial fotografiado hasta las 07:48.
- Los rótulos ESTA SEMANA/ANTERIORES no permiten deducir por sí solos la fecha: se usan fechas de resúmenes y fotos originales. No se consideran los nombres de reenvíos de WhatsApp fechas del viaje.
- fac.zip y factu2/factu3 repiten capturas; facturacion.zip repite resúmenes de septiembre. No son jornadas independientes.

## Qué sigue sin estar completamente cerrado

El historial entero del 17/09 suma $11.061,89 y el total mostrado es $11.010, con $60 de propinas. Si se retira el viaje de $361,91 del final del día, falta conocer el último viaje del 16/09. Un ingreso trasladado de alrededor de $310 sería compatible con el acumulado temprano de $3.167 y con el cierre. No se ha encontrado la fila correspondiente del 16; ese importe es una inferencia, NO un viaje observado ni dato de entrenamiento.

Otras fotos contienen saldos semanales/mensuales, pagos emitidos, historial parcial, promociones o pantallas sin desglose de propinas. Se revisaron pero no se forzó un factor con períodos no reconciliables. El cotejo se refiere a Total ganancias, no a una auditoría del depósito bancario.

## Aplicación a Coco

Dado que Frank indica que la oferta coincide con el historial, el punto inicial mejor respaldado es **pago estimado = oferta × 1,00**, sin propina futura y sin volver a restar una comisión ni sumar Stars. Esto no demuestra que la oferta original siempre sea idéntica al importe final: no hay parejas completas de oferta inicial y detalle final para todos los viajes.

Coco debe registrar por separado fecha de aceptación y de finalización, mantener una sola entrada por viaje y conservar la sesión al pasar medianoche. Para el promedio de sesión, contar viajes finalizados e incluir espera. Para conciliar un día de Cabify, atribuir los viajes según el criterio de liquidación confirmado, sin duplicarlos entre días.

La fórmula de conciliación propuesta es:
 ganancias sin propinas = historial atribuido correctamente − propinas incluidas en ese historial + premios no incluidos + ajustes documentados.

Solo se aprende un factor residual después de conciliar esos componentes. Una diferencia diaria sin conciliar no debe cambiar automáticamente el factor de pago ni convertirse en un supuesto suplemento nocturno. Las fotos no prueban que Cabify pague un porcentaje adicional simplemente por ser de noche.

Este informe no modifica el ZIP 2.4.0 ni compila una APK. Corrige el análisis económico que debe guiar la próxima modificación.

## Fuentes verificables

- Ayeryhoy/20260918_065653.jpg y 065706.jpg: nueve importes positivos del 18.
- Ayeryhoy/20260918_065808.jpg: 17/09 23:48 $361,91.
- Ayeryhoy/20260918_065536.jpg: 18/09 Total ganancias $2.833.
- factu3/WhatsApp Image 2026-09-17 at 8.57.21 AM (1).jpeg: último viaje del 26, 23:47 $272,82; resto del historial en las otras capturas de factu3.
- Carpeta 1/20260627_081227.jpg: 27/06 total $7.201 y premio $1.200.
- Carpeta 2/20260628_073623.jpg: ocho filas adicionales del 28; 073614.jpg: último viaje del 27, 23:45 $266,06.
- Carpeta 1/20260628_073420.jpg: 28/06 total $4.464 y propinas $75.
- Carpeta 1/20260702_070225.jpg: último viaje del 1/07, 23:52 $270,36.
- Carpeta 2/20260702_194114.jpg: ocho filas del 2/07 hasta 06:38.
- Carpeta 1/20260702_065808.jpg: 2/07 total $2.315 y propinas $45.

Reproducción: ejecutar `python calcular.py` y luego `python conciliar.py`. `resultados.json` conserva el análisis inicial de factores SIN conciliación para mostrar por qué falla; **la conclusión vigente está en este documento y conciliacion_final.json**. No entrenar Coco con los factores exploratorios de resultados.json.
