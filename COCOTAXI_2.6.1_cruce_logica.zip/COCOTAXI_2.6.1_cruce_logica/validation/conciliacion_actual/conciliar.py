from decimal import Decimal as D
from pathlib import Path
import json
p=Path(__file__).resolve().parent
raw=json.loads((p/'resultados.json').read_text())
# Observed prior-day last trips. Assignment to settlement day is a hypothesis,
# supported by independent reconciliations; finish timestamps are not available.
cases=[('27 junio mañana','5728.58','272.82','0','0','1200','7201','26 junio 23:47'),('28 junio mañana','4198.18','266.06','0','75','0','4464','27 junio 23:45'),('2 julio mañana','2045.33','270.36','0','45','0','2315','1 julio 23:52'),('18 septiembre hasta 06:55','2471.59','361.91','0','0','0','2833','17 septiembre 23:48'),('30 junio tarde/noche','3046.84','0','294.97','0','0','2751','sale: 30 junio 23:47')]
out=[]
for name,h,inc,exc,tips,bonus,total,boundary in cases:
 h,inc,exc,tips,bonus,total=map(D,(h,inc,exc,tips,bonus,total))
 estimate=h+inc-exc-tips+bonus
 actual=total-tips
 assert abs(estimate-actual)<1
 out.append(dict(period=name,history=str(h),incoming=str(inc),outgoing=str(exc),tips=str(tips),bonus=str(bonus),estimate_no_tips=str(estimate),actual_no_tips=str(actual),difference=str(estimate-actual),boundary_trip=boundary))
cum=D('361.91');ledger=[dict(time='17/09 23:48 (atribuido al 18 como hipótesis)',amount='361.91',cumulative=str(cum))]
for t,a in raw['holdout_rows']:
 a=D(a)
 if a:
  cum+=a;ledger.append(dict(time='18/09 '+t,amount=str(a),cumulative=str(cum)))
assert cum==D('2833.50')
(p/'conciliacion_final.json').write_text(json.dumps(dict(factor_history=1,interpretation='Hipótesis de diferente fecha de registro y liquidación; no horas de fin observadas',cases=out,ledger18=ledger),indent=2,ensure_ascii=False))
print(json.dumps(out,ensure_ascii=False,indent=2));print('18 septiembre:',cum,'vs 2833; diferencia',cum-D(2833))
