import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.JavacTask;
public class ParseJava {
 public static void main(String[] args) throws Exception {
  JavaCompiler c=ToolProvider.getSystemJavaCompiler();
  DiagnosticCollector<JavaFileObject> d=new DiagnosticCollector<>();
  try(StandardJavaFileManager f=c.getStandardFileManager(d,null,null)) {
   List<java.io.File> files=new ArrayList<>();
   try(var paths=Files.walk(Path.of(args[0]))) {paths.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toFile()));}
   JavacTask task=(JavacTask)c.getTask(null,f,d,List.of("-proc:none"),null,f.getJavaFileObjectsFromFiles(files));
   task.parse();
   for(var problem:d.getDiagnostics()) System.out.println(problem);
   if(d.getDiagnostics().stream().anyMatch(x->x.getKind()==Diagnostic.Kind.ERROR))System.exit(1);
   System.out.println("Syntax OK: "+files.size()+" Java files (not Android type checking)");
  }
 }
}
