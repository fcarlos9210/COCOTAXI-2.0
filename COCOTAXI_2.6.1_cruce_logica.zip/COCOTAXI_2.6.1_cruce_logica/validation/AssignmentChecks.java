package com.cocotaxi.app;
public final class AssignmentChecks {
  public static void main(String[] args) {
    String assigned = "CABIFY Ir a origen Avenida Ingeniero, 1595 Montevideo Navegar Ver ruta Cata Viajes realizados 19 Valoración 100%";
    if (!AssignmentSignals.isAssigned(assigned)) throw new AssertionError("pickup screen");
    for (String text : new String[] {"Navegar Ver ruta", "Ir a origen", "Aceptar " + assigned,
        "Historial " + assigned, "Viaje cancelado " + assigned, "Otro conductor " + assigned,
        "No se pudo aceptar " + assigned, ""})
      if (AssignmentSignals.isAssigned(text)) throw new AssertionError(text);
    System.out.println("PASS: 9 assignment signal checks");
  }
}
