#!/usr/bin/env python3
"""Aggregate payout calibration: assume each positive recorded fare was accepted.
History equals offered fare by Frank's explicit clarification; this is not a duration test.
"""
import argparse,csv,decimal,json,pathlib
D=decimal.Decimal
ROOT=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--target',default='700');args=p.parse_args();target=D(args.target)
if not target.is_finite() or target<=0:raise SystemExit('El objetivo debe ser positivo')
q=lambda n:n.quantize(D('.01'),rounding=decimal.ROUND_HALF_UP)
data=json.loads((ROOT/'ayeryhoy_data.json').read_text(),parse_float=D)
rows=sorted([dict(date=s['day'],time=t,history=D(a),source=f) for f,s in data['screens'].items() for t,a in s['rows']],key=lambda r:(r['date'],r['time']))
train=[r for r in rows if r['date']=='2026-09-17'];hist=sum(r['history'] for r in train)
day17=next(x for x in data['daily'] if x['date']=='2026-09-17');actual=D(day17['total']-day17['tips']-day17['bonus'])
exact=actual/hist;initial=q(exact) # 0.99: calibrated on one aggregate day, not guaranteed for future days.
candidates=[D('.80'),D('.90'),D('.95'),D('.98'),initial,D('1'),exact]
summary=[]
for date in ['2026-09-17','2026-09-18']:
 rs=[r for r in rows if r['date']==date];daily=next(x for x in data['daily'] if x['date']==date);paid=D(daily['total']-daily['tips'])
 for k in candidates:
  pred=sum(q(r['history']*k) for r in rs)+D(daily['bonus'])
  summary.append(dict(date=date,factor=str(k),history=str(sum(r['history'] for r in rs)),prediction=str(pred),actual_without_tips=str(paid),difference=str(pred-paid),error_percent=str(q((pred-paid)/paid*100)),valid_independent_test=False,qualification='Ajustado con este mismo día; error de ajuste, no prueba futura' if date.endswith('17') else 'Cobertura del historial no confirmada: si está completo, el factor falla por esta diferencia; no atribuirla automáticamente a viajes faltantes'))
with (ROOT/'viaje_por_viaje.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['fecha','hora','oferta_asumida_igual_historial','estado_simulado','factor_inicial','estimado_sin_propina','acumulado_estimado_dia','estimado_factor_exacto_ajuste','max_minutos_demanda_media_objetivo_'+str(target),'max_minutos_demanda_baja','max_minutos_demanda_muerta','max_minutos_demanda_alta','fuente'])
 accum={}
 for r in rows:
  est=q(r['history']*initial);accum[r['date']]=accum.get(r['date'],D(0))+est
  w.writerow([r['date'],r['time'],r['history'],'ACEPTADO HIPOTETICAMENTE' if r['history']>0 else 'CERO: NO GENERA INGRESO',initial,est,accum[r['date']],q(r['history']*exact),*[q(est*60/(target*m)) for m in [D(1),D('.9'),D('.75'),D('1.15')]],r['source']])
with (ROOT/'comparacion_formulas.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
prior=[x for x in data['daily'] if x['date']<'2026-09-17'];stars=sum(D(x['stars']) for x in prior)/sum(D(x['base']+x['extras']) for x in prior)
checks=[dict(date=x['date'],conditional_prediction=str(q(D(x['base']+x['extras'])*(1+stars)+D(x['bonus']))),actual_without_tips=str(x['total']-x['tips']),qualification='Usa base y extras ya liquidados; no es pronóstico de oferta') for x in data['daily'] if x['date']>='2026-09-17']
report=dict(assumption='Según Frank, importe ofrecido = importe del historial. Se simula aceptar cada fila positiva.',initial_factor=str(initial),exact_in_sample_factor=str(exact),training_days=1,training_positive_rows=sum(r['history']>0 for r in train),rows=len(rows),comparison=summary,stars_conditional_rate=str(stars),conditional_checks=checks,independent_complete_days=0,warning='0.99 es inicial y provisional. No está confirmada la cobertura del historial del 18; 0.99 no reproduce su total visible. No se pueden identificar por separado comisión y devoluciones ni medir error por viaje con un total diario.')
(ROOT/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
assert len(train)==46 and hist==D('11061.89') and actual==D('10950') and initial==D('.99')
print(json.dumps({k:v for k,v in report.items() if k not in ['comparison','conditional_checks']},indent=2,ensure_ascii=False))
print(json.dumps([x for x in summary if x['factor'] in ['0.99','1']],indent=2,ensure_ascii=False))
