"""Offline checks of actual Java formula classes. Android persistence/UI are not emulated."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/cocotaxi/app'
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);pkg=p/'com/cocotaxi/app';pkg.mkdir(parents=True);android=p/'android/content';android.mkdir(parents=True)
 for name in ['SettingsStore','DecisionEngine','OfferRanking','Offer','Money','PromotionMath','OfferParser','DemandModel','AssignmentSignals']:
  (pkg/(name+'.java')).write_text((source/(name+'.java')).read_text())
 (android/'Context.java').write_text('package android.content; public abstract class Context { public static final int MODE_PRIVATE=0; public abstract SharedPreferences getSharedPreferences(String s,int n); }')
 (android/'SharedPreferences.java').write_text('''package android.content; public interface SharedPreferences {
 boolean getBoolean(String k,boolean d); long getLong(String k,long d); int getInt(String k,int d); Editor edit();
 interface Editor { Editor putBoolean(String k,boolean v); Editor putLong(String k,long v); Editor putInt(String k,int v); void apply(); }
 }''')
 # Reuse real nested value classes, without the Android database implementations.
 src=(source/'CocoStore.java').read_text(); (pkg/'CocoStore.java').write_text('package com.cocotaxi.app; public class CocoStore { public static final java.time.ZoneId ZONE = java.time.ZoneId.of("America/Montevideo");\n'+src[src.index('  public static class Totals'):])
 src=(source/'PromotionStore.java').read_text(); (pkg/'PromotionStore.java').write_text('package com.cocotaxi.app; public class PromotionStore {\n'+src[src.index('  public static class Snapshot'):])
 (pkg/'CoreChecks.java').write_text((root/'validation/CoreChecks.java').read_text())
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-d',str(p/'classes'),*[str(x) for x in p.rglob('*.java')]],check=True)
 subprocess.run(['java','-cp',str(p/'classes'),'com.cocotaxi.app.CoreChecks'],check=True)
 (pkg/'AssignmentChecks.java').write_text((root/'validation/AssignmentChecks.java').read_text())
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp',str(p/'classes'),'-d',str(p/'classes'),str(pkg/'AssignmentChecks.java')],check=True)
 subprocess.run(['java','-cp',str(p/'classes'),'com.cocotaxi.app.AssignmentChecks'],check=True)
