package com.cocotaxi.app;
import java.util.*;
public class CoreChecks {
 static int count;
 static void check(boolean v,String name) {if(!v)throw new AssertionError(name); count++;System.out.println("PASS "+name);}
 static boolean near(double a,double b) {return Math.abs(a-b)<.001;}
 static Offer offer(double fare,double minutes) {Offer o=new Offer();o.fare=fare;o.pickupMin=2;o.tripMin=minutes-2;o.hasOfferSignal=true;return o;}
 public static void main(String[] args) {
  SettingsStore.Values v=new SettingsStore.Values();
  int dow=Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
  int today=dow==Calendar.SUNDAY?6:dow-Calendar.MONDAY;
  int excluded=(today+1)%7; // keep exactly six workdays, but never exclude the day the test runs
  v.workDaysMask=0x7F & ~(1<<excluded);
  for(int i=0;i<7;i++)v.workDayHours[i]=(v.workDaysMask&(1<<i))!=0?11:0;
  v.targetHoursDay=11;v.dailyGoal=5500;v.goalMode=1;
  SettingsStore.normalizeGoals(v);
  check(near(v.realGoalHour,500)&&near(v.weeklyGoal,33000),"daily 5500 / 11 h = 500 hourly; 33000 weekly");
  v.goalMode=0;v.weeklyGoal=39600;SettingsStore.normalizeGoals(v);
  check(near(v.dailyGoal,6600)&&near(v.realGoalHour,600),"weekly 39600 / 6 days / 11 hours");
  v.goalMode=2;v.realGoalHour=700;SettingsStore.normalizeGoals(v);
  check(near(v.dailyGoal,7700)&&near(v.weeklyGoal,46200),"hourly source derives other goals");
  for(int i=0;i<7;i++)if((v.workDaysMask&(1<<i))!=0)v.workDayHours[i]=10;v.targetHoursDay=10;SettingsStore.normalizeGoals(v);
  check(near(v.realGoalHour,700)&&near(v.dailyGoal,7000),"hourly stays fixed on duration change");
  v.goalMode=1;v.dailyGoal=5500;v.targetHoursDay=11;SettingsStore.normalizeGoals(v);
  check(near(PromotionMath.requiredHourly(5500,11,300,2000),583.333333),"recover daily target in remaining six hours");
  check(near(PromotionMath.requiredHourly(5500,11,660,2000),0),"no division by zero after planned shift");
  check(!PromotionMath.plan(8,1100,60,10,15,40,500).feasible,"five of thirteen at 02:00, end 03:00: no promo credit");
  check(!PromotionMath.plan(1,1100,5,6,15,40,500).feasible,"trip exceeds deadline including margin");
  check(!PromotionMath.plan(0,1100,60,10,15,40,500).feasible,"already achieved reward cannot justify more trips");
  check(!PromotionMath.plan(8,1100,Double.NaN,10,15,40,500).feasible,"invalid time rejected");
  PromotionMath.Plan plan=PromotionMath.plan(13,1100,240,10,15,40,500);
  check(plan.feasible&&plan.credit>0&&plan.credit<1100/13.0,"short trip conditional reward covers goal conservatively");
  check(!PromotionMath.plan(13,1100,240,40,15,40,500).feasible,"long low-income trip does not meet goal with reward");
  CocoStore.Session s=new CocoStore.Session();s.active=true;s.minutes=10;s.money=80;
  v.payoutMode=1;v.factor=1;v.recovery=false;
  PromotionStore.Snapshot promo=new PromotionStore.Snapshot();promo.target=13;promo.bonus=1100;promo.start=0;promo.now=1000;promo.end=1000+240*60000L;
  DecisionEngine.Result ordinary=DecisionEngine.evaluate(offer(40,10),v,s,2,null);
  DecisionEngine.Result promoted=DecisionEngine.evaluate(offer(40,10),v,s,2,null,promo);
  check(!ordinary.accept&&promoted.accept&&promoted.promoFeasible,"promotion integrated in actual decision engine");
  check(near(promoted.payout,40)&&near(promoted.net,40)&&near(s.money,80),"conditional bonus never changes trip payout or ledger");
  promo.completed=5;promo.end=promo.now+60*60000L;
  DecisionEngine.Result impossible=DecisionEngine.evaluate(offer(40,10),v,s,2,null,promo);
  check(!impossible.accept&&near(impossible.promoCredit,0),"impossible promotion falls back to normal filter");
  check(DecisionEngine.evaluate(offer(200,10),v,s,2,null,promo).accept,"profitable ordinary trip accepted despite impossible promo");
  promo.start=promo.now+1000;
  check(!DecisionEngine.evaluate(offer(40,10),v,s,2,null,promo).accept,"future promo inactive");
  promo.start=0;promo.end=promo.now;
  check(!DecisionEngine.evaluate(offer(40,10),v,s,2,null,promo).accept,"expired promo inactive");
  promo.end=promo.now+240*60000L;promo.completed=promo.target;
  check(!DecisionEngine.evaluate(offer(40,10),v,s,2,null,promo).accept,"completed promo inactive");
  promo.completed=0;s.minutes=659;
  check(!DecisionEngine.evaluate(offer(40,10),v,s,2,null,promo).accept,"promo cannot assume work after planned shift");
  s.minutes=10;s.paused=true;
  check(!DecisionEngine.evaluate(offer(200,10),v,s,2,null,promo).accept,"paused session rejects");
  s.paused=false;v.payoutMode=0;
  check(!DecisionEngine.evaluate(offer(200,10),v,s,2,null,promo).accept,"promo cannot bypass missing payout model");
  v.payoutMode=1;
  DecisionEngine.Result best=OfferRanking.best(Arrays.asList(ordinary,promoted));
  check(best==promoted,"visible offers ranked with conditional promotion score");
  DecisionEngine.Result low=DecisionEngine.evaluate(offer(100,10),v,s,1,null);
  DecisionEngine.Result high=DecisionEngine.evaluate(offer(100,10),v,s,3,null);
  check(low.accept&&!high.accept,"demand relaxes or tightens ordinary threshold");
  v.goalMode=1;v.dailyGoal=5500;for(int i=0;i<7;i++)if((v.workDaysMask&(1<<i))!=0)v.workDayHours[i]=11;SettingsStore.normalizeGoals(v);
  v.recovery=true;s.minutes=300;s.money=2000;
  check(near(DecisionEngine.evaluate(offer(200,10),v,s,2,null).threshold,583.333333),"actual remaining daily pace informs recovery filter");
  s.minutes=10;s.money=0;v.recovery=false;v.waitPassenger=0;v.waitNext=120;
  DecisionEngine.Result afterWait=DecisionEngine.evaluate(offer(180,15),v,s,2,null);
  check(afterWait.accept&&near(afterWait.minutes,15)&&near(afterWait.hourly,720),
      "180 / 15 min accepted after ten idle minutes; legacy future wait ignored");
  check(near(afterWait.projected,432),"real ten minute idle time remains in session projection");
  s.minutes=0;v.waitNext=0;
  DecisionEngine.Result atStart=DecisionEngine.evaluate(offer(180,15),v,s,2,null);
  check(atStart.accept==afterWait.accept&&near(atStart.hourly,afterWait.hourly),
      "initial idle time does not change standalone trip performance");
  check(!DecisionEngine.evaluate(offer(180,60),v,s,2,null).accept,
      "180 peso fare alone does not justify a sixty minute trip");
  v.waitPassenger=2;v.waitNext=99;
  check(near(DecisionEngine.evaluate(offer(180,15),v,s,2,null).minutes,17),
      "passenger wait remains separate from removed next-offer wait");
  Offer parsed=OfferParser.parse("Para ti\n$337\n3 min 1.2 km\n7 min 4.5 km\nAceptar","com.cabify.driver");
  check(parsed.hasEnoughForDecision()&&near(parsed.fare,337)&&near(parsed.pickupMin,3)&&near(parsed.tripMin,7),
      "parser keeps single Cabify offer fast path exact");
  check(OfferParser.isHistoryScreen("Comisión reducida · Total a cobrar"),
      "accent normalization still blocks history screens");
  check(OfferParser.parseVisible("Para ti\n$200\n2 min 1 km\n8 min 4 km\nAceptar\nPara ti\n$300\n3 min 2 km\n9 min 5 km\nAceptar").size()==2,
      "visible-card parser does not merge two offers");
  System.out.println("TOTAL: "+count+" checks passed; no Android UI/database/build verification.");
 }
}
