"""State-transition checks for COCOTAXI 2.6.1 dashboard ledger and clocks."""
import sqlite3

SQL = """
SELECT COALESCE(SUM(COALESCE(actual,estimate)-cost),0),
       COALESCE(SUM(CASE WHEN status='ASIGNADO' THEN estimate-cost ELSE 0 END),0),
       COALESCE(SUM(CASE WHEN status='FINALIZADO' THEN COALESCE(actual,estimate)-cost ELSE 0 END),0),
       COALESCE(SUM(trip),0),
       COALESCE(SUM(minutes),0),
       COALESCE(SUM(CASE WHEN status='ASIGNADO' THEN 1 ELSE 0 END),0)
FROM trips
WHERE deleted=0 AND status IN ('ASIGNADO','FINALIZADO')
"""

def totals(db):
    return db.execute(SQL).fetchone()

db=sqlite3.connect(':memory:')
db.execute('CREATE TABLE trips(status TEXT, estimate INTEGER, actual INTEGER, cost INTEGER, trip INTEGER, minutes REAL, deleted INTEGER)')

# Accepted by Coco or by the user: enters app gains as an estimate and service starts.
db.execute("INSERT INTO trips VALUES('ASIGNADO',30000,NULL,0,1,0,0)")
money, estimated, earned, trips, service, pending = totals(db)
assert (money,estimated,earned,trips,pending)==(30000,30000,0,1,1), (money,estimated,earned,trips,pending)

# Finalized: same amount moves from estimated to earned, never counted twice.
db.execute("UPDATE trips SET status='FINALIZADO', minutes=12.5")
money, estimated, earned, trips, service, pending = totals(db)
assert (money,estimated,earned,trips,pending)==(30000,0,30000,1,0), (money,estimated,earned,trips,pending)
assert abs(service-12.5) < 1e-9

# A later real-payment correction replaces the estimate instead of adding a second payment.
db.execute("UPDATE trips SET actual=31500")
money, estimated, earned, trips, service, pending = totals(db)
assert (money,estimated,earned,trips,pending)==(31500,0,31500,1,0), (money,estimated,earned,trips,pending)

# Clock invariant: idle = connected - service. During a ride idle stays frozen; after finish it resumes.
connected_before=20.0; service_before=0.0
idle_before=connected_before-service_before
connected_during=27.0; service_during=7.0
idle_during=connected_during-service_during
assert idle_during == idle_before == 20.0
connected_after=30.0; finalized_service=7.0
idle_after=connected_after-finalized_service
assert idle_after == 23.0
print('PASS: accepted -> estimated; finalized -> earned; no double count; service/idle clocks preserve waiting time')
