# Hoy en las fotos: 18/09/2026

| Hora | Historial UYU |
|---|---:|
| 00:17 | 235.92 |
| 00:27 | 297.51 |
| 01:01 | 441.07 |
| 02:54 | 173.47 |
| 03:12 | 275.04 |
| 04:28 | 186.08 |
| 04:49 | 282.25 |
| 05:06 | 249.92 |
| 05:44 | 330.33 |

Cuatro registros adicionales son cero. Suma de los nueve importes positivos: **2.471,59**. Total ganancias: **2.833**; no hay propinas mostradas. Diferencia: **+361,41**, o **+14,62%** frente al historial.

Con factor 0,99 y redondeo por viaje: **2.446,88**, diferencia **−386,12** (−13,63% del total). Si ese historial está completo hasta el momento del resumen, 0,99 no es acertado para hoy. La fila cortada no demuestra por sí sola un viaje omitido.

Desglose mostrado: precio base 2.468 + extras 152 + Stars 212 = 2.832; el total muestra 2.833. Diferencia de componentes compatible con redondeos de pantalla. No confundir el historial con el precio base solo porque hoy son parecidos.
