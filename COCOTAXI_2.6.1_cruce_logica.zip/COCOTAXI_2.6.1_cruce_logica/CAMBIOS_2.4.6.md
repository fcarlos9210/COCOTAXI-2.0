# COCOTAXI 2.4.6

- Rediseño visual inspirado en la referencia aportada: fondo azul marino, tarjetas compactas, acentos verde esmeralda, amarillo, azul y violeta, navegación inferior y controles más modernos.
- Se mantiene intacta la lógica de evaluación de ofertas, sesión, promociones y automatización de Cabify.
- Nuevo PIN opcional de inicio configurable desde Ajustes > Seguridad.
- El PIN se almacena como derivación PBKDF2-HMAC-SHA256 con sal aleatoria; nunca se guarda en texto plano.
- Bloqueo temporal de 30 segundos después de cinco intentos fallidos.
- Corrección visual de la tarjeta de sesión para evitar el contador de Viajes duplicado.
- Versión 2.4.6 (versionCode 21).
