> Versión actual: **2.4.2**. Lee `CAMBIOS_2.4.2.md` y `PARA_CODEX_PC.md`; las notas inferiores describen versiones anteriores. Sin APK compilada en este entorno.

# Abrir en Codex del PC

Abre la carpeta que contiene `settings.gradle`, `gradlew.bat` y `app`.
Este es código 2.4.0, versionCode 15, Java 17, compileSdk/targetSdk 36.
No instalar ni reutilizar la APK anterior como si contuviera estos cambios.

Pega este encargo en Codex:

> Revisa README.md y docs/FORMULA.md. Esta entrega ya implementa las mejoras; no reconstruyas la app desde cero. Configura JDK 17 y SDK Android 36, ejecuta gradlew.bat testDebugUnitTest lintDebug assembleDebug. Resuelve errores reales de compilación y pruebas preservando la lógica documentada. Ejecuta especialmente PromotionStoreTest, FormulaTest, StoreTest, OverlayTest y UiTest. Renderiza las cuatro pestañas y el flotante en 393×852 dp y verifica también 360×800 y fuentes ampliadas: controles accesibles, sin cortes. Revisa que Inicio/Ajustes entren en la pantalla habitual y que el historial sea paginado. Conserva desplazamiento de respaldo si es necesario para accesibilidad. Comprueba actualización desde versionCode 14 sin borrar sesiones. Entrega APK solo tras compilar y comunica qué pruebas de dispositivo faltan; no afirmes haber validado Cabify sin hacerlo.

PowerShell (con JDK/SDK instalados y conexión):

```powershell
.\gradlew.bat testDebugUnitTest lintDebug assembleDebug
```

Salida: `app\build\outputs\apk\debug\app-debug.apk`.
Si Android rechaza una actualización por firma distinta, NO desinstalar borrando datos sin antes proteger el historial. Esta entrega no contiene ni requiere las claves del APK previo.

Pruebas de dispositivo pendientes:
- Primer inicio: superposición, accesibilidad y notificaciones; denegar y reintentar desde Ajustes.
- Tocar icono abre Coco; arrastrarlo no abre; minimizar muestra únicamente el icono.
- Dos ofertas visibles: comparar ambas; no pulsar automáticamente una lista.
- Aceptación fallida no suma; viaje asignado/finalizado actualiza historial; borrar resta y restaurar repone.
- Promo 23–03 a las 02:00 con 5/13: crédito desactivado si el ritmo no alcanza; viaje rentable ordinario sigue aceptable.
- Premio no se suma hasta cobrarlo. Corregir contador no duplica viajes ya observados.
- La sesión y la meta de jornada continúan al pasar medianoche; cierres de calibración se comparan por períodos iguales.

Prueba offline disponible con Python y Java 17: `python validation/check_core.py`. Compila las clases de fórmula reales con interfaces mínimas para dependencias Android; NO prueba base de datos, UI ni genera APK.
