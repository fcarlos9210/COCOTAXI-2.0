# COCOTAXI 2.5.0

- El control de sesión usa Play para conectar y resalta en verde únicamente el estado activo.
- Las promociones se pueden preparar sin conexión y se enlazan a la siguiente sesión.
- Liquidación permanece disponible y se retiró Comprobar cobros de Metas.
- Automatización muestra solo Aceptar auto y Vibración; la ventana flotante queda siempre activa durante la sesión.
- Perfil reemplaza al engranaje superior y contiene la seguridad/PIN.
- Días de trabajo permite asignar horas distintas a cada día; Coco usa las del día actual.
- Se retiraron Horas objetivo, la versión visible y el lema anterior.
- El Coco aparece en el banner y el lanzador usa un icono adaptativo sin rectángulo blanco.
- La ventana flotante adopta el panel neón con métricas, cobro y veredicto de la referencia.
- VersionCode 22 y versionName 2.5.0.
