@echo off
setlocal
pushd "%~dp0"
call gradlew.bat testDebugUnitTest assembleDebug --console=plain
if errorlevel 1 (
  echo Fallo la compilacion o una prueba. Revisa el error anterior.
  popd
  pause
  exit /b 1
)
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "COCOTAXI_2.4.2_debug.apk"
if errorlevel 1 (
  popd
  pause
  exit /b 1
)
echo APK creada: COCOTAXI_2.4.2_debug.apk
popd
pause
