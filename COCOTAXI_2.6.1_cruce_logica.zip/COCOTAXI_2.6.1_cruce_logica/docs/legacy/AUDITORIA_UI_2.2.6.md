# Auditoría UI COCOTAXI 2.2.6

Referencia visual: capturas suministradas en `pantallas.zip` y `COCO.zip`.

## Metas

- 4 indicadores superiores (`META REAL`, `OPERATIVO`, `SESIÓN REAL`, `CONECTADO`) en tarjetas iguales, más altas y con tamaños uniformes.
- `META DE HOY` ampliada para mantener visibles el valor objetivo, el indicador de porcentaje y los tres bloques `GANADO`, `FALTA`, `OBJ/H`.
- `META SEMANAL` conserva el mismo lenguaje visual de tarjetas internas.
- `SESIÓN REAL` no se marca como recuperación durante los primeros 60 minutos; se muestra `aún sin base`.
- Se mantienen 3 pestañas: Inicio, Metas, Ajustes.

## Ajustes

- Campos de objetivos distribuidos en 3 filas de dos columnas.
- Modo de demanda dentro de una tarjeta interna con botones uniformes.
- Días dentro de una tarjeta interna.
- Filtros, Promoción y Facturación en una fila de 3 botones del mismo ancho.
- Peajes/Sonido y Overlay/Días en filas separadas para evitar controles pegados.
- Registro de ingreso en una fila independiente.
- Guardar/Descartar separados y alineados.
- Sin `ScrollView` en la actividad: la distribución usa alturas compactas para mantener la pantalla completa.

## Compatibilidad funcional preservada

- OCR / Accessibility / overlay.
- Registro de viajes y estados.
- Promociones.
- Conciliación de facturación y aprendizaje semanal.
- Guardado explícito de ajustes.
