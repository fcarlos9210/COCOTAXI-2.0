# AUDITORIA PRECOMPILACION COCOTAXI 2.2.4

## Correcciones consolidadas

1. `MainActivity.java`: `CabifyBillingStore.reconcile(...)` devuelve `Reconciliation`; se usa `reconciliation.factor`.
2. `DecisionEngine.java`: la duracion se obtiene mediante `SessionStore.duration(...)`, no `SettingsStore.duration(...)`.
3. `CabifyBillingStore.java`: existe `addOcrSample(Context,String)` y delega a `addFromText(...)`.
4. `RideStore.java` y `WeeklyLearningStore.java`: las escrituras de `double` usan un helper que escribe bits en `long`; no se encadenan llamadas `putDouble` inexistentes de `SharedPreferences.Editor`.
5. `ScreenOcrEngine.java`: no usa `AccessibilityService.SCREENSHOT_SCREEN`.

## Comprobaciones estaticas

- Sin llamadas a `SettingsStore.duration(...)`.
- Sin llamadas a `SharedPreferences.Editor.putDouble(...)`.
- `CabifyBillingStore.Reconciliation` se utiliza con su propiedad `factor`.
- `addOcrSample(...)` esta definido y llamado desde `MainActivity`.
- Version: 2.2.4 / versionCode 10.

## Limitacion
No se ejecuta `assembleDebug` en este entorno porque no dispone del Android SDK/Gradle del proyecto.
