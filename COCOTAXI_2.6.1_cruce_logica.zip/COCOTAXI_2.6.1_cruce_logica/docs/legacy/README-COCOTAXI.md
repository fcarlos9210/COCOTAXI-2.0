# COCOTAXI 2.2.3

Esta versión parte directamente de la app visual de `COCO.zip`. Se mantienen los colores, estilo de tarjetas, tipografía, iconos y navegación general. Las pantallas son `Inicio`, `Metas` y `Ajustes`.

## Cambios funcionales

- Controles `Play / Pause / Stop` solo en Inicio.
- Sin scroll en las tres pantallas principales.
- Metas muestra simultáneamente Meta real, Objetivo operativo, Sesión real y Conectado.
- Ajustes tiene `GUARDAR AJUSTES` y `Descartar`; el guardado propaga los valores a Inicio, Metas y motor.
- Objetivo real separado del objetivo operativo.
- Aprendizaje semanal gradual: resultado real → sugerencia de operativo para la semana siguiente.
- Demanda automática para Uruguay: viernes/sábado alta, jueves/domingo media, lunes/martes/miércoles baja; el usuario puede forzar alta/media/baja.
- Detección Cabify por Accessibility + OCR de respaldo.
- No se muestra overlay sobre pantallas de historial/facturación solo porque aparezcan importes.
- Registro de oferta → aceptación → finalización para contar viajes y promociones.
- Facturación como capa estadística separada; no se hardcodea una comisión por viaje.
- Importación de capturas de facturación y conciliación manual de día.

## Regla de dinero

El importe de una oferta/historial se conserva como importe del viaje. La diferencia de `Total ganancias` frente a la suma del historial se analiza como conciliación diaria y no se reparte artificialmente entre viajes.

## Compilación

Abrir el proyecto en Android Studio o usar Gradle Wrapper. El proyecto está configurado con Java 17. Para generar debug:

```powershell
.\gradlew.bat clean assembleDebug
```

APK esperado:

`app\build\outputs\apk\debug\app-debug.apk`

## Pruebas

Ver `GUIA_PRUEBAS_FUNCIONALES_COCOTAXI_2.2.3.md`.


## 2.2.4
Esta entrega parte de COCOTAXI 2.2.3 y consolida las correcciones de compilacion. Usa `gradle wrapper --gradle-version 8.9` una sola vez si tu copia no trae `gradlew.bat`. No mezcles archivos con 2.2.2.


## COCOTAXI 2.2.5 — ajuste visual y UX

Esta versión conserva la interfaz de referencia con tres secciones: Inicio, Metas y Ajustes.

- Play / pausa / stop aparecen únicamente en Inicio.
- Metas muestra META REAL, OPERATIVO, SESIÓN REAL y CONECTADO sin scroll.
- META DE HOY tiene altura suficiente para mostrar GANADO, FALTA y OBJ/H completos.
- El estado RECUPERAR solo se muestra después de 60 minutos conectados; una sesión nueva no se marca como recuperación.
- Ajustes conserva el botón GUARDAR AJUSTES y aplica los cambios guardados al resto de la aplicación.
- No se usa una comisión Cabify hardcodeada para modificar el importe de una oferta.
