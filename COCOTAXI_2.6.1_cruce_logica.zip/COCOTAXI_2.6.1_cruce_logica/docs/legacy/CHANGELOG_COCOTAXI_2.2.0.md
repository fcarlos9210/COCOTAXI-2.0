# COCOTAXI 2.2.6

- UI recalibrada sobre la referencia visual de las pantallas aportadas.
- Metas: cuatro indicadores superiores más grandes y uniformes.
- Meta de hoy ampliada para mostrar completamente GANADO, FALTA y OBJ/H.
- Sesión real no se marca como recuperación durante la primera hora.
- Ajustes: controles con más separación, tamaños y jerarquía visual alineados con la referencia.
- Se mantienen las funciones de aprendizaje semanal, demanda, promociones, OCR y facturación.
