# COCOTAXI 2.2.3 — guía de pruebas funcionales

## 1. Objetivo

Esta versión conserva el diseño base de COCO.zip y añade la lógica de COCOTAXI sin mover los controles de sesión fuera de **Inicio**. Las pantallas principales son únicamente **Inicio / Metas / Ajustes**.

Las pruebas deben hacerse en un teléfono Android con Cabify Driver instalado. COCOTAXI no pulsa automáticamente Aceptar/Rechazar; observa el estado de Cabify mediante Accessibility y, cuando hace falta, OCR de pantalla.

## 2. Preparación del teléfono

1. Instalar `app-debug.apk`.
2. Abrir COCOTAXI.
3. Conceder permiso de ventana flotante cuando se use Overlay.
4. En Ajustes del sistema → Accesibilidad, activar el servicio de COCOTAXI.
5. Abrir Cabify Driver y dejarlo visible.
6. En COCOTAXI definir primero la meta real y el objetivo operativo y pulsar **GUARDAR AJUSTES**.

## 3. Pruebas de interfaz y navegación

### P01 — Controles solo en Inicio
Esperado: `▶`, `Ⅱ` y `■` aparecen únicamente en Inicio.

Resultado correcto: Metas y Ajustes no muestran esos tres botones.

### P02 — Sin scroll en pantallas principales
Esperado: Inicio, Metas y Ajustes se muestran completos sin `ScrollView` ni desplazamiento vertical.

### P03 — Metas muestra cuatro indicadores
Esperado: se ven simultáneamente:
- META REAL
- OPERATIVO
- SESIÓN REAL
- CONECTADO

### P04 — Guardar ajustes
Cambiar Meta real, Operativo y Demanda. Pulsar **GUARDAR AJUSTES**.

Esperado: al volver a Inicio y Metas aparecen los nuevos valores y el motor utiliza el nuevo operativo.

### P05 — Descartar ajustes
Cambiar un valor y pulsar **Descartar**.

Esperado: al volver a Ajustes aparece el valor anterior guardado.

### P06 — Navegar con cambios sin guardar
Modificar un ajuste y tocar otra pestaña.

Esperado: COCOTAXI pregunta si se desea guardar, salir sin guardar o cancelar.

## 4. Pruebas de sesión

### P07 — Iniciar sesión
En Inicio pulsar `▶`.

Esperado:
- estado CONECTADO;
- se inicia el reloj de sesión;
- el tiempo conectado aumenta;
- si Overlay está activado y tiene permiso, se inicia el servicio flotante.

### P08 — Pausar/reanudar
Pulsar `Ⅱ`.

Esperado: aparece EN PAUSA, se detiene el tiempo conectado. Pulsar `▶` para reanudar.

### P09 — Finalizar
Pulsar `■`.

Esperado: sesión desconectada, Overlay detenido y minutos de la sesión enviados al acumulado semanal.

## 5. Pruebas con Cabify

### P10 — Oferta visible
Con sesión activa y Cabify mostrando una oferta real:

Esperado: COCOTAXI detecta contexto de oferta, importe, recogida/viaje cuando estén disponibles y actualiza el Overlay.

No debe tomar como oferta una pantalla de historial, total de ganancias o resumen.

### P11 — Oferta con OCR parcial
Forzar un caso donde Accessibility no entregue el importe completo.

Esperado: COCOTAXI intenta OCR de la pantalla y combina los textos antes de evaluar.

### P12 — Aceptación inferida
Con una oferta activa, aceptar manualmente el viaje en Cabify.

Esperado: al desaparecer la tarjeta de oferta y aparecer una pantalla de recogida/navegación, COCOTAXI registra aceptación probable/confirmada.

### P13 — No aceptación
Dejar que una oferta expire o desaparezca sin entrar en una pantalla de recogida.

Esperado: no se registra como viaje aceptado.

### P14 — Finalización inferida
Completar un viaje y mostrar la pantalla final o historial.

Esperado: COCOTAXI marca el registro como completado, suma el importe del viaje que Cabify mostró y cuenta el viaje para promociones.

Importante: el importe individual usado por COCOTAXI sigue siendo el de la oferta/historial. No se inventa una comisión por viaje.

## 6. Pruebas de promociones

### P15 — Promoción manual
En Ajustes → Promoción indicar, por ejemplo, `10 viajes` y `$1000`.

Esperado: Metas muestra el progreso de la promoción.

### P16 — Progreso automático
Completar viajes con una promoción activa detectada o configurada.

Esperado: el contador aumenta solo después de que COCOTAXI detecta finalización del viaje; no aumenta solamente por ver una oferta.

## 7. Pruebas de facturación

### P17 — Importar capturas
En Ajustes → Facturación → Subir capturas, seleccionar capturas de Total de ganancias.

Esperado: COCOTAXI extrae, cuando están visibles:
- Total ganancias
- Precio base
- Extras y suplementos
- Comisión reducida
- Propinas
- Incentivos

### P18 — Conciliar día
Introducir:
- suma completa del Historial;
- Total de ganancias;
- propinas;
- incentivos.

Esperado: se guarda un **factor de conciliación diario** como estadística. Ese factor NO se presenta como “comisión por viaje”.

## 8. Pruebas de aprendizaje semanal

### P19 — Ejemplo 700 → 500
Configurar:
- Meta real: `700 UYU/h`
- Operativo usado: `700 UYU/h`
- Resultado real de semana: `500 UYU/h`

Pulsar **Registrar semana → Calcular**.

Esperado: el sistema calcula una sugerencia gradual cercana a `900 UYU/h` para la siguiente semana y no modifica la meta hasta pulsar **Aplicar sugerencia**.

### P20 — Aplicar sugerencia
Pulsar **Aplicar sugerencia**.

Esperado: Inicio y Metas muestran el nuevo operativo inmediatamente.

## 9. Prueba de demanda

En Ajustes probar AUTO / ALTA / MEDIA / BAJA y guardar.

Comportamiento inicial automático previsto para Uruguay:
- Viernes: ALTA
- Sábado: ALTA
- Jueves: MEDIA
- Domingo: MEDIA
- Lunes: BAJA
- Martes: BAJA
- Miércoles: BAJA

El usuario puede sobreescribir AUTO mediante ALTA/MEDIA/BAJA.

## 10. Criterios de aceptación

La versión se considera funcional cuando:

- los controles de sesión solo están en Inicio;
- las tres pantallas principales no requieren scroll;
- Metas muestra META REAL, OPERATIVO, SESIÓN REAL y CONECTADO;
- Ajustes tiene GUARDAR AJUSTES y los cambios se reflejan en Inicio/Metas;
- las ofertas de Cabify se distinguen de historial y facturación;
- aceptación/finalización se registran sin pulsar botones de Cabify;
- los viajes completados alimentan sesión y promociones;
- el importe de un viaje no se reduce artificialmente por una comisión inventada;
- las conciliaciones se guardan como estadística diaria;
- el aprendizaje semanal puede sugerir un nuevo operativo sin cambiarlo automáticamente.

## 11. Registro de incidencias

Para cualquier fallo anotar:
- modelo de teléfono;
- versión de Android;
- versión de Cabify;
- hora aproximada;
- pantalla de Cabify;
- qué debía detectar COCOTAXI;
- qué detectó realmente;
- captura de pantalla de Cabify y de COCOTAXI.


## Pruebas visuales 2.2.5

### Metas — Meta de hoy
- Abrir Metas en un teléfono vertical equivalente al usado en las capturas de referencia.
- Verificar que GANADO, FALTA y OBJ/H muestran etiqueta y número completos, sin clipping.
- Verificar que META REAL, OPERATIVO, SESIÓN REAL y CONECTADO muestran su valor completo.
- Verificar que no aparece scroll en la pantalla.

### Inicio — nueva sesión
- Iniciar una sesión y comprobar que PROMEDIO ACTUAL puede mostrar 0/h sin mostrar RECUPERAR.
- Confirmar que RECUPERAR aparece solo cuando la sesión tiene al menos 60 minutos conectados y el promedio queda por debajo del objetivo operativo.
- Confirmar que Play, Pausa y Stop solo existen en Inicio.

### Ajustes
- Cambiar Meta real UYU/h, objetivo operativo, demanda y horas.
- Pulsar GUARDAR AJUSTES.
- Volver a Inicio y Metas y verificar que los valores cambian inmediatamente.
- Entrar y salir sin guardar y comprobar el diálogo de cambios sin guardar.

### Compilación
Ejecutar en Windows desde la raíz del proyecto:

```powershell
gradle wrapper --gradle-version 8.9
.\gradlew.bat clean
.\gradlew.bat assembleDebug
```

El APK esperado es `app\build\outputs\apk\debug\app-debug.apk`.
