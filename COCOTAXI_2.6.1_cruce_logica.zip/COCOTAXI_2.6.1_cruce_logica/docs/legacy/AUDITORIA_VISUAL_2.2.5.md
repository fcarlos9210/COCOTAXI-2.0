# Auditoría visual COCOTAXI 2.2.5

Referencia usada: capturas aportadas por el usuario (Inicio/Metas/Ajustes).

## Cambios verificados

1. Navegación principal: solo Inicio, Metas y Ajustes.
2. Controles Play/Pausa/Stop: se crean únicamente cuando la pestaña actual es Inicio.
3. Metas: cuatro indicadores superiores; Meta de hoy ampliada; métricas GANADO/FALTA/OBJ/H con altura fija.
4. Inicio: RECUPERAR se muestra únicamente cuando la sesión lleva al menos 60 minutos conectada.
5. Las pantallas principales no contienen ScrollView.
6. Los ajustes se trabajan en un borrador y se aplican mediante GUARDAR AJUSTES.
