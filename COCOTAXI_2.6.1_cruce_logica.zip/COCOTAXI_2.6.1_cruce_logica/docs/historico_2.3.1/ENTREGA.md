# Empieza aquí

1. El APK compilado está en `entrega/COCOTAXI_2.3.1-debug.apk`.
2. Para continuar en tu PC, abre esta carpeta en Codex y lee `INSTRUCCIONES_CODEX.md`. No falta el Gradle Wrapper.
3. La fórmula está en `docs/FORMULA.md`; la auditoría de cambios, en `docs/CAMBIOS.md`.
4. Los 59 registros de Ayeryhoy están en `validation/viaje_por_viaje.csv`, con el análisis y sus límites en `validation/RESULTADOS_AYERYHOY.md`.
5. Las pruebas ejecutadas y las comprobaciones que requieren tu teléfono están en `docs/VALIDACION.md`.

## Tus indicaciones, integradas

| Indicación | Implementación |
|---|---|
| Neto por hora configurable | Factor diario provisional 0,99 y aprendizaje con cierres completos; recogida + viaje + esperas y costes opcionales |
| Comparar dos o más ofertas visibles | Tarjetas separadas, mejor neto/h que cumpla, posición de arriba abajo; nueva lectura al desplazarte |
| No abrir viajes de una lista | En listas solo recomienda; el usuario abre la oferta |
| Pulsación opcional | Solo oferta individual estable, favorable y con botón Aceptar accesible |
| No asumir que se aceptó | Intento, asignación y finalización separados; errores y competencia no suman |
| Historial por sesión | Corregir, eliminar y recuperar; confirmación sustituye el estimado |
| Solo dos estados flotantes | ACEPTAR / RECHAZAR con motivo y datos |
| Horas muertas y demanda | Umbrales iniciales por horario, selección manual y mapa opcional |
| Mapas enviados | +10%…+60% y colores; saldo y bonos no se usan como tarifa; no duplica incrementos |
| Toque del icono | Abre Coco; arrastre lo mueve |
| Diseño de referencia | Tema oscuro/verde, logo, tarjetas, medidores y cuatro pestañas; composición adaptable |
| Ensayo Ayeryhoy | Todos los importes legibles calculados; límites de datos y de validación explícitos |
| Compilar | APK de prueba incluido y fuente con instrucciones Windows/Linux |

La calibración diaria no exige pagos netos por viaje: lee `validation/RESULTADOS_AYERYHOY.md`. Se empieza con un ajuste de un solo día. El factor 0,99 no reproduce el total visible del 18; no se presenta como precisión validada.

Lee README.md antes de actualizar una instalación anterior: una firma distinta impide actualizar encima conservando datos. La aceptación automática y el mapa necesitan validación en tu Cabify real; no se ha simulado esa comprobación.
