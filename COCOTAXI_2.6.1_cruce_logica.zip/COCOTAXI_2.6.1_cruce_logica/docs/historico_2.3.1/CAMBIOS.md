# Actualización 2.3.1: calibración por cierres diarios

La aclaración de Frank permite asumir oferta=historial y entrenar contra Total ganancias sin propinas. Se incorpora modo diario inicial 0,99 de Ayeryhoy, con indicación provisional. Los cierres completos reemplazan esa referencia usando cociente de sumas; días parciales no entrenan. Se conserva el modo de parejas como opcional. Migración SQLite v1→v2 añade elegibilidad de cierres sin borrar sesiones ni confiar automáticamente en cierres antiguos. Nueva instalación o antiguo modo sin calibrar pasan al diario; una elección manual o de parejas se conserva.

La simulación ahora asume cada fila positiva aceptada y calcula pago y acumulado uno por uno. 0,99 estima 10.951,30 frente a 10.950 el 17; no se afirma precisión futura. Todo el flujo de ofertas, lista, aceptación, historial, icono y mapa de 2.3.0 se conserva.

# Revisión de 2.2.6 a 2.3.0

- Oferta/hora incluye recogida, trayecto y esperas configuradas. Costes opcionales por todos los km. Peajes y propinas excluidos del beneficio previsto.
- Se utiliza el factor de pago en la decisión. Se separa factor manual de parejas verificadas; no se simula una comisión universal ni una confianza estadística inexistente.
- Demanda por día/franja y selección manual. Recuperación gradual desde una hora, sin exigir compensar todo el pasado con un viaje. Solo dos recomendaciones visibles.
- Segmentación por tarjeta antes de extraer importes. Comparación de todas las tarjetas visibles completas; no se escoge el mayor importe del texto completo ni se mezcla OCR con texto accesible duplicado.
- Accesibilidad restringida por paquete exacto y comprobación de raíz. OCR local incluido, lectura secuencial, control de resultados obsoletos y captura de respaldo con consentimiento Android.
- Aceptación automática opcional solo en oferta individual mediante botón accesible; en listas únicamente recomienda. Se exige estabilidad y se evita repetir la misma oferta durante cinco minutos. No se pulsa rechazo ni se hace scroll automático.
- Estados de intento, asignado y finalizado separados. Ni historial ni el botón «Finalizar viaje» cuentan como finalización. Los intentos fallidos o no confirmados no producen ingresos.
- SQLite con sesiones independientes, corrección del mismo registro, eliminación reversible y calibración que excluye eliminados.
- Reloj monotónico, pausa y reinicio del dispositivo. Ingresos por día/semana independientes de la última sesión.
- Icono flotante: toque abre MainActivity; arrastre usa umbral de movimiento; tarjeta minimizable; ancho adaptable. Servicio de sesión en primer plano con notificación.
- Cuatro pestañas de las últimas referencias. Inicio mantiene conectar/pausar/desconectar, medidores y cifras reales. Sesión agrega historial. Ajustes agrupa campos avanzados para mantener la composición principal de las fotos. En pantallas pequeñas o con texto grande se permite desplazamiento para que no desaparezcan controles.
- Promociones: configuración explícita, vencimiento y progreso orientativo; no se adelanta el bono como dinero. Los extras cobrados se pueden registrar sin inventar otro viaje.
- Liquidación por fecha reemplaza la anterior; OCR se revisa antes de guardar. Aprendizaje semanal manual limitado y sensible al tiempo de espera.
- Gradle Wrapper completo, Java 17, Android API 36, pruebas y ensayo Ayeryhoy reproducible.

## Migración

Se mantienen las preferencias originales. El último total antiguo se conserva como una sesión heredada, marcado estimado y sin inventar viajes individuales. Si era una sesión aún activa, no se inventa el tiempo transcurrido sin observación: queda cerrada con tiempo no reconstruido. El historial detallado antiguo no existía y no puede reconstruirse a partir de un acumulado. Las preferencias antiguas de semanales se conservan, pero no se reparten entre fechas ni se añaden a los nuevos ingresos por segunda vez.

## Referencias de mapa recibidas al cierre

Reconoce +10%, +20%…+60% en el contexto del mapa o «Buscando viajes» / «viajes disponibles para ti». Se excluyen porcentajes de bonos y liquidaciones. La señal eleva el filtro durante 30 segundos y nunca duplica el incremento en la tarifa. Los colores son una ayuda experimental y no localizan con certeza al conductor dentro de una zona.
