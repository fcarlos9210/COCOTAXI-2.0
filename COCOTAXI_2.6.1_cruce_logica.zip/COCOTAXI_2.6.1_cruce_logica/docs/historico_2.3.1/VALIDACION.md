# Validación de COCOTAXI 2.3.1 — 18/09/2026

## Ejecutado sobre esta entrega

- Gradle 8.11.1, Android Gradle Plugin 8.10.1, JDK 17; compile/target SDK 36, mínimo API 26.
- `:app:testDebugUnitTest :app:assembleDebug :app:lintDebug`: **BUILD SUCCESSFUL**.
- **63 pruebas, cero fallos, errores o pruebas omitidas**. JUnit + Robolectric API 34. No equivalen a una prueba física del teléfono.
- Lint: **0 errores, 24 advertencias**. Se conserva el informe completo. Quedan avisos de traducción futura, controles nativos, dibujo y convenciones de recursos; el servicio limpia su referencia estática en onDestroy. La captura de Accesibilidad requiere API 30; en Android 26–29 existe captura de respaldo con permiso explícito. No se ha ocultado ningún error con un baseline ni desactivado Lint.
- APK `entrega/COCOTAXI_2.3.1-debug.apk`: package `com.cocotaxi.app`, versionCode 14, versionName 2.3.1. Firma debug v2 verificada con apksigner.
- SHA-256 del APK: `8d522a51c68a988d2273269bffb97de7cc534c048517573dc1166be42082445d`.
- La compilación usó copias locales de dependencias oficiales ya descargadas. En el PC no hace falta ese repositorio: sin COCO_LOCAL_MAVEN se usan Google Maven y Maven Central. El ZIP incluye gradlew, gradlew.bat y el JAR real del Wrapper.

| Grupo | Pruebas |
|---|---:|
| CardAccessibilityTest | 4 |
| FormulaTest | 30 |
| OverlayTest | 3 |
| StoreTest | 25 |
| UiTest | 1 |

Los casos incluyen recogida/esperas, factor aplicado una vez, exclusión de propinas/peajes previstos, proyección de sesión, tarjetas separadas, selección de la mejor, lista parcialmente visible, porcentajes de mapa, saldo y bono ignorados, intentos fallidos sin ingresos, finalizar una sola vez, corrección sin duplicar, borrado y recuperación, sesiones independientes, pausa/reinicio, viajes pendientes al cerrar sesión, toque frente a arrastre y los dos estados de la recomendación.

`design/preview/` contiene renders reales del código Android bajo Robolectric: Inicio, Metas, Sesión, Ajustes y ventana flotante. Revisados visualmente. Ajustes permite desplazarse para acceder a todos los controles. La tipografía, el tamaño y los controles se adaptan al teléfono; no se promete equivalencia píxel a píxel con una imagen de referencia.

## Ensayo Ayeryhoy

Ejecutado `python validation/simulate.py`: 59 filas, cálculo monetario Decimal y resultados reproducibles. El ajuste del 17 coincide porque se calculó con ese día; no se presenta como validación independiente. La suma visible del 18 no coincide con 0,99: se obtiene 2.446,88 frente a 2.833. No se puede afirmar que falten viajes solo por una fila cortada; hay que verificar la cobertura. Si está completo, el factor falla esa comparación. La relación Stars comprobada en días separados usa componentes ya liquidados y no predice una oferta inicial. Ver RESULTADOS_AYERYHOY.md. No se han inventado duraciones ni instalado esos cocientes como comisión universal.

## Comprobación pendiente en el teléfono

No se dispuso de un teléfono conectado ni acceso a tu PC. Deben comprobarse los textos reales de asignación/finalización, la estructura accesible de las tarjetas y el botón Aceptar, la captura al rotar, permisos Android/Samsung, restricciones de batería y el OCR en pantalla real. La aceptación automática queda desactivada inicialmente. La detección de mapa es experimental, opcional y no determina con certeza que tu ubicación esté dentro de una zona coloreada.

La app puede recomendar mediante OCR, pero solo pulsa un botón accesible identificado dentro de una oferta individual. En listas no pulsa nada. Si Cabify no expone una aceptación inequívoca, se usa el registro manual; una recomendación nunca se convierte automáticamente en dinero. Al desconectar o detectar un reinicio, los viajes pendientes quedan SIN CONFIRMAR y se pueden corregir, sin bloquear otra sesión.

El modo diario usa 0,99 inicial y provisional del 17; se ajusta con cierres completos sin requerir netos individuales. No está validado para otros días y no reproduce el total visible del 18. Se probaron exclusión de propinas/bonos/reembolsos, ponderación por importe, corrección y retirada de cierres, exclusión de parciales y días antiguos, migración conservando sesiones y suma de las ofertas del 17 mediante el mismo motor que la app. Los umbrales por demanda son una estrategia inicial, no un óptimo demostrado.
