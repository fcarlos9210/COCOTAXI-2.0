# COCOTAXI 2.3.1

Proyecto Android nativo Java para Frank. Parte de la versión 2.2.6 incluida en la transferencia y conserva el identificador `com.cocotaxi.app`, el logo y los iconos originales. Interfaz oscura con verde neón, tarjetas y medidores inspirados en las referencias; cuatro pestañas Inicio, Sesión, Metas y Ajustes. Las cifras son reales, no las cifras ilustrativas e inconsistentes de las fotos.

## Arranque

1. El APK de prueba ya compilado está en `entrega/COCOTAXI_2.3.1-debug.apk`; también puedes compilar el proyecto.
2. En Inicio, autoriza Accesibilidad y Ventana flotante.
3. En Ajustes, configura meta por hora y operativo. En «Pago, demanda y aceptación automática», selecciona «Cierres diarios · inicial Ayeryhoy» (predeterminado en instalaciones nuevas). Empieza con factor provisional 0,99. En Metas → Liquidación diaria puedes registrar el cierre completo para ajustar el factor. No necesitas netos individuales.
4. Conectar inicia una sesión. Pausar excluye el descanso; Reanudar continúa la misma sesión; Desconectar la cierra.
5. Abre Cabify Driver. Coco compara tarjetas visibles completas e indica su posición de arriba abajo. Al desplazarte vuelve a comparar las nuevas; no lee ofertas que nunca estuvieron en pantalla ni desplaza la lista por su cuenta.
6. Un toque en el icono abre COCOTAXI. Arrastrarlo lo mueve y no abre la app. «−» minimiza la tarjeta.
7. Revisa los pagos en Sesión. Confirmar sustituye la estimación; Eliminar excluye un error y permite deshacer.

**Nuevo modelo:** el factor diario compara la suma del historial con el total de ganancias sin propinas; conserva Stars dentro del total y separa bonos/reembolsos. Solo los días cerrados y completos confirmados entrenan. El factor inicial se ajustó con un día, sin validación independiente. El modo manual elegido previamente se conserva.

**El estado visible de la recomendación es únicamente ACEPTAR o RECHAZAR.** El texto inferior explica la causa. «Sin calibrar» rechaza preventivamente; puedes seleccionar factor manual 1 si verificas que el importe mostrado ya es el neto que quieres comparar.

## Aceptación automática

Se habilita expresamente en Ajustes; inicialmente desactivada. Requiere sesión activa, oferta conveniente con pago calibrado, pantalla de oferta individual (nunca una lista), misma tarjeta estable en dos lecturas y botón de aceptación accesible dentro de esa tarjeta. El clic no suma dinero. Se espera una pantalla de asignación y posteriormente finalización explícita. Errores, oferta tomada por otro conductor o un intento sin confirmar no suman.

No se pulsa «Rechazar» en Cabify: ese rótulo expresa la recomendación de Coco. Tampoco se hace clic por coordenadas OCR. Cuando Cabify no expone un botón identificable, la recomendación sigue disponible pero debes aceptar manualmente. Si no puede asociar una aceptación manual a una oferta inequívoca, usa el registro manual; Coco no supone que tomaste su recomendación.

No está validado contra una sesión real de Cabify en tu teléfono. La lectura, las transiciones y los botones pueden variar entre versiones y necesitan una prueba controlada en el dispositivo. No se controla tu PC ni tu instalación de Codex desde este chat.

## Compilar en Windows

Instala Android Studio con SDK Android 36 y Build Tools 35.0.0. Abre PowerShell en esta carpeta, la que contiene `gradlew.bat`:

```powershell
$env:JAVA_HOME="C:\Program Files\Android\Android Studio\jbr"
$env:Path="$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat --version
.\gradlew.bat testDebugUnitTest assembleDebug lintDebug
```

JDK 17 o un JBR compatible con Gradle 8.11.1. Si el SDK no se detecta, crea `local.properties` usando `local.properties.example`. También puedes ejecutar `powershell -ExecutionPolicy Bypass -File .\build.ps1`. Salida: `app\build\outputs\apk\debug\app-debug.apk`.

macOS/Linux: `chmod +x gradlew && ./gradlew testDebugUnitTest assembleDebug lintDebug`. La primera compilación descarga dependencias; la app usa OCR incluido para no depender de descargar un modelo en el teléfono.

El APK debug es de prueba y su firma puede diferir de tu instalación anterior. Para actualizar conservando datos usa la misma clave de firma anterior; no desinstales sin exportar o preservar lo que necesites. Este proyecto no contiene una clave de producción.

## Documentos

- `docs/FORMULA.md`: reglas y ejemplos, separación de comisiones, devoluciones y costes.
- `validation/RESULTADOS_AYERYHOY.md`: comparación real, límites y resultados reproducibles.
- `validation/viaje_por_viaje.csv`: todos los importes legibles, uno por uno.
- `docs/VALIDACION.md`: resultados de ejecución y comprobaciones pendientes en dispositivo.
- `INSTRUCCIONES_CODEX.md`: continuación/compilación en tu PC.
- `docs/legacy/`: documentos recibidos; son históricos y no describen necesariamente esta versión.

Datos locales en SQLite y preferencias. No hay backend, cuenta o envío de viajes a un servidor. La captura de respaldo requiere el permiso de Android y puede detenerse desde su notificación. Solo se procesa durante una sesión activa con Cabify en primer plano. Importar una liquidación muestra el OCR para revisión antes de guardar.
