# Fórmula aplicada en COCOTAXI 2.3.1

## Importe comparable

Para una oferta de importe `F`, se estima `P = redondear_centavos(F × k)`.

**Modo inicial: cierres diarios.** Frank confirma que el importe ofrecido pasa igual al historial. Se instala `k=0,99`, ajustado de forma provisional con Ayeryhoy del 17/09: 10.950 sin propinas / 11.061,89 de historial. Aplicado y redondeado viaje por viaje da 10.951,30. Esto es un ajuste del mismo día, no una precisión validada en otros días.

Al registrar días completos verificados, `k = Σ(total − propinas − bonos extraordinarios − reembolsos) / Σ(historial)` de los últimos 28 días cerrados. No exige pagos netos individuales. Stars y devoluciones ordinarias ya están incluidos en el total; no se agregan dos veces. Los cierres no se suman como nuevos ingresos. Los importes estimados anteriores conservan su estimación original; el nuevo factor se aplica a las nuevas ofertas.

También se conservan el factor manual y el modelo opcional de parejas individuales verificadas (mínimo cinco, separadas por rótulo). No hay una comisión universal impuesta. El factor diario global presupone que las ofertas e historial son comparables y que la mezcla de viajes no cambia mucho; no distingue condiciones de pago desconocidas por categoría.

Con `c` de gastos/km y `d` kilómetros totales, incluidos los km en vacío previstos:

```
Gasto = redondear_centavos(c × d)
Neto = P − Gasto
T = recogida + trayecto + espera pasajero + espera próxima oferta
R_viaje = 60 × Neto / T
R_sesión_proyectada = 60 × (Acumulado + Neto) / (MinutosConectados + T)
```

Los peajes reembolsados no son beneficio. Si hay una parte no reembolsada, debe incluirse entre los gastos reales al confirmar el viaje. Los gastos/km son opcionales y no incluyen automáticamente alquiler, impuestos, seguro o depreciación; el usuario define qué coste quiere modelar. Si necesita aplicar coste o filtro por km y faltan kilómetros, Coco rechaza por datos incompletos.

## Regla de decisión

`Filtro = Operativo × multiplicadorDemanda + recuperaciónGradual`

Demanda muerta: 0,75; baja: 0,90; media: 1; alta: 1,15. Son parámetros de estrategia iniciales, no valores entrenados ni garantía de ingreso. La meta real se conserva; aceptar por debajo de ella en horas débiles prioriza generar ingreso frente a esperar.

Desde 60 minutos conectados, si la sesión va por debajo de la meta:

```
Déficit = max(0, MetaReal × MinutosConectados / 60 − Acumulado)
RecuperaciónGradual = min(MetaReal × 0,20, Déficit × 60 / 120)
```

Se aplica en demanda media/alta cuando está habilitada. En demanda baja/muerta no eleva el filtro. Se reparte la recuperación sobre dos horas para no exigir que un único viaje compense todo el tiempo muerto pasado. Esta decisión evita bloquear indefinidamente ofertas rentables por un déficit histórico.

**ACEPTAR** si los datos son suficientes, hay un factor habilitado (incluido el inicial provisional), la sesión está activa, se cumplen límites de recogida y por km, el neto es positivo y `R_viaje ≥ Filtro`. En los demás casos muestra **RECHAZAR**, con el motivo. En caso de importe ambiguo no inventa cifras ni acepta automáticamente.

La aceptación automática opcional solo actúa en una oferta individual con botón accesible. En listas no pulsa ni abre tarjetas: el usuario elige y abre la oferta.

Entre todas las tarjetas visibles, se priorizan las que cumplen y después el mayor neto/h del ciclo. La proyección de sesión se muestra para conservar el efecto acumulado; no se comparan importes nominales como si dos viajes de distinta duración fueran equivalentes.

## Importe mínimo y recuperación completa

```
Oferta mínima para el filtro = (Filtro × T/60 + Gasto) / k
Oferta que recuperaría toda la meta = max(0, (MetaReal × (MinutosConectados+T)/60 − Acumulado + Gasto)/k)
```

Ejemplos sin costes ni esperas añadidas, k=1:

- 188 UYU, recogida 3 min y viaje 9 min: **940/h**.
- 480 ganados en 60 min, siguiente oferta 160 por 10 min: **548,57/h** proyectados.
- Para recuperar completamente 700/h en ese caso: **336,67**; oferta 337 deja **700,29/h**.
- Oferta 400 por esos 10 min: **754,29/h**.
- Oferta 985, recogida 7 y viaje 41: **1.231,25/h**, no 1.441,46/h. Un peaje de 167 no se suma como beneficio.

## Demanda automática

Zona horaria America/Montevideo. Inicialmente 02–06 es franja muerta; viernes/sábado 17–23 es alta; jueves/domingo fuera de franja muerta, media; el resto, baja. Las franjas se pueden editar y existe selección manual. El mapa es opcional y experimental: colores dominantes y rótulos +10%, +20%…+60% (y variantes antiguas x10…x60) en una pantalla identificada como mapa pueden elevar la exigencia durante 30 segundos. Estos rótulos jamás multiplican ni incrementan el dinero de la oferta: podría incluir ya la tarifa dinámica. El bono «hasta $2.000 extra» se trata por separado, sin anticipar su cobro. Las pestañas «Promos» y «Billetera» al pie del mapa no se confunden con estar dentro del historial. El OCR también puede reconocer los porcentajes cuando el mapa no expone texto accesible. No se deduce con certeza una demanda local a partir de colores sin una leyenda y localización verificadas.

## Contabilidad

Un intento de pulsación no es un ingreso; una recomendación tampoco. Se contabiliza una finalización explícita de un viaje asignado. El botón «Finalizar viaje» por sí solo y la pantalla «Historial» no finalizan nada. La confirmación real reemplaza el estimado del mismo registro; eliminar lo excluye de totales y aprendizaje. Se puede deshacer una eliminación.

El contador de sesión usa reloj monotónico; la pausa no suma. Después de reiniciar Android, la sesión queda pausada para no cobrar el tiempo apagado. Día y semana se calculan en Montevideo, semana desde lunes. Se conservan separadas sesiones distintas.

## Aprendizaje y límites

La conciliación se guarda por fecha y reemplaza otra captura del mismo día. No se suma al historial. Solo cambia el modelo diario si marcas el cierre como completo y comparable. Los cierres de hoy o parciales no entrenan. El ensayo Ayeryhoy documenta el supuesto oferta=historial indicado por Frank y la contradicción del total visible del 18 y la necesidad de verificar la cobertura de ese período.

No hay datos de demanda suficientes para probar que los umbrales iniciales maximicen el ingreso esperado. La verdadera optimización necesita tiempos de espera, alternativas disponibles y cobros emparejados. El ajuste semanal es orientativo, máximo ±10%, manual; exige cinco horas, diez viajes y pagos confirmados, y no eleva el filtro si predominó la espera.
