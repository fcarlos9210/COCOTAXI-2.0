# Continuar en Codex del PC

Trabaja en esta carpeta. Lee README.md, docs/FORMULA.md y docs/VALIDACION.md. No reconstruyas el proyecto ni sustituyas la interfaz por una web. Conserva package com.cocotaxi.app, cuatro pestañas y referencias visuales.

1. Comprueba JDK/SDK y ejecuta `gradlew.bat testDebugUnitTest assembleDebug lintDebug` en Windows (o `./gradlew` en Unix).
2. Corrige cualquier fallo real antes de declarar éxito. No descargues un APK de otro proyecto ni uses un build anterior como resultado de este código.
3. Instala en el teléfono conectado solo cuando Frank lo pida. Evita desinstalar una instalación anterior porque borra sus datos.
4. Comprueba el toque y arrastre del icono, la navegación a Coco desde Cabify, los permisos, pausa y finalización.
5. Con el conductor detenido, prueba dos tarjetas visibles, desplazamiento, tarjeta parcial, importe ambiguo, oferta ya tomada y botón Aceptar no accesible.
6. Valida los estados de asignación y finalización con el texto real que expone la versión instalada de Cabify. Un botón «Finalizar viaje» nunca debe contabilizar antes de que termine. Historial no es una finalización.
7. La automatización es opcional y debe seguir desactivada hasta que Frank la active; no debe pulsar otra tarjeta, repetir ofertas obsoletas ni tocar coordenadas OCR. Solo decide mediante reglas deterministas ajustadas por el usuario. En listas nunca pulsa ni abre tarjetas; solo recomienda el mejor visible.
8. El modo diario usa 0,99 provisional de Ayeryhoy, no una comisión universal. Frank confirma oferta=historial. Se aprende con sumas de cierres completos; no exigir netos individuales. No introducir propinas, duplicar Stars ni entrenar con días parciales.
9. Conservar los datos locales. Las eliminaciones del historial son reversibles y dejan de contar tanto para dinero como aprendizaje.
10. Entrega la ruta exacta del APK recién generado y los resultados de las pruebas. Describe sin ocultar las funciones no verificadas en el teléfono.
