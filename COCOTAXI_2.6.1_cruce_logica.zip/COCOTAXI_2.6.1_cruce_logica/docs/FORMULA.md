> 2.4.2: se elimina la espera entre ofertas futura de todas las fórmulas de rendimiento. Solo se suma recogida + recorrido + espera al pasajero. La espera real sigue en el tiempo de sesión. Esta corrección sustituye las expresiones antiguas inferiores.

> Actualización 2.4.1: el factor inicial es **1,00 provisional**. La conciliación posterior con viajes que cruzan medianoche sustituye la hipótesis antigua 0,99. Revisar `CAMBIOS_2.4.1.md`.

# Fórmula 2.4.0

## Meta vinculada

Semanal / días elegidos / horas por jornada = meta/hora.
Diaria / horas por jornada = meta/hora.
Si se elige hora, diaria = hora × horas; semanal = diaria × días.
Solo una fuente es editable. Toda modificación de duración/días recalcula las dependientes.

Promedio acumulado / Objetivo Real = (ganado de viajes finalizados + estimación del viaje actualmente asignado + premios ya registrados) / tiempo activo, incluyendo espera y excluyendo pausas explícitas. Un viaje `ASIGNADO` entra una sola vez como estimado; al pasar a `FINALIZADO` el mismo importe deja el bloque estimado y pasa al bloque ganado, sin duplicarse. Una corrección posterior del pago real sustituye esa estimación. Nunca contabilizar una recomendación o un intento fallido como ingreso.
Ritmo pendiente = máximo(0, meta diaria − acumulado) / horas restantes. A partir de una hora de sesión, el filtro de demanda media/alta recupera el déficit gradualmente, con un límite adicional de 20% de la meta/hora, para no rechazar toda oferta por un atraso imposible de cubrir de golpe.

## Pago de una oferta

Pago = redondear a centavos(oferta × factor).
Beneficio = pago − coste/km × (recogida + recorrido + km vacíos configurados).
Tiempo = recogida + trayecto + espera al pasajero + espera hasta próxima oferta.
Ingreso/hora = beneficio × 60 / tiempo.

Factor diario = suma(cierres sin propinas, premios ni peajes) / suma(historial correspondiente). Se exige declaración de día cerrado y cobertura completa; días en curso no entrenan. Una fecha de cierre debe corresponder a la misma ventana de los viajes: no mezclar «Hoy» y «Ayer» automáticamente. Stars ya está incluido, no se suma otra vez. 1,00 es un punto inicial provisional, NO una comisión conocida ni una garantía. También se conservan factor manual y pares individuales verificados.

Demanda muerta/baja/media/alta aplica 75/90/100/115% a la meta/hora en el filtro ordinario. El mapa modifica la exigencia, no añade de nuevo un suplemento al precio.

## Promoción

Se configura por sesión, nunca por calendario automático. Fechas explícitas admiten medianoche. Se cuentan viajes finalizados dentro de [inicio, fin); se excluyen eliminados y abonos que no son viajes. El contador manual fija una corrección sobre los viajes que ya existen y no los duplica; futuros viajes, borrados y restaurados se reflejan. Si Cabify exige otra condición de elegibilidad, debe corregirse el contador según Cabify. No se ha inferido esa condición de las imágenes.

Restantes N = exigidos − completados. Tiempo disponible L = mínimo(fin de promo − ahora, tiempo restante de jornada). Margen reservado = máximo(5 minutos, 10% de L).
Ciclo futuro: percentil 80 de hasta ocho intervalos entre finalizaciones en la sesión; incluye esperas. Requiere al menos tres intervalos. Sin datos: 15 minutos por ciclo. Nunca menos que esperas configuradas + 8 minutos. Este dato inicial es una hipótesis conservadora configurable mediante tiempos; no aprendizaje demostrado.

Se comprueba:
 tiempo de oferta + (N−1) × ciclo futuro ≤ L − margen.

Si no cabe, crédito cero: decisión ordinaria. Si cabe, el crédito por viaje para comparar es:
 premio × descuento prudencial / N.
Descuento prudencial = 0,60 + 0,25 × mínimo(1, holgura / tiempo necesario).
No es una probabilidad estadística entrenada. Nunca supera 85% del premio pendiente y nunca se contabiliza como cobro.

La oferta con promoción debe alcanzar como mínimo la meta/hora y el filtro ordinario si es mayor. Su puntuación compara (beneficio + crédito condicionado)/tiempo. Los viajes largos que no cumplen se rechazan salvo que su cobro ordinario por hora sí convenga. Entre tarjetas visibles se priorizan aceptables y luego esta puntuación. No se conocen ofertas fuera de pantalla.

Al lograr o vencer la promoción, deja de repartir crédito. Cobro: registro manual de bono sin marcar «cuenta como viaje», una sola vez. No hay detección garantizada del abono real de Cabify ni garantía de completar promociones. La aproximación usa ritmo reciente y un descuento fijo; no es un optimizador con conocimiento del mercado futuro.
