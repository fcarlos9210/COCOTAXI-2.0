# PROMPT DE CONTINUACIÓN PARA ASTRA

Continúa el desarrollo de COCOTAXI usando CONTEXTO_COCOTAXI.md y el ZIP ACTUAL del proyecto Android que adjunte el usuario.

Primero inspecciona la estructura y el código real. No asumas que una función existe. Intenta compilar el estado inicial antes de realizar cambios. Si falta Gradle Wrapper, repara/configura un build reproducible.

Reglas:
- Conserva Conectar, Pausar y Desconectar.
- No uses comisión fija de Cabify.
- La decisión principal usa el promedio proyectado de la sesión.
- Separa estado de sesión, OCR/parser, motor de decisión, overlay y persistencia.
- Prueba fórmulas antes de integrarlas.
- MediaProjection/OCR debe ser eficiente.
- Gestiona correctamente Accessibility, permiso de overlay y MediaProjection.
- Ejecuta tests/build después de los cambios y no declares éxito sin comprobarlo.
- Si el entorno permite compilar, continúa corrigiendo errores hasta producir APK.
- Al final indica cambios, pruebas, pendientes y ruta exacta del APK.

Pruebas mínimas:
1. $188, pickup 3, viaje 9 => 940 UYU/h.
2. target 700, conectado 60, acumulado 480, oferta 160, duración 10 => ~548.57/h proyectado.
3. mismo estado: importe para recuperar target => ~336.67.
4. oferta 400 => ~754.29/h proyectado.
5. tiempo pausado no aumenta minutosConectado.
6. propina no participa en predicción de una oferta futura.
