# COCOTAXI — TRANSFERENCIA DE CONTEXTO

## Objetivo
COCOTAXI 2.x es una app Android para ayudar a un conductor de Cabify en Uruguay a decidir qué ofertas tomar, usando principalmente el efecto de cada oferta sobre el rendimiento acumulado de la sesión.

## UI
Pantalla principal minimalista, sin mapa ni evaluación de viajes. Mantener:
- ▶ Conectar: inicia sesión y overlay.
- Ⅱ Pausar: congela tiempo conectado y desactiva temporalmente overlay.
- ■ Desconectar: finaliza sesión y oculta overlay.
Al reanudar, continúa la misma sesión. La evaluación aparece en overlay sobre Cabify.

## Fórmulas
minutosOferta = minutosHastaRecoger + minutosViaje
importeBruto = importeMostrado + peajesVisibles
rendimientoViaje = importeBruto / minutosOferta * 60

Ejemplo: $188, 3 min recogida, 9 min viaje => 12 min => 940 UYU/h.

promedioSesion = dineroAcumulado / minutosConectado * 60
dineroProyectado = dineroAcumulado + importeOferta + peajesVisibles
tiempoProyectado = minutosConectado + minutosOferta
promedioProyectado = dineroProyectado / tiempoProyectado * 60

Clasificación inicial configurable:
- >=110% objetivo: EXCELENTE
- >=100%: ACEPTABLE
- >=90%: CONSIDERAR
- <90%: NO CONVIENE

La decisión principal NO debe depender sólo del rendimiento individual. Debe responder:
“¿Qué efecto tiene este viaje sobre mi objetivo de UYU/h desde que comencé la sesión?”

## Modo recuperación
Si promedioSesion está bajo el objetivo:
importeMinimo = objetivoHora * ((minutosConectado + minutosOferta)/60) - dineroAcumulado - peajesVisibles

Ejemplo: objetivo 700, conectado 60 min, acumulado 480, próxima oferta 10 min:
importe mínimo = 336.67 UYU.
Oferta $160 => promedio proyectado 548.57/h.
Oferta ~$337 => ~700/h.
Oferta $400 => ~754.29/h.

No rechazar automáticamente importes pequeños: $160 por 5 min puede ser muy útil.

## Demanda
Overlay: AUTO / HIGH / MEDIUM / LOW.
Patrón inicial orientativo y configurable: viernes/sábado alta; jueves/domingo media; lunes/martes/miércoles baja.
La demanda no cambia la matemática base. Puede ajustar estrategia por costo de oportunidad: alta demanda = más selectividad; baja = esperar también cuesta.

## Meta semanal
Permitir objetivo semanal, por ejemplo 40.000 UYU. Arquitectura futura: distinguir conectado, esperando, conduciendo y cargando. Por ahora tiempo conectado es central y la pausa no suma tiempo.

## Cabify: bruto y pago real
NO hardcodear 20%, 17%, 0.897724 ni otra comisión universal.
La decisión en vivo usa el importe bruto mostrado.
Más adelante aprender factorPago = pagoReal / importeMostrado con datos reales, separando siempre:
1. bruto mostrado;
2. pago estimado aprendido;
3. pago/liquidación real.
Analizar ratio de sumas, mediana, media recortada, percentiles, MAD, MAE/MAPE/RMSE y confianza. Propinas no se predicen ni se usan para decidir ofertas futuras.

## OCR / captura
AccessibilityService solo no sirve para texto dentro de una imagen de Galería. Arquitectura deseada:
1. AccessibilityService;
2. si no basta, MediaProjection;
3. Google ML Kit Text Recognition on-device Latin;
4. parser;
5. motor de decisión;
6. overlay.

Caso de prueba: detectar $188, 3 min / 339 m, 9 min / 4.1 km => $188, 3 min, 9 min => 940 UYU/h.
Evitar OCR continuo agresivo para batería/CPU.

## Overlay
Debe poder mostrar: clasificación, importe, pickup, viaje, rendimiento individual, promedio actual, promedio proyectado, objetivo, “NECESITAS ≥ $X” en recuperación y demanda.
Verificar que el icono flotante abra MainActivity; anteriormente se detectó un posible bug de doble toque/performClick sin listener efectivo.

## Datos históricos
Se quiere usar dataset/carpeta “ayeryhoy” para simular recomendaciones viaje a viaje y comparar con el pago real diario, excluyendo propinas predictivas.
También se planteó analizar un ZIP grande de capturas Cabify incrementalmente: clasificar oferta/detalle/liquidación, OCR de importes/comisiones/impuestos/peajes/propina/km/minutos/fecha, agrupar capturas por viaje y generar JSON/Markdown y modelo personalizado de payout.

## Android / compilación
Package conocido: com.cocotaxi.app
Repositorio mencionado: github.com/fcarlos9210/COCOTAXI-2.0. En una comprobación anterior existía pero estaba vacío y la integración no pudo escribir (403). Verificar estado actual antes de usarlo.

Build PowerShell esperado desde raíz:
$env:JAVA_HOME="C:\Program Files\Android\Android Studio\jbr"
$env:Path="$env:JAVA_HOME\bin;$env:Path"
java -version
.\gradlew.bat --version
.\gradlew.bat clean assembleDebug

APK esperado:
app\build\outputs\apk\debug\app-debug.apk

Instalación:
adb devices
adb install -r .\app\build\outputs\apk\debug\app-debug.apk

Si INSTALL_FAILED_UPDATE_INCOMPATIBLE: existe com.cocotaxi.app con otra firma. Para prueba se puede desinstalar e instalar de nuevo, sabiendo que uninstall borra datos locales.

## Último problema local
Ruta:
C:\Users\frank\Pictures\coctaxi\COCOTAXI_2.1.0_mejorada_para_compilar
`java` inicialmente no estaba en PATH; se indicó JBR de Android Studio.
Luego `.\gradlew.bat --version` dio CommandNotFoundException: gradlew.bat no estaba en esa raíz o el proyecto estaba anidado/incompleto.
Siguiente diagnóstico:
Get-ChildItem
Get-ChildItem -Recurse -Filter "gradlew.bat" -ErrorAction SilentlyContinue

## Prioridades
1. Inspeccionar ZIP/código real antes de asumir.
2. Conseguir build reproducible.
3. Mantener Conectar/Pausar/Desconectar.
4. Testear pausa y tiempo conectado.
5. Pruebas unitarias del motor matemático.
6. Accessibility + MediaProjection/OCR.
7. Overlay/permisos/servicios robustos.
8. Validar con dataset real.
9. Nunca comisión fija.
10. Separar OCR/parser, sesión, decisión, overlay, persistencia y futuro aprendizaje de payout.
