# COCOTAXI 2.5.3 — corrección icono flotante

- Corregido el icono flotante de Coco al conectar la sesión.
- Causa: `RoundedIconView` se agregaba al overlay con tamaño `0 x 0`; cambiar su visibilidad no podía hacerlo visible.
- Solución: el icono ahora se crea a `56dp x 56dp`, centrado dentro de la ventana minimizada de 66dp.
- Se mantienen los dos bordes verdes y el comportamiento de arrastrar/tocar para abrir Coco.
- No se cambió la lógica de evaluación ni autoaceptación de viajes.
