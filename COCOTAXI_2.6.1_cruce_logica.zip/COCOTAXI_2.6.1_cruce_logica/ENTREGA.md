> Versión actual: **2.6.1**. Cruce de lógica 2.4.5 + rendimiento 2.6.0. Lee `CAMBIOS_2.6.1.md` y `AUDITORIA_CRUCE_2.6.1.md`. Sin APK compilada en este entorno.

# Entrega 2.4.0 — fuentes, sin APK nueva

Se aplicaron metas exclusivas, promoción por sesión integrada en recomendaciones, contador corregible, pantallas compactas, historial paginado, permisos guiados y flotante basado en COCO.zip original.

Comprobado aquí: 25 escenarios de lógica Java; sintaxis de 26 archivos Java.
Pendiente: compilación Android, suite Robolectric completa, renderizado y prueba física con Cabify. Gradle no se pudo descargar por restricción de red del entorno. No se afirma que todos los errores de la APK anterior estén resueltos sin reproducirlos.

No se ha demostrado una fórmula universal de pago con las capturas: factor diario provisional identificado; registros de períodos coincidentes permiten sustituirlo. Las promociones no se contabilizan anticipadamente.

Instrucciones: INSTRUCCIONES_CODEX.md. Fórmula: docs/FORMULA.md. Los informes de 2.3.1 son históricos, no pruebas de 2.4.0.
