# Auditoría cruzada 2.4.5 ↔ 2.6.0 / COCOTAXI 2.6.1

## Ciclo validado

1. **Esperando viaje**: `Sin viaje` crece con el tiempo conectado; `En servicio` permanece fijo.
2. **Aceptación automática**: primero se despacha el click de Cabify; luego se crea el registro y se confirma como `ASIGNADO`.
3. **Aceptación manual**: el evento de click intenta registrar la oferta; si la pantalla cambia demasiado rápido, las señales de pantalla asignada reutilizan únicamente una oferta individual reciente y no una lista ambigua.
4. **ASIGNADO**: el importe entra una vez en `Ganancias en App`, dentro del bloque **estimado**. `En servicio` crece desde la aceptación. Como el tiempo conectado y el tiempo de servicio crecen juntos, `Sin viaje` conserva la espera previa.
5. **FINALIZADO**: el mismo registro cambia de estado, se fija su duración de servicio y su importe sale de **estimado** y pasa a **ganado**. El total de `Ganancias en App` no salta ni se duplica por finalizar.
6. **Después del viaje**: `En servicio` queda fijo en la duración acumulada y `Sin viaje` vuelve a crecer con la nueva espera.
7. **Corrección posterior**: un pago real sustituye el importe estimado del registro finalizado; no añade un segundo viaje.

## Resultado del cruce

La lógica temporal de 2.4.5 se conserva en la 2.6.0 auditada: el servicio vivo se calcula desde el instante de aceptación y `Sin viaje` se deriva siempre como conectado menos servicio. La optimización 2.6.0 no alteró ese mecanismo; solo redujo trabajo antes del click.

Se corrigió una diferencia de presentación/contabilidad: antes `estimated` dependía de que `actual` fuese nulo, por lo que un viaje ya `FINALIZADO` podía seguir apareciendo como estimado hasta una corrección manual. En 2.6.1 los bloques se definen por **estado del viaje**: `ASIGNADO = estimado`, `FINALIZADO = ganado`.

## Invariantes

- Una oferta vista pero no asignada no suma dinero ni viaje.
- Un viaje asignado suma una sola vez.
- Finalizar mueve el importe entre bloques; no lo vuelve a sumar.
- Un error/cancelación que lleve el registro fuera de `ASIGNADO`/`FINALIZADO` deja de contarse.
- `En servicio` solo crece durante el viaje activo.
- `Sin viaje` nunca se reinicia al aceptar o finalizar.
