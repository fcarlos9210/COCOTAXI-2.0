# Cambios 2.6.0

- Auditoría y optimización del camino crítico oferta → decisión → autoaceptación.
- Una sola pasada del árbol de Accesibilidad en la ruta normal mediante `TextCollector.Snapshot`.
- Reutilización del nodo clicable y bounds de Aceptar; sin volver a buscar el botón antes del click.
- Una sola evaluación de `DecisionEngine` por conjunto de ofertas.
- Click/gesto despachado antes de escrituras SQLite y antes de dibujar el overlay.
- Caches de sesión, viaje y promociones invalidados por revisión de `CocoStore`.
- Revisión de store con `AtomicLong` para seguridad entre hilos.
- Normalización de texto compartida entre parser, asignación y demanda.
- Parser reducido en regex/reemplazos repetidos.
- MediaProjection procesa frames en `HandlerThread` y aplica throttle antes de SQLite.
- Screenshots de Accessibility se copian en executor dedicado.
- Overlay evita consultar SQLite en cada tick de 200 ms.
- Accesibilidad filtrada a `com.cabify.driver`.
- Sondeo de respaldo reducido de 150 ms a 100 ms.
- Telemetría `COCO_PERF` para medir `inspect_to_dispatch_ms`, `decision_ms` y `post_dispatch_ms`.
- El resultado de autoaceptación se notifica al overlay después del intento y conserva la visualización de 4 s.
- `versionName 2.6.0`, `versionCode 24`.

No se modificó intencionalmente la fórmula de decisión ni el diseño aprobado.
