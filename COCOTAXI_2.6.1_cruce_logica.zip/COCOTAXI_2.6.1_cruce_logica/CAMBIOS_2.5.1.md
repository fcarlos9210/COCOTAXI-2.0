# COCOTAXI 2.5.1

- Icono flotante minimizado: exactamente dos bordes verdes, usando el verde activo de la app.
- Inicio: tarjeta renombrada a **PROMEDIO CONFIRMADO** y cálculo visual basado solo en ingresos confirmados.
- Ajustes: objetivo configurado desde un solo parámetro a elección (Semanal, Jornada o Por hora); los otros dos se recalculan automáticamente con la lógica existente.
- Perfil: eliminados el recuadro de presentación de Perfil y el botón Volver.
- Botones: fondo visual con menor ancho mediante márgenes internos laterales, conservando áreas táctiles y comportamiento.
- Motor de decisión, OCR, aceptación, promociones y persistencia no se alteraron.
