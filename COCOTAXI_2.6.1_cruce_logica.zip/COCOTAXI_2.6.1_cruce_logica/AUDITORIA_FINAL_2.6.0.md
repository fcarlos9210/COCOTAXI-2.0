# COCOTAXI 2.6.0 — Auditoría final de captura y autoaceptación

Fecha: 2026-09-19
Base auditada: COCOTAXI 2.5.3 (icono flotante corregido)
Objetivo: reducir al mínimo el tiempo desde que Cabify expone una oferta hasta que Coco decide y despacha la acción Aceptar, sin cambiar la fórmula de decisión ni el diseño visual aprobado.

## Conclusión

El cuello de botella principal no estaba en la fórmula matemática. Estaba en el camino alrededor de ella: el árbol de Accesibilidad se recorría varias veces, la misma oferta se evaluaba dos veces, se consultaba SQLite repetidamente y se actualizaba la ventana flotante antes de pulsar Aceptar.

La versión 2.6.0 reorganiza el camino crítico para que sea:

1. recibir evento / sondeo de respaldo;
2. recorrer el árbol de Accesibilidad una sola vez;
3. normalizar y extraer la oferta;
4. evaluar una sola vez;
5. despachar `ACTION_CLICK` (o gesto de respaldo);
6. después del despacho: registrar en SQLite y actualizar la ventana flotante.

No se ha cambiado intencionalmente la fórmula que determina si un viaje es aceptable.

## Hallazgos de mayor impacto

### 1. Hasta 7–8 recorridos del árbol para una sola oferta — CORREGIDO

En 2.5.3, el camino rápido de una oferta individual podía recorrer el árbol para:

- `collect`;
- `isList`;
- `hasAccept`;
- `acceptBounds`;
- nuevamente `isList`;
- nuevamente `hasAccept`;
- `clickAccept`;
- y, si era necesario el gesto, volver a buscar `acceptBounds`.

En 2.6.0, `TextCollector.Snapshot` obtiene en una sola pasada:

- texto visible;
- cantidad de botones Aceptar;
- límites del botón;
- copia del ancestro clicable que ejecutará `ACTION_CLICK`.

El camino normal de autoaceptación queda en un recorrido del árbol.

### 2. La decisión se calculaba dos veces — CORREGIDO

En 2.5.3 `show()` llamaba a `best(cards)` y luego `maybeClick()` volvía a llamar a `best(cards)`. Eso duplicaba carga de ajustes, sesión, calibración, promociones y evaluación.

En 2.6.0 se calcula `DecisionEngine.Result` una sola vez y el mismo resultado alimenta tanto el click como el overlay.

### 3. SQLite estaba delante del click — CORREGIDO

En 2.5.3 `store.attempt(...)` se ejecutaba antes de `TextCollector.clickAccept(root)`. Una escritura o espera de SQLite podía retrasar el click real sobre Cabify.

En 2.6.0 se reserva primero el debounce, se despacha el click y solo después se persiste el intento/confirmación.

### 4. El overlay se dibujaba antes de aceptar — CORREGIDO

La ventana flotante se actualizaba antes de `maybeClick`. En 2.6.0 el orden es decisión → click → persistencia → overlay. El trabajo de WindowManager ya no está delante del botón Aceptar.

### 5. Consultas de sesión demasiado frecuentes — CORREGIDO

El servicio consultaba `CocoStore.session()` en cada sondeo de 150 ms y otras rutas volvían a consultarlo. `session()` no es un getter trivial: también puede actualizar intervalos y abrir transacciones.

Se añadieron snapshots de muy corta duración invalidados por una revisión del store. Para decisión se refresca como máximo cada 200 ms; para estado normal, 750 ms. Las mutaciones relevantes invalidan el cache inmediatamente mediante un `AtomicLong`.

### 6. El overlay consultaba SQLite 4 veces por segundo — CORREGIDO

El temporizador visual sigue actualizándose cada 200 ms, pero la sesión se recarga solo al cambiar la revisión o al cumplirse 1 segundo.

### 7. Captura de respaldo hacía trabajo pesado en el hilo principal — CORREGIDO

La conversión de frames de MediaProjection pasó a un `HandlerThread`, y la copia de screenshots de Accessibility usa un executor dedicado. La devolución a ML Kit se coordina sin bloquear el camino principal de Accesibilidad.

Además, el `ImageReader` ahora aplica el throttle antes de consultar SQLite: los callbacks a frecuencia de pantalla ya no consultan la sesión en cada frame.

### 8. Eventos de otras aplicaciones — CORREGIDO

El servicio de Accesibilidad queda filtrado a `com.cabify.driver`, que es la aplicación que el código actual sabe interpretar. Esto reduce eventos irrelevantes y trabajo cuando otras apps cambian su interfaz.

### 9. Normalización y regex repetidos — REDUCIDOS

Se normaliza el texto principal una sola vez por inspección y se reutiliza en parser, señales de asignación y demanda. Expresiones frecuentes se compilan una vez o se sustituyen por comparaciones más baratas cuando es seguro.

### 10. Sondeo de respaldo — AJUSTADO

El sondeo pasó de 150 ms a 100 ms. Los eventos de Accesibilidad siguen siendo la ruta primaria; el sondeo solo reduce el peor caso cuando Cabify no emite a tiempo un evento útil.

## OCR

OCR queda como respaldo, no como primera opción. La ruta más rápida sigue siendo Accesibilidad porque permite obtener texto y botón en el mismo árbol y ejecutar `ACTION_CLICK` directamente.

Cuando Coco reutiliza una lectura OCR reciente con un botón Aceptar accesible, se conserva una pequeña confirmación de estabilidad de 80 ms para no pulsar una oferta nueva usando texto OCR de un frame anterior. Esta protección no se aplica a una oferta completa y actual leída directamente de Accesibilidad.

## Instrumentación añadida

Cada intento automático real escribe una línea con tag `COCO_PERF`:

- `inspect_to_dispatch_ms`: desde el inicio de la inspección hasta despachar el click/gesto;
- `decision_ms`: tiempo empleado por la evaluación;
- `post_dispatch_ms`: persistencia ejecutada después del click;
- `click=1`: acción despachada;
- `click=-1`: no se pudo despachar;
- `ocr=true/false`: origen OCR o Accesibilidad.

Para medirlo en el teléfono:

```powershell
adb logcat -c
adb logcat -s COCO_PERF:I
```

Estas métricas permiten optimizar usando tiempos reales del teléfono, no estimaciones.

## Validaciones realizadas aquí

- Parseo sintáctico: 22 archivos Java sin errores de sintaxis.
- 33 comprobaciones del motor central: PASS.
- 9 comprobaciones de señales de asignación: PASS.
- Se añadieron regresiones del parser para oferta individual, pantalla de historial con acentos y múltiples ofertas visibles.

Limitación del entorno: aquí no está instalado/caché el Android SDK + Gradle 8.11.1 necesario para ejecutar un `assembleDebug` Android completo. Por eso la última verificación de tipos Android y compilación debe hacerse en el PC.

## Compilación en el PC

```powershell
$env:JAVA_HOME="C:\Program Files\Android\Android Studio\jbr"
$env:Path="$env:JAVA_HOME\bin;$env:Path"

.\gradlew.bat clean
.\gradlew.bat assembleDebug
```

APK esperada:

`app\build\outputs\apk\debug\app-debug.apk`

## Qué no se cambió

- diseño visual aprobado;
- objetivo y lógica funcional de Coco;
- fórmula de decisión;
- regla de que Coco solo pulsa automáticamente cuando la decisión es aceptable;
- ventana de resultado de aproximadamente 4 segundos;
- icono flotante de 2.5.3.

## Próxima prueba recomendada

Probar varias ofertas reales con `COCO_PERF` abierto. El número importante es `inspect_to_dispatch_ms`. Si aparecen valores altos, las líneas permitirán separar lectura/decisión de trabajo posterior al click y localizar el siguiente cuello de botella en el dispositivo real.
