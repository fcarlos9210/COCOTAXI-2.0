# COCOTAXI 2.4.1 — pantalla de origen y ventana flotante

Implementado en fuentes, sin APK compilada ni prueba en teléfono en esta entrega.

- Reconoce la pantalla fotografiada: Ir a origen + Navegar + Ver ruta, excluyendo historial, aceptar y errores.
- Si se perdió el evento del botón, conserva la última oferta INDIVIDUAL con Aceptar durante 45 segundos y en la misma sesión. Al aparecer origen recupera esa oferta, aunque la recomendación fuera RECHAZAR. No reutiliza el mejor viaje de una lista para adivinar el seleccionado.
- La asignación crea el viaje en historial como ASIGNADO; el importe estimado no se convierte en ingreso final hasta confirmar la finalización. Se mantiene edición/eliminación manual. Si el importe no se identifica, se muestra diagnóstico y se necesita registro manual. Falta probar la pantalla real de finalización.
- Ventana reorganizada según la referencia: fondo oscuro verde, borde verde, cuatro columnas Recogida/Viaje/Total/Después del viaje; importe grande y ACEPTAR/RECHAZAR (dos decisiones). Total incluye esperas configuradas. Después del viaje = (ingreso acumulado + neto de oferta) × 60 / (minutos conectados + ciclo estimado). No abona promociones anticipadamente.
- Icono oculto en panel expandido, visible al minimizar. Tocar el icono abre Coco; arrastrarlo mueve. La X oculta esa oferta; no rechaza en Cabify ni desconecta la sesión.
- Factor inicial corregido a 1,00 PROVISIONAL. 18/09: 2471,59 de ese día + 361,91 del último viaje anterior = 2833,50 frente a 2833 mostrado. Cruce de medianoche inferido; no existen horas de finalización verificadas. No restar otra comisión ni sumar Stars de nuevo. Excluir propinas de ambos lados de cualquier calibración. Los cierres antiguos ingresados por el usuario no se modifican automáticamente: retirar los no conciliados.

## Validación
Ejecutar `python3 validation/check_core.py` y `java validation/ParseJava.java app/src`. Los tests de Android/Robolectric y el render de la ventana requieren Gradle y SDK. La apariencia fue implementada con vistas nativas; no se ha verificado coincidencia visual exacta en dispositivo.

## Pendiente del pedido anterior
Esta actualización resuelve la referencia de pantalla y la ventana. Siguen pendientes la reanudación de sesiones cerradas con botón Nueva sesión, múltiples promociones y el modelo observado de esperar frente a tomar viaje. No confundir esta entrega con esas funciones terminadas. Tampoco detecta automáticamente el importe de una asignación iniciada sin haber observado antes su oferta individual.
