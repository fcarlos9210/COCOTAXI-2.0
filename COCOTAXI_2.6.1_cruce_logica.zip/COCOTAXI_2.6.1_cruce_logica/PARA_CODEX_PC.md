# Compilar COCOTAXI 2.4.2

Abre esta carpeta en Codex de tu PC y pega:

> Compila este proyecto Android nativo. Lee CAMBIOS_2.4.2.md. Usa Java 17, Android SDK 36 y el Gradle Wrapper incluido. Detecta Android Studio/SDK instalados y configura local.properties localmente si hace falta. Ejecuta testDebugUnitTest y assembleDebug, corrige los fallos concretos sin alterar los requisitos y deja la APK en COCOTAXI_2.4.2_debug.apk. Prueba pausa, cierre con historial preservado y nueva sesión a cero, toque del icono para abrir/minimizar, ocultación de recomendación con viaje asignado y ausencia de espera futura en la fórmula. No desinstales la app ni borres datos del móvil. Si existe una clave de firma local autorizada, conserva la identidad de firma para actualizar; no incluyas claves ni contraseñas en el ZIP. Indica las pruebas que no puedas ejecutar.

También puedes ejecutar COMPILAR_WINDOWS.bat desde esta carpeta si Java y SDK ya están configurados. Requiere Internet para descargar dependencias. El script detiene la entrega si fallan los tests.

La APK debug solo actualizará una instalación con firma compatible. No se ha generado APK en este chat ni se ha accedido remotamente a tu PC. Para traer una compilación realizada allí a este chat hay que adjuntar la APK resultante.
