#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
exec sh ./gradlew testDebugUnitTest assembleDebug lintDebug
