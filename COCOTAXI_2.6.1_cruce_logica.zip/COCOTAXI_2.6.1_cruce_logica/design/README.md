# Referencias visuales

Las cuatro referencias de interfaz y las dos fotos del mapa con porcentajes están en references/. Se conserva el logo original del código, los iconos de trazo, fondo casi negro, verde neón, tarjetas redondeadas con bordes, títulos blancos, indicadores y barra inferior con Inicio / Sesión / Metas / Ajustes.

La implementación utiliza controles nativos; las fotos no se usan como una pantalla falsa. Los textos, importes y proporciones se adaptan al ancho y tamaño de fuente. Los ajustes avanzados se agrupan en una vista secundaria y hay desplazamiento de respaldo cuando el contenido no cabe. Las cifras ilustrativas de las fotos se sustituyen por cálculos reales.

Las imágenes en preview/, si están presentes, provienen del render de la app bajo Robolectric, no de un generador de imágenes. No prueban la apariencia final exacta en todos los dispositivos ni la interacción real con Cabify.
