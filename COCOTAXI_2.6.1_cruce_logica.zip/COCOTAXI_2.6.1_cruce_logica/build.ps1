$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not $env:JAVA_HOME) {
  $studioJbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
  if (Test-Path $studioJbr) { $env:JAVA_HOME = $studioJbr }
}
if ($env:JAVA_HOME) { $env:Path = "$env:JAVA_HOME\bin;$env:Path" }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { throw 'Instala JDK 17 o Android Studio y configura JAVA_HOME.' }
& .\gradlew.bat testDebugUnitTest assembleDebug lintDebug
if ($LASTEXITCODE -ne 0) { throw "La compilación falló: código $LASTEXITCODE" }
Write-Host 'APK: app\build\outputs\apk\debug\app-debug.apk'
