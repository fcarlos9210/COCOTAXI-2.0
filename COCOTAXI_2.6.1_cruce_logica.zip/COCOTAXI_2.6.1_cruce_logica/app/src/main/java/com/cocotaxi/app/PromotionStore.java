package com.cocotaxi.app;

import android.content.*;
import android.database.Cursor;
import java.util.*;

/** Multiple independent promotions for the current session. */
public final class PromotionStore {
  private static final String PREFS = "coco_verified_promotions_v2";
  private static final String LEGACY = "coco_verified_promotion";
  private static final String NEXT_SESSION = "__next_session__";

  private static SharedPreferences prefs(Context c) {
    SharedPreferences p = c.getSharedPreferences(PREFS, 0);
    migrateLegacy(c, p);
    return p;
  }

  private static void migrateLegacy(Context c, SharedPreferences target) {
    if (target.getBoolean("migrated", false)) return;
    SharedPreferences old = c.getSharedPreferences(LEGACY, 0);
    int t = old.getInt("target", 0);
    String session = old.getString("session", "");
    SharedPreferences.Editor e = target.edit().putBoolean("migrated", true);
    if (t > 0 && session != null && !session.isEmpty()) {
      e.putInt("count", 1)
          .putString("0.id", UUID.randomUUID().toString())
          .putString("0.session", session)
          .putInt("0.target", t)
          .putLong("0.bonus", old.getLong("bonus", 0))
          .putLong("0.start", old.getLong("start", 0))
          .putLong("0.end", old.getLong("end", 0))
          .putInt("0.adjustment", old.getInt("adjustment", 0));
    }
    e.apply();
  }

  /** Compatibility helper: replaces the current session's promotions with one promotion. */
  public static void set(Context c, int target, double bonus, long end) {
    set(c, target, bonus, System.currentTimeMillis(), end, 0);
  }

  /** Compatibility helper used by existing tests and old callers. */
  public static void set(Context c, int target, double bonus, long start, long end, int completed) {
    clear(c);
    add(c, target, bonus, start, end, completed);
  }

  public static String add(
      Context c, int target, double bonus, long start, long end, int completed) {
    CocoStore.Session session = CocoStore.get(c).session();
    validate(session, target, bonus, start, end, completed);
    List<Snapshot> raw = rawRecords(c);
    Snapshot s = new Snapshot();
    s.id = UUID.randomUUID().toString();
    s.session = session.active ? session.id : NEXT_SESSION;
    s.target = target;
    s.bonus = bonus;
    s.start = start;
    s.end = end;
    s.adjustment = completed - (session.active ? count(c, session.id, start, end) : 0);
    raw.add(s);
    write(c, raw);
    return s.id;
  }

  public static void update(
      Context c, String id, int target, double bonus, long start, long end, int completed) {
    CocoStore.Session session = CocoStore.get(c).session();
    validate(session, target, bonus, start, end, completed);
    List<Snapshot> raw = rawRecords(c);
    boolean found = false;
    for (Snapshot s : raw) {
      if (s.id.equals(id) && (s.session.equals(session.id) || s.session.equals(NEXT_SESSION))) {
        s.target = target;
        s.bonus = bonus;
        s.start = start;
        s.end = end;
        s.adjustment = completed - (session.active ? count(c, session.id, start, end) : 0);
        found = true;
        break;
      }
    }
    if (!found) throw new IllegalArgumentException("La promoción ya no existe");
    write(c, raw);
  }

  public static void remove(Context c, String id) {
    List<Snapshot> raw = rawRecords(c);
    raw.removeIf(s -> s.id.equals(id));
    write(c, raw);
  }

  private static void validate(
      CocoStore.Session session, int target, double bonus, long start, long end, int completed) {
    if (target < 1
        || target > 500
        || !Double.isFinite(bonus)
        || bonus <= 0
        || start >= end
        || end <= System.currentTimeMillis()
        || end - start > 48L * 3600000L
        || completed < 0
        || completed > target)
      throw new IllegalArgumentException("Revisa premio, viajes y horario (máximo 48 h)");
  }

  private static int count(Context c, String session, long start, long end) {
    try (Cursor q =
        CocoStore.get(c)
            .getReadableDatabase()
            .rawQuery(
                "SELECT COUNT(*) FROM trips WHERE session=? AND deleted=0 AND trip=1 "
                    + "AND status='FINALIZADO' AND at>=? AND at<?",
                new String[] {session, "" + start, "" + end})) {
      return q.moveToFirst() ? q.getInt(0) : 0;
    }
  }

  private static double cycle(Context c, String session) {
    List<Double> cycles = new ArrayList<>();
    try (Cursor q =
        CocoStore.get(c)
            .getReadableDatabase()
            .rawQuery(
                "SELECT at FROM trips WHERE session=? AND deleted=0 AND trip=1 "
                    + "AND status='FINALIZADO' ORDER BY at DESC LIMIT 9",
                new String[] {session})) {
      long previous = 0;
      while (q.moveToNext()) {
        long at = q.getLong(0);
        if (previous > at) cycles.add((previous - at) / 60000.0);
        previous = at;
      }
    }
    if (cycles.size() < 3) return 15;
    Collections.sort(cycles);
    return Math.max(1, cycles.get((int) Math.ceil(cycles.size() * .8) - 1));
  }

  private static List<Snapshot> rawRecords(Context c) {
    SharedPreferences p = prefs(c);
    int n = Math.max(0, Math.min(50, p.getInt("count", 0)));
    List<Snapshot> out = new ArrayList<>();
    for (int i = 0; i < n; i++) {
      Snapshot s = new Snapshot();
      s.id = p.getString(i + ".id", "");
      s.session = p.getString(i + ".session", "");
      s.target = p.getInt(i + ".target", 0);
      s.bonus = p.getLong(i + ".bonus", 0) / 100.0;
      s.start = p.getLong(i + ".start", 0);
      s.end = p.getLong(i + ".end", 0);
      s.adjustment = p.getInt(i + ".adjustment", 0);
      if (!s.id.isEmpty() && !s.session.isEmpty() && s.target > 0) out.add(s);
    }
    return out;
  }

  private static void write(Context c, List<Snapshot> records) {
    SharedPreferences.Editor e = prefs(c).edit().clear().putBoolean("migrated", true);
    e.putInt("count", records.size());
    for (int i = 0; i < records.size(); i++) {
      Snapshot s = records.get(i);
      e.putString(i + ".id", s.id)
          .putString(i + ".session", s.session)
          .putInt(i + ".target", s.target)
          .putLong(i + ".bonus", Money.cents(s.bonus))
          .putLong(i + ".start", s.start)
          .putLong(i + ".end", s.end)
          .putInt(i + ".adjustment", s.adjustment);
    }
    e.apply();
  }

  /** Every promotion belonging to the active session, including scheduled/expired ones. */
  public static List<Snapshot> getAll(Context c) {
    return getAll(c, CocoStore.get(c).session());
  }

  /** Hot-path overload: reuse the session snapshot already loaded by Accessibility. */
  public static List<Snapshot> getAll(Context c, CocoStore.Session current) {
    List<Snapshot> out = new ArrayList<>();
    long now = System.currentTimeMillis();
    double cycle = current.active ? cycle(c, current.id) : 15;
    List<Snapshot> records = rawRecords(c);
    boolean bound = false;
    for (Snapshot raw : records) {
      if (current.active && NEXT_SESSION.equals(raw.session)) {
        raw.session = current.id;
        bound = true;
      }
      if (current.active ? !current.id.equals(raw.session) : !NEXT_SESSION.equals(raw.session)) continue;
      int observed = current.active ? count(c, current.id, raw.start, raw.end) : 0;
      raw.completed = Math.max(0, observed + raw.adjustment);
      raw.completed = Math.min(raw.target, raw.completed);
      raw.now = now;
      raw.cycle = cycle;
      raw.samples = cycle == 15 ? 0 : 3;
      out.add(raw);
    }
    if (bound) write(c, records);
    out.sort(Comparator.comparingLong(a -> a.start));
    return out;
  }

  /** Portfolio wrapper kept for the decision engine and old callers. */
  public static Snapshot get(Context c) {
    return get(c, CocoStore.get(c).session());
  }

  /** Hot-path overload: avoids querying the session a second time for every offer. */
  public static Snapshot get(Context c, CocoStore.Session current) {
    List<Snapshot> all = getAll(c, current);
    Snapshot portfolio = new Snapshot();
    portfolio.promotions = all;
    if (all.isEmpty()) return portfolio;
    Snapshot chosen = null;
    for (Snapshot s : all) if (s.active()) { chosen = s; break; }
    if (chosen == null) chosen = all.get(0);
    portfolio.copyScalar(chosen);
    portfolio.promotions = all;
    return portfolio;
  }

  public static void clear(Context c) {
    c.getSharedPreferences(PREFS, 0).edit().clear().putBoolean("migrated", true).apply();
    c.getSharedPreferences(LEGACY, 0).edit().clear().apply();
  }

  public static class Snapshot {
    public String id = "", session = "";
    public int target, completed, samples, adjustment;
    public double bonus, cycle = 15;
    public long start, end, now;
    public java.util.List<Snapshot> promotions = java.util.Collections.emptyList();

    private void copyScalar(Snapshot s) {
      id = s.id;
      session = s.session;
      target = s.target;
      completed = s.completed;
      samples = s.samples;
      adjustment = s.adjustment;
      bonus = s.bonus;
      cycle = s.cycle;
      start = s.start;
      end = s.end;
      now = s.now;
    }

    public boolean active() {
      if (promotions != null && !promotions.isEmpty()) {
        for (Snapshot s : promotions) if (s.activeScalar()) return true;
        return false;
      }
      return activeScalar();
    }

    private boolean activeScalar() {
      return target > completed && now >= start && now < end;
    }

    public String description() {
      if (promotions != null && !promotions.isEmpty()) {
        int active = 0, future = 0;
        for (Snapshot s : promotions) {
          if (s.activeScalar()) active++;
          else if (s.now < s.start && s.completed < s.target) future++;
        }
        String base = promotions.size() + (promotions.size() == 1 ? " promoción" : " promociones");
        if (active > 0) return base + " · " + active + (active == 1 ? " activa" : " activas");
        if (future > 0) return base + " · " + future + (future == 1 ? " programada" : " programadas");
        return base + " · revisar";
      }
      if (target == 0) return "Sin promociones · configurar";
      if (completed >= target) return "Meta de promo completada · confirma el abono";
      if (now < start) return "Programada · " + completed + "/" + target + " viajes";
      if (now >= end) return "Promo terminada · " + completed + "/" + target;
      double left = (end - now) / 60000.0;
      boolean reachable = (target - completed) * cycle + Math.max(5, left * .1) <= left;
      return completed
          + "/"
          + target
          + " viajes · "
          + (long) left
          + " min"
          + (reachable ? " · en seguimiento" : " · necesita viajes más rápidos");
    }
  }
}
