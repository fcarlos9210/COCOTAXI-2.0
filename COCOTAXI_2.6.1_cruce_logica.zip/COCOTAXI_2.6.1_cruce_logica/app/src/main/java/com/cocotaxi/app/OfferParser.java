package com.cocotaxi.app;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/** Parse one card only. Screen segmentation must happen before monetary extraction. */
public final class OfferParser {
  private static final Pattern PRICE =
      Pattern.compile("(?:\\$u?|u\\$|uyu)\\s*([0-9][0-9.,]*)", Pattern.CASE_INSENSITIVE);
  private static final Pattern MIN = Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*min(?:utos?)?\\b");
  private static final Pattern KM = Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*(km|m)\\b");
  private static final Pattern WS = Pattern.compile("\\s+");
  private static final Pattern ACCEPT_SPLIT = Pattern.compile("(?iu)(?<=aceptar)\\s*\\n");

  private OfferParser() {}

  /** Unicode normalization without recompiling a regex on every call. */
  public static String normalize(String s) {
    if (s == null || s.isEmpty()) return "";
    String decomposed = Normalizer.normalize(s, Normalizer.Form.NFD);
    StringBuilder out = new StringBuilder(decomposed.length());
    for (int i = 0; i < decomposed.length(); i++) {
      char c = decomposed.charAt(i);
      int type = Character.getType(c);
      if (type != Character.NON_SPACING_MARK
          && type != Character.COMBINING_SPACING_MARK
          && type != Character.ENCLOSING_MARK) out.append(Character.toLowerCase(c));
    }
    return out.toString();
  }

  public static boolean isHistoryScreen(String text) {
    return isHistoryNormalized(normalize(text));
  }

  public static boolean isHistoryNormalized(String s) {
    if (s == null) return false;
    return s.contains("historial")
        || s.contains("total ganancias")
        || s.contains("total a cobrar")
        || s.contains("precio base")
        || s.contains("comision reducida")
        || ((s.contains("billetera") || s.contains("promos")) && !DemandModel.isMapScreenNormalized(s));
  }

  public static boolean isLikelyOfferScreen(String text) {
    return isLikelyOfferNormalized(normalize(text));
  }

  public static boolean isLikelyOfferNormalized(String s) {
    if (s == null || isHistoryNormalized(s)) return false;
    return s.contains("aceptar")
        || s.contains("para ti")
        || s.contains("en app")
        || s.contains("viaje disponible");
  }

  public static Offer parse(String text, String pkg) {
    return parseNormalized(text, normalize(text), pkg);
  }

  /** Parse when the caller already normalized the same accessibility/OCR frame. */
  public static Offer parseNormalized(String rawText, String normalized, String pkg) {
    Offer o = new Offer();
    o.rawText = rawText == null ? "" : rawText;
    o.platform = "Cabify";
    String s = normalized == null ? "" : normalized;
    o.hasOfferSignal = isLikelyOfferNormalized(s);
    if (!o.hasOfferSignal) return o;
    o.kind = s.contains("para ti") ? "PARA_TI" : s.contains("en app") ? "EN_APP" : "UNKNOWN";
    String[] lines = s.split("\\n");
    List<Double> prices = new ArrayList<>();
    for (String l : lines) {
      Matcher m = PRICE.matcher(l);
      if (l.contains("peaje")) {
        if (m.find()) o.tolls = Money.parse(m.group(1));
        continue;
      }
      if (excludedPriceLine(l)) continue;
      while (m.find()) prices.add(Money.parse(m.group(1)));
    }
    if (prices.size() == 1) o.fare = prices.get(0);
    else if (prices.size() > 1) o.warning = "Más de un importe: tarjeta ambigua";

    Matcher m = MIN.matcher(s);
    List<double[]> legs = new ArrayList<>();
    List<Integer> starts = new ArrayList<>(), ends = new ArrayList<>();
    while (m.find()) {
      starts.add(m.start());
      ends.add(m.end());
      legs.add(new double[] {Money.metric(m.group(1)), -1});
    }
    for (int i = 0; i < legs.size(); i++) {
      String after = s.substring(ends.get(i), i + 1 < legs.size() ? starts.get(i + 1) : s.length());
      Matcher d = KM.matcher(after);
      if (d.find()) legs.get(i)[1] = Money.metric(d.group(1)) / (d.group(2).equals("m") ? 1000 : 1);
    }
    if (legs.size() == 2) {
      o.pickupMin = legs.get(0)[0];
      o.pickupKm = legs.get(0)[1];
      o.tripMin = legs.get(1)[0];
      o.tripKm = legs.get(1)[1];
    } else {
      o.warning = legs.size() > 2 ? "Varias rutas: no mezclar tarjetas" : "Faltan los dos tiempos";
    }

    o.key =
        o.kind
            + "|"
            + o.fare
            + "|"
            + o.pickupMin
            + "|"
            + o.tripMin
            + "|"
            + o.pickupKm
            + "|"
            + o.tripKm
            + "|"
            + WS.matcher(s).replaceAll(" ").trim();
    return o;
  }

  private static boolean excludedPriceLine(String l) {
    return l.contains("saldo")
        || l.contains("bono")
        || l.contains("extra")
        || l.contains("propina")
        || l.contains("incentivo")
        || l.contains("ganancias")
        || l.contains("/h")
        || l.contains("/km");
  }

  /** OCR fallback only accepts unambiguous cards separated by their Accept action. */
  public static List<Offer> parseVisible(String text) {
    return parseVisibleNormalized(normalize(text));
  }

  public static List<Offer> parseVisibleNormalized(String normalizedText) {
    List<Offer> out = new ArrayList<>();
    String normalized = normalizedText == null ? "" : normalizedText;
    if (isHistoryNormalized(normalized)) return out;
    String[] chunks = ACCEPT_SPLIT.split(normalized);
    for (String chunk : chunks) {
      Offer o = parseNormalized(chunk, chunk, "com.cabify.driver");
      if (o.hasEnoughForDecision()) out.add(o);
    }
    return out;
  }
}
