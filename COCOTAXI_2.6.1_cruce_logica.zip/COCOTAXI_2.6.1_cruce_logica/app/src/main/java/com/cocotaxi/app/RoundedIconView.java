package com.cocotaxi.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

public final class RoundedIconView extends View {
  private final Bitmap bitmap;
  private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
  private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
  private final Paint innerStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
  private final Path clipPath = new Path();
  private final Rect source = new Rect();
  private final RectF target = new RectF();

  public RoundedIconView(Context context) {
    super(context);
    bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.cocotaxi_foreground);
    strokePaint.setStyle(Paint.Style.STROKE);
    // Same emerald used by the active Desconectar button in MainActivity.
    strokePaint.setColor(Color.rgb(32, 227, 162));
    strokePaint.setStrokeWidth(dp(2));
    innerStrokePaint.setStyle(Paint.Style.STROKE);
    innerStrokePaint.setColor(Color.rgb(32, 227, 162));
    innerStrokePaint.setStrokeWidth(dp(2));
    setLayerType(View.LAYER_TYPE_SOFTWARE, null);
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    float radius = Math.min(getWidth(), getHeight()) * 0.24f;
    float inset = dp(3);
    target.set(inset, inset, getWidth()-inset, getHeight()-inset);
    clipPath.reset();
    clipPath.addRoundRect(target, radius, radius, Path.Direction.CW);
    int save = canvas.save();
    canvas.clipPath(clipPath);
    canvas.drawColor(Color.rgb(13, 36, 56));
    if (bitmap != null) {
      source.set(0, 0, bitmap.getWidth(), bitmap.getHeight());
      canvas.drawBitmap(bitmap, source, target, bitmapPaint);
    }
    canvas.restoreToCount(save);
    // Exactly two green borders around Coco.
    canvas.drawRoundRect(target, radius, radius, strokePaint);
    RectF inner = new RectF(target);
    inner.inset(dp(4), dp(4));
    canvas.drawRoundRect(inner, Math.max(0, radius - dp(4)), Math.max(0, radius - dp(4)), innerStrokePaint);
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }
}
