package com.cocotaxi.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.Display;
import android.view.accessibility.*;
import java.util.*;
import java.util.concurrent.*;

public final class CocotaxiAccessibilityService extends AccessibilityService {
  public static final String CABIFY = "com.cabify.driver";
  public static CocotaxiAccessibilityService instance;
  public static String diagnostic = "Activa Accesibilidad para leer Cabify";
  private final Handler handler = new Handler(Looper.getMainLooper());
  private ScreenOcrEngine ocr;
  private volatile boolean processing;
  private volatile boolean busy, destroyed;
  private long inspectStartedNs, lastDispatchNs;
  private long ocrAt, stableAt, clickedAt;
  private String stableKey = "";
  private final java.util.Map<String, Long> attemptedKeys = new java.util.HashMap<>();
  private List<Offer> previous = new ArrayList<>();
  private long previousAt;
  private Offer recentDetail;
  private Offer recentOcrOffer;
  private Offer lastUnambiguousOffer;
  private long recentOcrAt, lastUnambiguousAt;
  private String detailSession = "", lastOfferSession = "";
  private long detailAt;
  private boolean assignmentSeen;

  // Short-lived hot-path caches. Store revision invalidates them immediately after any session/trip mutation.
  private CocoStore.Session cachedSession;
  private CocoStore.Trip cachedTrip;
  private long cachedSessionAt, cachedTripAt, cachedRevision = -1L, cachedTripRevision = -1L;
  private PromotionStore.Snapshot cachedPromo;
  private long cachedPromoAt, cachedPromoRevision = -1L;
  private final ExecutorService screenshotExecutor =
      Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "CocoScreenshot");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
      });

  private static final int CLICK_NONE = 0;
  private static final int CLICK_SUCCESS = 1;
  private static final int CLICK_FAILURE = -1;

  private void rememberDetail(List<Offer> cards, boolean individual) {
    // Never replace the last verified single offer with a list. Keeping the last detail briefly
    // lets us associate a very fast screen transition with the amount the user just accepted.
    if (!individual || cards.size() != 1) return;
    recentDetail = cards.get(0);
    detailAt = SystemClock.elapsedRealtime();
    detailSession = cachedSession != null ? cachedSession.id : CocoStore.get(this).session().id;
    cacheUnambiguous(recentDetail);
    assignmentSeen = false;
  }

  private void cacheUnambiguous(Offer offer) {
    if (offer == null || !offer.hasEnoughForDecision()) return;
    lastUnambiguousOffer = offer;
    lastUnambiguousAt = SystemClock.elapsedRealtime();
    lastOfferSession = cachedSession != null ? cachedSession.id : CocoStore.get(this).session().id;
  }

  private void observeAssignment(
      String normalized, boolean assigned, CocoStore store, CocoStore.Session session, CocoStore.Trip trip) {
    if (assigned && !assignmentSeen) {
      assignmentSeen = true;
      long now = SystemClock.elapsedRealtime();
      Offer candidate = null;
      if (recentDetail != null && session.id.equals(detailSession) && now - detailAt <= 45000)
        candidate = recentDetail;
      else if (recentOcrOffer != null && session.id.equals(lastOfferSession) && now - recentOcrAt <= 6000)
        candidate = recentOcrOffer;
      else if (lastUnambiguousOffer != null
          && session.id.equals(lastOfferSession)
          && now - lastUnambiguousAt <= 6000)
        candidate = lastUnambiguousOffer;
      else if (previous.size() == 1 && now - previousAt <= 5000) candidate = previous.get(0);

      if (trip == null && candidate != null) {
        SettingsStore.Values v = SettingsStore.load(this);
        int demand = demand(v);
        PromotionStore.Snapshot promo = promotionSnapshot(store, session);
        CocoStore.Calibration learned = calibration(store, candidate.kind, v);
        DecisionEngine.Result r = DecisionEngine.evaluate(candidate, v, session, demand, learned, promo);
        // Assignment is independent of the recommendation: this branch only records what Cabify already assigned.
        if (r.payout > 0) store.attempt(candidate, r, false);
      }
      recentDetail = null;
      recentOcrOffer = null;
      lastUnambiguousOffer = null;
    }

    // Avoid the old session + active-trip database round-trip on every 150 ms map poll.
    if (trip != null || assigned) store.observeNormalized(normalized);
    if (assigned || trip != null) CocotaxiOverlayService.clearOffer();
  }

  private int mapSignal = -1;
  private long mapAt;
  private final Runnable poll =
      new Runnable() {
        public void run() {
          if (!destroyed) {
            inspect(null);
            handler.postDelayed(this, 100);
          }
        }
      };

  @Override
  protected void onServiceConnected() {
    instance = this;
    handler.post(poll);
    diagnostic = "Accesibilidad conectada";
  }

  @Override
  public void onAccessibilityEvent(AccessibilityEvent event) {
    if (event == null) return;
    CharSequence pkg = event.getPackageName();
    if (pkg != null && !CABIFY.contentEquals(pkg)) return;
    if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) {
      if (!finishClick(event)) manualClick(event);
    }
    inspect(event);
  }

  private boolean finishClick(AccessibilityEvent e) {
    if (!CABIFY.contentEquals(e.getPackageName() == null ? "" : e.getPackageName())) return false;
    AccessibilityNodeInfo n = e.getSource();
    if (n == null) return false;
    StringBuilder seen = new StringBuilder();
    try {
      if (e.getText() != null)
        for (CharSequence value : e.getText())
          if (value != null) seen.append(' ').append(OfferParser.normalize(value.toString()));
      for (int i = 0; i < 5 && n != null; i++) {
        if (n.getText() != null)
          seen.append(' ').append(OfferParser.normalize(n.getText().toString()));
        if (n.getContentDescription() != null)
          seen.append(' ').append(OfferParser.normalize(n.getContentDescription().toString()));
        // Some Cabify versions put the action label on the clickable parent rather than the leaf.
        // Read only each ancestor's own label; never its whole subtree, otherwise tapping a map
        // control could accidentally see a sibling "Finalizar" button and close the trip.
        AccessibilityNodeInfo parent = n.getParent();
        n.recycle();
        n = parent;
      }
      String text = OfferParser.normalize(seen.toString());
      boolean finish =
          text.contains("finalizar viaje")
              || text.contains("terminar viaje")
              || text.contains("finalizar carrera")
              || text.contains("terminar carrera")
              || text.contains("desliza para finalizar")
              || text.contains("deslizar para finalizar");
      if (!finish) return false;
      CocoStore store = CocoStore.get(this);
      CocoStore.Trip trip = store.activeTrip();
      if (trip != null && "ASIGNADO".equals(trip.status) && store.complete(trip.id)) {
        diagnostic = "Viaje finalizado · servicio detenido";
        CocotaxiOverlayService.clearOffer();
      }
      return true;
    } finally {
      if (n != null) n.recycle();
    }
  }

  private void manualClick(AccessibilityEvent e) {
    if (!CABIFY.contentEquals(e.getPackageName() == null ? "" : e.getPackageName())
        || SystemClock.elapsedRealtime() - clickedAt < 1500) return;
    AccessibilityNodeInfo n = e.getSource();
    if (n == null) return;
    try {
      String label =
          OfferParser.normalize(
                  String.valueOf(n.getText() == null ? n.getContentDescription() : n.getText()))
              .trim();
      if (!label.startsWith("aceptar")) return;
      for (int i = 0; i < 8 && n != null; i++) {
        Offer o = OfferParser.parse(TextCollector.collect(n), CABIFY);
        if (o.hasEnoughForDecision()) {
          SettingsStore.Values v = SettingsStore.load(this);
          CocoStore store = CocoStore.get(this);
          DecisionEngine.Result r =
              DecisionEngine.evaluate(
                  o, v, store.session(), demand(v), store.calibrationForOffer(o.kind, v), PromotionStore.get(this));
          String id = store.attempt(o, r, false);
          if (id != null) {
            store.confirmAccepted(id);
            diagnostic = "Viaje confirmado · en servicio";
          }
          return;
        }
        AccessibilityNodeInfo parent = n.getParent();
        n.recycle();
        n = parent;
      }

      // Very fast Cabify transitions may remove the fare from Accessibility before the click
      // event reaches us. Reuse only a recent unambiguous single offer, never a list.
      long now = SystemClock.elapsedRealtime();
      Offer candidate = null;
      CocoStore.Session session = CocoStore.get(this).session();
      if (recentDetail != null && session.id.equals(detailSession) && now - detailAt <= 5000)
        candidate = recentDetail;
      else if (recentOcrOffer != null && session.id.equals(lastOfferSession) && now - recentOcrAt <= 3000)
        candidate = recentOcrOffer;
      else if (lastUnambiguousOffer != null
          && session.id.equals(lastOfferSession)
          && now - lastUnambiguousAt <= 3000) candidate = lastUnambiguousOffer;
      else if (previous.size() == 1 && now - previousAt <= 3000) candidate = previous.get(0);
      if (candidate != null && candidate.hasEnoughForDecision()) {
        SettingsStore.Values v = SettingsStore.load(this);
        CocoStore store = CocoStore.get(this);
        DecisionEngine.Result r =
            DecisionEngine.evaluate(
                candidate,
                v,
                session,
                demand(v),
                store.calibrationForOffer(candidate.kind, v),
                PromotionStore.get(this));
        String id = store.attempt(candidate, r, false);
        if (id != null) {
          store.confirmAccepted(id);
          diagnostic = "Viaje confirmado · en servicio";
        }
      }
    } finally {
      if (n != null) n.recycle();
    }
  }

  private int demand(SettingsStore.Values v) {
    return DemandModel.level(v, System.currentTimeMillis(), mapSignal, mapAt);
  }

  private CocoStore.Session sessionSnapshot(CocoStore store, boolean forDecision) {
    long now = SystemClock.elapsedRealtime(), revision = store.revision();
    long maxAge = forDecision ? 200L : 750L;
    if (cachedSession == null || cachedRevision != revision || now - cachedSessionAt >= maxAge) {
      cachedSession = store.session();
      cachedSessionAt = now;
      cachedRevision = store.revision();
    }
    return cachedSession;
  }

  private CocoStore.Trip tripSnapshot(CocoStore store, CocoStore.Session session) {
    long now = SystemClock.elapsedRealtime(), revision = store.revision();
    if (cachedTripRevision != revision || now - cachedTripAt >= 750L) {
      cachedTrip = store.activeTrip();
      cachedTripAt = now;
      cachedTripRevision = store.revision();
      // activeTrip() can expire a stale INTENTO; refresh the session revision token if needed.
      if (cachedRevision != store.revision()) cachedSessionAt = 0;
    }
    return cachedTrip;
  }

  private PromotionStore.Snapshot promotionSnapshot(CocoStore store, CocoStore.Session session) {
    long now = SystemClock.elapsedRealtime(), revision = store.revision();
    if (cachedPromo == null || cachedPromoRevision != revision || now - cachedPromoAt >= 1500L) {
      cachedPromo = PromotionStore.get(this, session);
      cachedPromoAt = now;
      cachedPromoRevision = store.revision();
    }
    return cachedPromo;
  }

  private CocoStore.Calibration calibration(CocoStore store, String kind, SettingsStore.Values v) {
    if (v.payoutMode == 3) return store.dailyCalibration();
    if (v.payoutMode == 2) return store.calibration(kind);
    return null;
  }

  public boolean cabifyForeground() {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return false;
    try {
      return CABIFY.contentEquals(root.getPackageName() == null ? "" : root.getPackageName());
    } finally {
      root.recycle();
    }
  }

  private void inspect(AccessibilityEvent event) {
    inspectStartedNs = SystemClock.elapsedRealtimeNanos();
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return;
    try {
      if (!CABIFY.contentEquals(root.getPackageName() == null ? "" : root.getPackageName())) {
        CocotaxiOverlayService.clearOffer();
        stableKey = "";
        return;
      }

      CocoStore store = CocoStore.get(this);
      CocoStore.Session session = sessionSnapshot(store, false);
      if (!session.active || session.paused) {
        CocotaxiOverlayService.clearOffer();
        return;
      }

      try (TextCollector.Snapshot tree = TextCollector.snapshot(root)) {
        String text = tree.text;
        String normalized = OfferParser.normalize(text);
        boolean assigned = AssignmentSignals.isAssignedNormalized(normalized);
        CocoStore.Trip trip = tripSnapshot(store, session);
        observeAssignment(normalized, assigned, store, session, trip);

        if (assigned || OfferParser.isHistoryNormalized(normalized)) {
          CocotaxiOverlayService.clearOffer();
          return;
        }
        if (trip != null) {
          CocotaxiOverlayService.clearOffer();
          if (Build.VERSION.SDK_INT >= 30) requestScreenshot(root.getWindowId());
          return;
        }

        int signal = DemandModel.textSignalNormalized(normalized);
        if (signal >= 0) {
          mapSignal = signal;
          mapAt = System.currentTimeMillis();
        }

        boolean list = tree.isList(normalized);
        boolean hasAccept = tree.hasAccept();

        // Fastest path: one tree scan + one parse + one decision. No UI work occurs before the click.
        if (!list && hasAccept) {
          Offer direct = OfferParser.parseNormalized(text, normalized, CABIFY);
          if (direct.hasEnoughForDecision()) {
            direct.top = tree.acceptBounds.top;
            direct.bottom = tree.acceptBounds.bottom;
            List<Offer> single = Collections.singletonList(direct);
            rememberDetail(single, true);
            previous = single;
            previousAt = SystemClock.elapsedRealtime();
            handleOffers(tree, single, false, false, true, session, false);
            diagnostic = "Oferta detectada al instante";
            return;
          }
          if (recentOcrOffer != null && SystemClock.elapsedRealtime() - recentOcrAt <= 5000) {
            List<Offer> single = Collections.singletonList(recentOcrOffer);
            rememberDetail(single, true);
            handleOffers(tree, single, true, false, true, session, true);
            diagnostic = "Oferta OCR + botón accesible";
            return;
          }
        }

        List<Offer> cards = OfferParser.parseVisibleNormalized(normalized);
        if (cards.isEmpty()) {
          Offer rootOffer = OfferParser.parseNormalized(text, normalized, CABIFY);
          if (rootOffer.hasEnoughForDecision()) cards = Collections.singletonList(rootOffer);
        }
        if (cards.isEmpty()) cards = TextCollector.cards(root);
        if (!cards.isEmpty()) {
          if (cards.size() == 1) cacheUnambiguous(cards.get(0));
          rememberDetail(cards, !list && hasAccept);
          previous = cards;
          previousAt = SystemClock.elapsedRealtime();
          handleOffers(tree, cards, false, list, hasAccept, session, false);
          diagnostic = "Leyendo " + cards.size() + " ofertas visibles";
        } else {
          CocotaxiOverlayService.clearOffer();
          stableKey = "";
          if (Build.VERSION.SDK_INT >= 30) requestScreenshot(root.getWindowId());
          else if (!assigned) diagnostic = "Texto no disponible: activa Captura de respaldo";
        }
      }
    } finally {
      root.recycle();
    }
  }

  private DecisionEngine.Result best(
      List<Offer> cards, SettingsStore.Values v, CocoStore.Session s, int demand,
      PromotionStore.Snapshot promo) {
    CocoStore store = CocoStore.get(this);
    CocoStore.Calibration daily = v.payoutMode == 3 ? store.dailyCalibration() : null;
    Map<String, CocoStore.Calibration> learnedByKind = new HashMap<>();
    List<DecisionEngine.Result> results = new ArrayList<>(cards.size());
    for (Offer o : cards) {
      CocoStore.Calibration learned = null;
      if (v.payoutMode == 3) learned = daily;
      else if (v.payoutMode == 2) {
        learned = learnedByKind.get(o.kind);
        if (learned == null) {
          learned = store.calibration(o.kind);
          learnedByKind.put(o.kind, learned);
        }
      }
      results.add(DecisionEngine.evaluate(o, v, s, demand, learned, promo));
    }
    return OfferRanking.best(results);
  }

  private void handleOffers(
      TextCollector.Snapshot tree, List<Offer> cards, boolean fromOcr, boolean list, boolean hasAccept,
      CocoStore.Session session, boolean requireStable) {
    CocoStore store = CocoStore.get(this);
    // Refresh the session only when a real offer exists; map polling stays on the cheap cache.
    session = sessionSnapshot(store, true);
    SettingsStore.Values v = SettingsStore.load(this);
    int demand = demand(v);
    PromotionStore.Snapshot promo = promotionSnapshot(store, session);
    long decisionStartNs = SystemClock.elapsedRealtimeNanos();
    DecisionEngine.Result result = best(cards, v, session, demand, promo);
    long decisionEndNs = SystemClock.elapsedRealtimeNanos();
    if (result == null) return;

    // Critical ordering: decide -> click Cabify -> persist -> draw overlay. Window rendering must never
    // delay the Accept action.
    lastDispatchNs = 0L;
    int click = maybeClick(tree, cards, v, result, list, hasAccept, requireStable);
    long completedNs = SystemClock.elapsedRealtimeNanos();
    if (result.accept && v.autoAccept && click != CLICK_NONE) {
      long dispatchNs = lastDispatchNs > 0L ? lastDispatchNs : completedNs;
      android.util.Log.i(
          "COCO_PERF",
          "inspect_to_dispatch_ms=" + ((dispatchNs - inspectStartedNs) / 1_000_000.0)
              + " decision_ms=" + ((decisionEndNs - decisionStartNs) / 1_000_000.0)
              + " post_dispatch_ms=" + ((completedNs - dispatchNs) / 1_000_000.0)
              + " click=" + click
              + " ocr=" + fromOcr);
    }
    CocotaxiOverlayService.update(result, cards.indexOf(result.offer) + 1, cards.size(), demand, fromOcr);
    if (click != CLICK_NONE) CocotaxiOverlayService.autoAcceptResult(click == CLICK_SUCCESS);
  }

  private int maybeClick(
      TextCollector.Snapshot tree, List<Offer> cards, SettingsStore.Values v, DecisionEngine.Result r,
      boolean list, boolean hasAccept, boolean requireStable) {
    if (cards.size() != 1 || list || !hasAccept) {
      stableKey = "";
      return CLICK_NONE;
    }
    if (!v.autoAccept || r == null || !r.accept) return CLICK_NONE;

    long now = SystemClock.elapsedRealtime();
    String key = r.offer.key + "@" + r.offer.top;
    if (requireStable) {
      if (!stableKey.equals(key)) {
        stableKey = key;
        stableAt = now;
        return CLICK_NONE;
      }
      if (now - stableAt < 80) return CLICK_NONE;
    } else {
      stableKey = key;
      stableAt = now;
    }
    if (now - clickedAt < 1200
        || now - attemptedKeys.getOrDefault(r.offer.key, -60001L) < 60000) return CLICK_NONE;

    // Reserve the debounce before dispatching: ACTION_CLICK may immediately generate a click event.
    clickedAt = now;
    boolean clicked = tree.clickAccept();
    if (!clicked) clicked = tapAcceptWithGesture(tree.acceptBounds);
    lastDispatchNs = SystemClock.elapsedRealtimeNanos();

    // Persist only after dispatching the click. SQLite must not sit in front of the driver's Accept.
    CocoStore store = CocoStore.get(this);
    String id = store.attempt(r.offer, r, true);
    if (clicked) {
      attemptedKeys.put(r.offer.key, now);
      if (id != null) store.confirmAccepted(id);
      diagnostic = "Viaje confirmado · en servicio";
    } else {
      if (id != null) store.status(id, "SIN BOTÓN ACCESIBLE");
      diagnostic = "Acepta manualmente: botón no accesible";
    }
    if (attemptedKeys.size() > 128)
      attemptedKeys.entrySet().removeIf(e -> now - e.getValue() > 60000L);
    cachedSessionAt = cachedTripAt = 0L;
    stableKey = "";
    return clicked ? CLICK_SUCCESS : CLICK_FAILURE;
  }

  private boolean tapAcceptWithGesture(Rect b) {
    if (Build.VERSION.SDK_INT < 24 || b == null || b.isEmpty()) return false;
    Path path = new Path();
    path.moveTo(b.exactCenterX(), b.exactCenterY());
    GestureDescription gesture =
        new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, 45))
            .build();
    try {
      return dispatchGesture(gesture, null, null);
    } catch (RuntimeException e) {
      return false;
    }
  }

  private void requestScreenshot(int window) {
    long now = SystemClock.elapsedRealtime();
    if (busy || now - ocrAt < 350 || Build.VERSION.SDK_INT < 30) return;
    busy = true;
    ocrAt = now;
    TakeScreenshotCallback cb =
        new TakeScreenshotCallback() {
          public void onSuccess(ScreenshotResult result) {
            Bitmap copy = null, hardware = null;
            HardwareBuffer buffer = result.getHardwareBuffer();
            try {
              hardware = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
              if (hardware != null) copy = hardware.copy(Bitmap.Config.ARGB_8888, false);
            } catch (Exception e) {
              diagnostic = "Captura no disponible";
            } finally {
              if (hardware != null) hardware.recycle();
              buffer.close();
            }
            if (copy == null) {
              busy = false;
              return;
            }
            processBitmap(copy);
          }

          public void onFailure(int error) {
            busy = false;
            diagnostic = "OCR no disponible (" + error + "); usa captura de respaldo";
          }
        };
    try {
      if (Build.VERSION.SDK_INT >= 34) takeScreenshotOfWindow(window, screenshotExecutor, cb);
      else takeScreenshot(Display.DEFAULT_DISPLAY, screenshotExecutor, cb);
    } catch (Exception e) {
      busy = false;
    }
  }

  public void processBitmap(Bitmap bitmap) {
    if (Looper.myLooper() != Looper.getMainLooper()) {
      handler.post(() -> processBitmap(bitmap));
      return;
    }
    if (destroyed || processing || !cabifyForeground()) {
      bitmap.recycle();
      busy = false;
      return;
    }
    processing = true;
    final String captureSession = sessionSnapshot(CocoStore.get(this), false).id;
    if (ocr == null) ocr = new ScreenOcrEngine();
    ocr.process(
        bitmap,
        new ScreenOcrEngine.Callback() {
          public void onText(String text) {
            try {
              CocoStore store = CocoStore.get(CocotaxiAccessibilityService.this);
              CocoStore.Session s = sessionSnapshot(store, false);
              if (!destroyed
                  && s.active
                  && !s.paused
                  && s.id.equals(captureSession)
                  && cabifyForeground()) {
                String normalized = OfferParser.normalize(text);
                SettingsStore.Values settings = SettingsStore.load(CocotaxiAccessibilityService.this);
                if (settings.mapDemand) {
                  int signal = DemandModel.textSignalNormalized(normalized);
                  if (signal >= 0) {
                    mapSignal = signal;
                    mapAt = System.currentTimeMillis();
                  }
                  sampleMap(bitmap, normalized);
                }
                boolean assigned = AssignmentSignals.isAssignedNormalized(normalized);
                CocoStore.Trip trip = tripSnapshot(store, s);
                observeAssignment(normalized, assigned, store, s, trip);
                if (assigned || trip != null) {
                  CocotaxiOverlayService.clearOffer();
                  return;
                }
                List<Offer> cards = OfferParser.parseVisibleNormalized(normalized);
                if (!cards.isEmpty()) {
                  if (cards.size() == 1) {
                    recentOcrOffer = cards.get(0);
                    recentOcrAt = SystemClock.elapsedRealtime();
                    cacheUnambiguous(recentOcrOffer);
                  }
                  rememberDetail(
                      cards,
                      cards.size() == 1
                          && normalized.contains("aceptar")
                          && !normalized.contains("viajes disponibles"));
                  int demand = demand(settings);
                  PromotionStore.Snapshot promo = promotionSnapshot(store, s);
                  DecisionEngine.Result result = best(cards, settings, s, demand, promo);
                  if (result != null)
                    CocotaxiOverlayService.update(
                        result, cards.indexOf(result.offer) + 1, cards.size(), demand, true);
                  diagnostic = "OCR: " + cards.size() + " ofertas";
                }
              }
            } finally {
              bitmap.recycle();
              busy = false;
              processing = false;
            }
          }

          public void onError(Exception e) {
            bitmap.recycle();
            busy = false;
            processing = false;
            diagnostic = "OCR: no se pudo leer";
          }
        });
  }

  private void sampleMap(Bitmap b, String normalized) {
    // Experimental visual signal only increases selectivity; never modifies predicted fare.
    if (!DemandModel.isMapScreenNormalized(normalized)) return;
    int red = 0, yellow = 0, total = 0;
    float[] hsv = new float[3];
    for (int y = b.getHeight() / 5; y < b.getHeight() * 3 / 5; y += 12)
      for (int x = b.getWidth() / 6; x < b.getWidth() * 5 / 6; x += 12) {
        android.graphics.Color.colorToHSV(b.getPixel(x, y), hsv);
        total++;
        if (hsv[1] > .55 && hsv[2] > .55) {
          if (hsv[0] < 20 || hsv[0] > 345) red++;
          if (hsv[0] > 35 && hsv[0] < 65) yellow++;
        }
      }
    if (total > 0 && (red / (double) total > .08 || yellow / (double) total > .15)) {
      int signal = red / (double) total > .08 ? 3 : 2;
      mapSignal = Math.max(signal, DemandModel.textSignalNormalized(normalized));
      mapAt = System.currentTimeMillis();
    }
  }

  @Override
  public void onInterrupt() {
    CocotaxiOverlayService.clearOffer();
  }

  @Override
  public void onDestroy() {
    destroyed = true;
    handler.removeCallbacksAndMessages(null);
    instance = null;
    if (ocr != null) ocr.close();
    screenshotExecutor.shutdownNow();
    CocotaxiOverlayService.clearOffer();
    super.onDestroy();
  }
}
