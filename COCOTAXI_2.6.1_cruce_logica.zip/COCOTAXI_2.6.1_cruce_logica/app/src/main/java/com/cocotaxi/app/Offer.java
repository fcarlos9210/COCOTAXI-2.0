package com.cocotaxi.app;

public final class Offer {
  public String kind = "UNKNOWN", warning = "", key = "";
  public int top, bottom;
  public String platform = "Plataforma";
  public String rawText = "";
  public double fare = -1.0;
  public double pickupKm = -1.0;
  public double pickupMin = -1.0;
  public double tripKm = -1.0;
  public double tripMin = -1.0;
  public double tolls = 0.0;
  public boolean hasOfferSignal;

  public boolean hasFare() {
    return Double.isFinite(fare) && fare > 0.0;
  }

  public boolean hasPickup() {
    return Double.isFinite(pickupMin) && pickupMin >= 0.0;
  }

  public boolean hasTrip() {
    return Double.isFinite(tripMin) && tripMin > 0.0;
  }

  public boolean hasEnoughForDecision() {
    return hasOfferSignal && warning.isEmpty() && hasFare() && hasPickup() && hasTrip();
  }

  public double totalKm() {
    double total = 0.0;
    if (pickupKm > 0.0) total += pickupKm;
    if (tripKm > 0.0) total += tripKm;
    return total;
  }

  public double totalMinutes() {
    double total = 0.0;
    if (pickupMin > 0.0) total += pickupMin;
    if (tripMin > 0.0) total += tripMin;
    return total;
  }

  public String missingSummary() {
    StringBuilder builder = new StringBuilder();
    if (!hasFare()) append(builder, "monto");
    if (!hasPickup()) append(builder, "recogida");
    if (!hasTrip()) append(builder, "viaje");
    if (builder.length() == 0) return "sin faltantes";
    return builder.toString();
  }

  private static void append(StringBuilder builder, String value) {
    if (builder.length() > 0) builder.append(", ");
    builder.append(value);
  }
}
