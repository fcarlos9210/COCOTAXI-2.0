package com.cocotaxi.app;

import android.graphics.Bitmap;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

/** OCR on-device como respaldo de Accessibility. */
public final class ScreenOcrEngine {
  public interface Callback {
    void onText(String text);

    void onError(Exception error);
  }

  private final TextRecognizer recognizer =
      TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

  public void process(Bitmap bitmap, final Callback callback) {
    if (bitmap == null) {
      callback.onError(new IllegalArgumentException("Bitmap nulo"));
      return;
    }
    try {
      InputImage image = InputImage.fromBitmap(bitmap, 0);
      recognizer
          .process(image)
          .addOnSuccessListener(result -> callback.onText(flatten(result)))
          .addOnFailureListener(callback::onError);
    } catch (Exception e) {
      callback.onError(e);
    }
  }

  public void close() {
    recognizer.close();
  }

  private String flatten(Text result) {
    StringBuilder sb = new StringBuilder();
    java.util.List<Text.Line> lines = new java.util.ArrayList<>();
    for (Text.TextBlock block : result.getTextBlocks()) lines.addAll(block.getLines());
    lines.sort(
        (a, b) -> {
          android.graphics.Rect x = a.getBoundingBox(), y = b.getBoundingBox();
          if (x == null || y == null) return 0;
          return x.top == y.top ? Integer.compare(x.left, y.left) : Integer.compare(x.top, y.top);
        });
    for (Text.Line line : lines) {
      if (sb.length() > 0) sb.append('\n');
      sb.append(line.getText());
    }
    return sb.toString();
  }
}
