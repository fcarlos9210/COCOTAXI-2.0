package com.cocotaxi.app;

import java.time.*;
import java.util.regex.Pattern;

public final class DemandModel {
  private static final Pattern BADGE =
      Pattern.compile("\\+\\s*[1-6]0\\s*%|\\bx\\s*(1[.,][1-6]|[1-6]0)\\b");

  private DemandModel() {}

  public static int level(SettingsStore.Values v, long now, int signal, long signalAt) {
    if (v.demandMode != 0) return v.demandMode == 1 ? 3 : v.demandMode == 3 ? 1 : 2;
    ZonedDateTime z = Instant.ofEpochMilli(now).atZone(CocoStore.ZONE);
    int hour = z.getHour(), day = z.getDayOfWeek().getValue();
    int base =
        inRange(hour, v.deadStart, v.deadEnd)
            ? 0
            : (day == 5 || day == 6) && inRange(hour, v.peakStart, v.peakEnd)
                ? 3
                : day == 4 || day == 7 ? 2 : 1;
    return v.mapDemand && now - signalAt < 30000 && now >= signalAt ? Math.max(base, signal) : base;
  }

  public static boolean inRange(int hour, int start, int end) {
    return start == end
        ? false
        : start < end ? hour >= start && hour < end : hour >= start || hour < end;
  }

  public static String name(int level) {
    return new String[] {"MUERTA", "BAJA", "MEDIA", "ALTA"}[Math.max(0, Math.min(3, level))];
  }

  public static int textSignal(String raw) {
    return textSignalNormalized(OfferParser.normalize(raw));
  }

  public static int textSignalNormalized(String t) {
    if (!isMapScreenNormalized(t)) return -1;
    for (String line : t.split("\\n")) {
      if (line.contains("bono")
          || line.contains("extra")
          || line.contains("incentivo")
          || line.contains("propina")
          || line.contains("comision")
          || line.contains("descuento")) continue;
      if (BADGE.matcher(line).find()) return 3;
    }
    return -1;
  }

  public static boolean isMapScreen(String raw) {
    return isMapScreenNormalized(OfferParser.normalize(raw));
  }

  public static boolean isMapScreenNormalized(String t) {
    if (t == null) return false;
    if (t.contains("historial")
        || t.contains("total ganancias")
        || t.contains("precio base")
        || t.contains("total a cobrar")
        || t.contains("comision reducida")
        || t.contains("aceptar")) return false;
    return t.contains("mapa")
        || t.contains("mapa de demanda")
        || t.contains("buscando viajes")
        || t.contains("viajes disponibles para ti");
  }
}
