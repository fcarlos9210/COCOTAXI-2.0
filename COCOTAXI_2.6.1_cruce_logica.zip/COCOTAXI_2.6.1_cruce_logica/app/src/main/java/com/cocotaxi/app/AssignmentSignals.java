package com.cocotaxi.app;

/** Assignment evidence from Cabify's pickup/service screens, never from an offer card. */
public final class AssignmentSignals {
  private AssignmentSignals() {}

  public static boolean isAssigned(String raw) {
    return isAssignedNormalized(OfferParser.normalize(raw));
  }

  public static boolean isAssignedNormalized(String text) {
    if (text == null) return false;
    if (OfferParser.isHistoryNormalized(text)
        || text.contains("aceptar")
        || text.contains("viaje cancelado")
        || text.contains("otro conductor")
        || text.contains("no se pudo aceptar")
        || text.contains("error al aceptar")
        || text.contains("ya no esta disponible")) return false;

    boolean classic =
        (text.contains("ir a origen") || text.contains("ir al origen"))
            && (text.contains("navegar") || text.contains("ver ruta"));
    boolean pickup =
        text.contains("ir a recoger")
            || text.contains("recoger al pasajero")
            || text.contains("he llegado")
            || text.contains("llegue al origen")
            || text.contains("iniciar viaje")
            || text.contains("desliza para iniciar")
            || text.contains("en camino al origen")
            || text.contains("esperando al pasajero")
            || text.contains("punto de recogida")
            || text.contains("dirigete al origen")
            || text.contains("dirigete al punto de recogida")
            || text.contains("contactar pasajero")
            || text.contains("llamar al pasajero")
            || text.contains("cancelar viaje");
    boolean service =
        text.contains("finalizar viaje")
            || text.contains("terminar viaje")
            || text.contains("destino del pasajero")
            || text.contains("viaje en curso")
            || text.contains("viaje iniciado")
            || text.contains("ruta al destino");
    return classic || pickup || service;
  }
}
