package com.cocotaxi.app;

/** Pure planner. Credits are conditional, never ledger income or a learned probability. */
public final class PromotionMath {
  public static final class Plan {
    public boolean feasible;
    public double credit, hourly, requiredCycle, margin;
  }
  public static Plan plan(int remaining, double bonus, double leftMinutes,
      double candidateMinutes, double futureCycle, double net, double floor) {
    Plan p = new Plan();
    if (remaining < 1 || !Double.isFinite(bonus) || bonus <= 0
        || !Double.isFinite(leftMinutes) || !Double.isFinite(candidateMinutes)
        || !Double.isFinite(futureCycle) || !Double.isFinite(net) || !Double.isFinite(floor)
        || candidateMinutes <= 0 || futureCycle <= 0 || floor <= 0) return p;
    double buffer = Math.max(5, leftMinutes * .10);
    double available = leftMinutes - buffer;
    p.requiredCycle = available / remaining;
    double needed = candidateMinutes + (remaining - 1) * futureCycle;
    p.margin = available - needed;
    if (p.margin < 0) return p;
    // Only 60–85% of the conditional reward contributes; this is a risk discount,
    // not a statistically calibrated chance. No reward is actually booked here.
    double discount = .60 + .25 * Math.min(1, p.margin / Math.max(1, needed));
    p.credit = bonus * discount / remaining;
    p.hourly = (net + p.credit) * 60 / candidateMinutes;
    p.feasible = p.hourly >= floor;
    return p;
  }
  public static double requiredHourly(double dailyGoal, double hours, double elapsedMinutes, double money) {
    double left = hours * 60 - elapsedMinutes;
    return left > 0 ? Math.max(0, dailyGoal - money) * 60 / left : 0;
  }
}
