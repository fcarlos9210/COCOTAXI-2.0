package com.cocotaxi.app;

import java.util.List;

public final class OfferRanking {
  public static DecisionEngine.Result best(List<DecisionEngine.Result> results) {
    DecisionEngine.Result best = null;
    for (DecisionEngine.Result r : results)
      if (best == null
          || r.accept && !best.accept
          || r.accept == best.accept && Math.max(r.score,r.hourly) > Math.max(best.score,best.hourly)) best = r;
    return best;
  }
}
