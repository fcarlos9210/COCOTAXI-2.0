package com.cocotaxi.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Local optional startup PIN. The PIN itself is never stored in plaintext. */
public final class PinStore {
  private static final String PREFS = "cocotaxi_security";
  private static final String SALT = "pin_salt";
  private static final String HASH = "pin_hash";
  private static final String FAILS = "pin_failures";
  private static final String LOCK_UNTIL = "pin_lock_until";
  private static final int ITERATIONS = 120_000;
  private static final int KEY_BITS = 256;

  private PinStore() {}

  private static SharedPreferences prefs(Context c) {
    return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
  }

  public static boolean enabled(Context c) {
    SharedPreferences p = prefs(c);
    return p.contains(SALT) && p.contains(HASH);
  }

  public static void set(Context c, String pin) {
    validateFormat(pin);
    byte[] salt = new byte[16];
    new SecureRandom().nextBytes(salt);
    byte[] hash = derive(pin, salt);
    prefs(c)
        .edit()
        .putString(SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
        .putString(HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
        .putInt(FAILS, 0)
        .putLong(LOCK_UNTIL, 0)
        .apply();
  }

  public static boolean verify(Context c, String pin) {
    if (!enabled(c)) return true;
    SharedPreferences p = prefs(c);
    long now = System.currentTimeMillis();
    if (p.getLong(LOCK_UNTIL, 0) > now) return false;
    try {
      byte[] salt = Base64.decode(p.getString(SALT, ""), Base64.NO_WRAP);
      byte[] expected = Base64.decode(p.getString(HASH, ""), Base64.NO_WRAP);
      boolean ok = MessageDigest.isEqual(expected, derive(pin == null ? "" : pin, salt));
      if (ok) {
        p.edit().putInt(FAILS, 0).putLong(LOCK_UNTIL, 0).apply();
      } else {
        int failures = p.getInt(FAILS, 0) + 1;
        SharedPreferences.Editor e = p.edit().putInt(FAILS, failures);
        if (failures >= 5) {
          e.putLong(LOCK_UNTIL, now + 30_000L).putInt(FAILS, 0);
        }
        e.apply();
      }
      return ok;
    } catch (RuntimeException ex) {
      return false;
    }
  }

  public static long secondsLocked(Context c) {
    long remaining = prefs(c).getLong(LOCK_UNTIL, 0) - System.currentTimeMillis();
    return remaining <= 0 ? 0 : (remaining + 999) / 1000;
  }

  public static void clear(Context c) {
    prefs(c).edit().clear().apply();
  }

  public static void validateFormat(String pin) {
    if (pin == null || !pin.matches("\\d{4,6}"))
      throw new IllegalArgumentException("El PIN debe tener entre 4 y 6 números");
  }

  private static byte[] derive(String pin, byte[] salt) {
    try {
      PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_BITS);
      try {
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
      } finally {
        spec.clearPassword();
      }
    } catch (Exception e) {
      throw new IllegalStateException("No se pudo proteger el PIN", e);
    }
  }
}
