package com.cocotaxi.app;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;

public final class TextCollector {
  private TextCollector() {}

  /**
   * One-pass snapshot of the active accessibility tree.
   *
   * <p>The old hot path walked the same tree several times just to collect text, count Accept
   * buttons, locate the Accept bounds and finally click it. Cabify offer screens are short-lived,
   * so the service now captures those facts together in one traversal and reuses them until the
   * decision is made.
   */
  public static final class Snapshot implements AutoCloseable {
    public final String text;
    public final int acceptCount;
    public final Rect acceptBounds;
    private AccessibilityNodeInfo acceptAction;

    private Snapshot(String text, int acceptCount, Rect acceptBounds, AccessibilityNodeInfo action) {
      this.text = text;
      this.acceptCount = acceptCount;
      this.acceptBounds = acceptBounds == null ? new Rect() : new Rect(acceptBounds);
      this.acceptAction = action;
    }

    public boolean hasAccept() {
      return acceptCount > 0;
    }

    public boolean isList(String normalizedText) {
      String text = normalizedText == null ? "" : normalizedText;
      return text.contains("viajes disponibles")
          || text.contains("lista de viajes")
          || acceptCount > 1;
    }

    /** Click the already-resolved clickable Accept ancestor without walking the tree again. */
    public boolean clickAccept() {
      AccessibilityNodeInfo node = acceptAction;
      return node != null
          && node.isVisibleToUser()
          && node.isEnabled()
          && node.isClickable()
          && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    @Override
    public void close() {
      if (acceptAction != null) {
        acceptAction.recycle();
        acceptAction = null;
      }
    }
  }

  private static final class ScanState {
    final StringBuilder text = new StringBuilder(512);
    int visited;
    int acceptCount;
    Rect acceptBounds;
    AccessibilityNodeInfo acceptAction;
  }

  public static Snapshot snapshot(AccessibilityNodeInfo root) {
    ScanState state = new ScanState();
    walkSnapshot(root, state, 0);
    return new Snapshot(state.text.toString(), state.acceptCount, state.acceptBounds, state.acceptAction);
  }

  private static void walkSnapshot(AccessibilityNodeInfo n, ScanState state, int depth) {
    if (n == null || depth > 30 || state.visited++ > 600 || !n.isVisibleToUser()) return;

    CharSequence t = n.getText(), d = n.getContentDescription();
    if (t != null && !isBlank(t)) state.text.append(t).append('\n');
    else if (d != null && !isBlank(d)) state.text.append(d).append('\n');

    if (isAcceptLabelFast(n)) {
      state.acceptCount++;
      if (state.acceptBounds == null) captureAcceptTarget(n, state);
    }

    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        walkSnapshot(c, state, depth + 1);
        c.recycle();
      }
    }
  }

  private static boolean isBlank(CharSequence value) {
    int length = value.length();
    for (int i = 0; i < length; i++) if (!Character.isWhitespace(value.charAt(i))) return false;
    return true;
  }

  /** Accept labels contain no accents, so avoid full Unicode normalization for every node. */
  private static boolean isAcceptLabelFast(AccessibilityNodeInfo n) {
    if (n == null || !n.isVisibleToUser()) return false;
    CharSequence raw = n.getText() != null ? n.getText() : n.getContentDescription();
    if (raw == null) return false;
    String t = raw.toString().trim();
    return "aceptar".equalsIgnoreCase(t)
        || "aceptar viaje".equalsIgnoreCase(t)
        || "aceptar carrera".equalsIgnoreCase(t);
  }

  /** Resolve the clickable ancestor and gesture bounds once, while the tree is fresh. */
  private static void captureAcceptTarget(AccessibilityNodeInfo n, ScanState state) {
    AccessibilityNodeInfo cur = AccessibilityNodeInfo.obtain(n);
    Rect fallback = new Rect();
    try {
      for (int i = 0; i < 5 && cur != null; i++) {
        if (cur.isVisibleToUser() && cur.isEnabled()) {
          Rect b = new Rect();
          cur.getBoundsInScreen(b);
          if (!b.isEmpty()) fallback.set(b);
          if (cur.isClickable()) {
            state.acceptAction = AccessibilityNodeInfo.obtain(cur);
            if (!b.isEmpty()) state.acceptBounds = new Rect(b);
            break;
          }
        }
        AccessibilityNodeInfo parent = cur.getParent();
        cur.recycle();
        cur = parent;
      }
      if (state.acceptBounds == null && !fallback.isEmpty()) state.acceptBounds = new Rect(fallback);
    } finally {
      if (cur != null) cur.recycle();
    }
  }

  public static String collect(AccessibilityNodeInfo root) {
    try (Snapshot s = snapshot(root)) {
      return s.text;
    }
  }

  public static List<Offer> cards(AccessibilityNodeInfo root) {
    List<Offer> out = new ArrayList<>();
    walkCards(root, out, 0, new int[] {0});
    out.sort(Comparator.comparingInt(o -> o.top));
    return out;
  }

  private static void walkCards(AccessibilityNodeInfo n, List<Offer> out, int depth, int[] count) {
    if (n == null || !n.isVisibleToUser() || depth > 25 || count[0]++ > 500) return;
    Offer o = OfferParser.parse(collect(n), "com.cabify.driver");
    if (o.hasEnoughForDecision()) {
      Rect b = new Rect();
      n.getBoundsInScreen(b);
      o.top = b.top;
      o.bottom = b.bottom;
      boolean duplicate = false;
      for (Offer a : out) if (a.key.equals(o.key) && a.top == o.top) duplicate = true;
      if (!duplicate) out.add(o);
      return;
    }
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        walkCards(c, out, depth + 1, count);
        c.recycle();
      }
    }
  }

  public static boolean isList(AccessibilityNodeInfo root) {
    try (Snapshot s = snapshot(root)) {
      return s.isList(OfferParser.normalize(s.text));
    }
  }

  public static boolean isList(AccessibilityNodeInfo root, String normalizedText) {
    try (Snapshot s = snapshot(root)) {
      return s.isList(normalizedText);
    }
  }

  public static boolean hasAccept(AccessibilityNodeInfo root) {
    try (Snapshot s = snapshot(root)) {
      return s.hasAccept();
    }
  }

  /** Fast click for a verified single-offer detail screen. */
  public static boolean clickAccept(AccessibilityNodeInfo root) {
    try (Snapshot s = snapshot(root)) {
      return s.clickAccept();
    }
  }

  /** Bounds used as a gesture fallback when Cabify exposes the label but not ACTION_CLICK. */
  public static Rect acceptBounds(AccessibilityNodeInfo root) {
    try (Snapshot s = snapshot(root)) {
      return new Rect(s.acceptBounds);
    }
  }

  public static boolean clickOffer(AccessibilityNodeInfo root, Offer wanted) {
    return clickAccept(root);
  }
}
