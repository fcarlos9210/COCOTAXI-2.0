package com.cocotaxi.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;

/** Explicit MediaProjection fallback; Android owns the consent dialog. */
public final class CaptureService extends Service {
  private MediaProjection projection;
  private VirtualDisplay display;
  private ImageReader reader;
  private long last;
  private final Handler handler = new Handler(Looper.getMainLooper());
  private HandlerThread frameThread;
  private Handler frameHandler;

  @Override
  public int onStartCommand(Intent i, int flags, int id) {
    if (i != null && "STOP".equals(i.getAction())) {
      stopSelf();
      return START_NOT_STICKY;
    }
    if (i == null || projection != null) return START_NOT_STICKY;
    NotificationManager nm = getSystemService(NotificationManager.class);
    nm.createNotificationChannel(
        new NotificationChannel(
            "coco_capture", "Captura de respaldo", NotificationManager.IMPORTANCE_LOW));
    PendingIntent stop =
        PendingIntent.getService(
            this,
            2,
            new Intent(this, CaptureService.class).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE);
    if ("STOP".equals(i.getAction())) {
      stopSelf();
      return START_NOT_STICKY;
    }
    startForeground(
        102,
        new Notification.Builder(this, "coco_capture")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("COCO: captura de respaldo")
            .setContentText("Solo procesa Cabify durante una sesión")
            .addAction(new Notification.Action.Builder(null, "Detener", stop).build())
            .build());
    try {
      Intent data = i.getParcelableExtra("data");
      if (data == null) {
        stopSelf();
        return START_NOT_STICKY;
      }
      projection =
          getSystemService(MediaProjectionManager.class)
              .getMediaProjection(i.getIntExtra("code", Activity.RESULT_CANCELED), data);
      projection.registerCallback(
          new MediaProjection.Callback() {
            @Override
            public void onStop() {
              stopSelf();
            }
          },
          handler);
      android.util.DisplayMetrics m = getResources().getDisplayMetrics();
      int width = m.widthPixels, height = m.heightPixels;
      frameThread = new HandlerThread("CocoCaptureFrames", android.os.Process.THREAD_PRIORITY_BACKGROUND);
      frameThread.start();
      frameHandler = new Handler(frameThread.getLooper());
      reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
      reader.setOnImageAvailableListener(
          r -> {
            Image image = r.acquireLatestImage();
            if (image == null) return;
            try {
              CocotaxiAccessibilityService a = CocotaxiAccessibilityService.instance;
              long now = SystemClock.elapsedRealtime();
              // ImageReader can fire at display refresh rate. Throttle before touching SQLite or
              // Accessibility so backup capture cannot compete with the offer hot path.
              if (a == null || now - last < 350) return;
              CocoStore.Session s = CocoStore.get(this).session();
              if (!s.active || s.paused || !a.cabifyForeground()) return;
              last = now;
              Image.Plane p = image.getPlanes()[0];
              int stride = p.getPixelStride(),
                  padding = p.getRowStride() - stride * image.getWidth();
              Bitmap padded =
                  Bitmap.createBitmap(
                      image.getWidth() + padding / stride,
                      image.getHeight(),
                      Bitmap.Config.ARGB_8888);
              padded.copyPixelsFromBuffer(p.getBuffer());
              Bitmap bitmap =
                  Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
              if (bitmap != padded) padded.recycle();
              a.processBitmap(bitmap);
            } finally {
              image.close();
            }
          },
          frameHandler);
      display =
          projection.createVirtualDisplay(
              "CocoCapture",
              width,
              height,
              m.densityDpi,
              DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
              reader.getSurface(),
              null,
              frameHandler);
    } catch (RuntimeException e) {
      CocotaxiAccessibilityService.diagnostic = "Captura no iniciada; vuelve a autorizar";
      stopSelf();
    }
    return START_NOT_STICKY;
  }

  @Override
  public IBinder onBind(Intent i) {
    return null;
  }

  @Override
  public void onDestroy() {
    if (display != null) display.release();
    if (reader != null) reader.close();
    if (projection != null) {
      MediaProjection p = projection;
      projection = null;
      p.stop();
    }
    handler.removeCallbacksAndMessages(null);
    if (frameHandler != null) frameHandler.removeCallbacksAndMessages(null);
    if (frameThread != null) frameThread.quitSafely();
    super.onDestroy();
  }
}
