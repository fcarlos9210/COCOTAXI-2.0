package com.cocotaxi.app;

import android.content.*;

/** Preserve the old aggregate as an explicitly unverified legacy session. */
public final class LegacyImport {
  public static void run(Context c) {
    SharedPreferences p = c.getSharedPreferences(SettingsStore.PREFS, 0);
    if (p.getBoolean("v3_imported", false)) return;
    long start = p.getLong("session_started_at", 0);
    double income = Double.longBitsToDouble(p.getLong("session_accumulated", 0));
    if (start > 0 && Double.isFinite(income) && income != 0) {
      CocoStore st = CocoStore.get(c);
      android.database.sqlite.SQLiteDatabase d = st.getWritableDatabase();
      d.beginTransaction();
      try {
        long end = p.getLong("session_ended_at", 0);
        if (end <= 0) end = start;
        long duration = Math.max(0, end - start - p.getLong("session_paused_ms", 0));
        ContentValues s = new ContentValues();
        s.put("id", "legacy-226");
        s.put("start", start);
        s.put("end", end);
        s.put("active", 0);
        s.put("paused", 0);
        s.put("elapsed", 0);
        s.put("wall", end);
        s.put("boot", 0);
        s.put("ms", duration);
        d.insertWithOnConflict(
            "sessions", null, s, android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE);
        ContentValues t = new ContentValues();
        t.put("id", "legacy-total-226");
        t.put("session", "legacy-226");
        t.put("at", end);
        t.put("status", "FINALIZADO");
        t.put("offered", 0);
        t.put("kind", "UNKNOWN");
        t.put("estimate", Money.cents(income));
        t.put("cost", 0);
        t.put("minutes", 0);
        t.put("trip", 0);
        t.put("label", "Total importado de 2.2.6; no es un viaje individual. Revisa el monto.");
        d.insertWithOnConflict(
            "trips", null, t, android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE);
        d.setTransactionSuccessful();
      } finally {
        d.endTransaction();
      }
    }
    p.edit().putBoolean("v3_imported", true).apply();
  }
}
