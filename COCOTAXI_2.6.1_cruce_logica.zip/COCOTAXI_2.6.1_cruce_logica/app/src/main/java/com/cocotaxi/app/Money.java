package com.cocotaxi.app;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

public final class Money {
  public static long cents(double n) {
    if (!Double.isFinite(n)) throw new IllegalArgumentException("Importe no válido");
    return BigDecimal.valueOf(n)
        .movePointRight(2)
        .setScale(0, RoundingMode.HALF_UP)
        .longValueExact();
  }

  public static double round(double n) {
    return cents(n) / 100.0;
  }

  public static double parse(String s) {
    if (s == null) return Double.NaN;
    String t = s.replaceAll("[^0-9.,-]", "");
    int comma = t.lastIndexOf(','), dot = t.lastIndexOf('.');
    if (comma >= 0 && dot >= 0)
      t = comma > dot ? t.replace(".", "").replace(',', '.') : t.replace(",", "");
    else if (comma >= 0) t = t.replace(',', '.');
    else if (dot >= 0 && t.length() - dot - 1 == 3) t = t.replace(".", "");
    try {
      return Double.parseDouble(t);
    } catch (Exception e) {
      return Double.NaN;
    }
  }

  public static double metric(String s) {
    try {
      return Double.parseDouble(s.replace(',', '.'));
    } catch (Exception e) {
      return Double.NaN;
    }
  }

  public static String format(double n) {
    NumberFormat f = NumberFormat.getNumberInstance(Locale.forLanguageTag("es-UY"));
    f.setMaximumFractionDigits(0);
    return "$" + f.format(n);
  }

  public static String exact(double n) {
    NumberFormat f = NumberFormat.getNumberInstance(Locale.forLanguageTag("es-UY"));
    f.setMinimumFractionDigits(2);
    f.setMaximumFractionDigits(2);
    return "$" + f.format(n);
  }
}
