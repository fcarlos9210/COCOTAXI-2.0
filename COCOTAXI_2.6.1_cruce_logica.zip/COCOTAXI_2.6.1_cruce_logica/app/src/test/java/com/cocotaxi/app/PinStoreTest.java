package com.cocotaxi.app;

import static org.junit.Assert.*;

import android.content.Context;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class PinStoreTest {
  private Context context;

  @Before
  public void setup() {
    context = RuntimeEnvironment.getApplication();
    PinStore.clear(context);
  }

  @After
  public void cleanup() {
    PinStore.clear(context);
  }

  @Test
  public void pinIsOptionalAndCanBeEnabled() {
    assertFalse(PinStore.enabled(context));
    PinStore.set(context, "2580");
    assertTrue(PinStore.enabled(context));
    assertTrue(PinStore.verify(context, "2580"));
    assertFalse(PinStore.verify(context, "1111"));
  }

  @Test
  public void invalidPinFormatRejected() {
    assertThrows(IllegalArgumentException.class, () -> PinStore.set(context, "123"));
    assertThrows(IllegalArgumentException.class, () -> PinStore.set(context, "1234567"));
    assertThrows(IllegalArgumentException.class, () -> PinStore.set(context, "12a4"));
  }

  @Test
  public void fiveFailuresTemporarilyLockVerification() {
    PinStore.set(context, "2580");
    for (int i = 0; i < 5; i++) assertFalse(PinStore.verify(context, "0000"));
    assertTrue(PinStore.secondsLocked(context) > 0);
    assertFalse(PinStore.verify(context, "2580"));
  }

  @Test
  public void clearDisablesPin() {
    PinStore.set(context, "2580");
    PinStore.clear(context);
    assertFalse(PinStore.enabled(context));
    assertTrue(PinStore.verify(context, "anything"));
  }
}
