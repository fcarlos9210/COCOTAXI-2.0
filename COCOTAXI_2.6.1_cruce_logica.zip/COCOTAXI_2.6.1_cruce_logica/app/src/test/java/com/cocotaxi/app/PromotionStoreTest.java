package com.cocotaxi.app;
import static org.junit.Assert.*;
import android.content.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=34)
public class PromotionStoreTest {
 private Context c;
 private CocoStore store;
 @Before public void setup() {
  c=RuntimeEnvironment.getApplication(); CocoStore.closeForTests();
  c.deleteDatabase("cocotaxi_v3.db"); PromotionStore.clear(c);
  store=CocoStore.get(c);store.start();
 }
 @After public void finish() {CocoStore.closeForTests();}
 private void promo(int done) {
  long now=System.currentTimeMillis();
  PromotionStore.set(c,13,1100,now-60000,now+4*3600000L,done);
 }
 @Test public void completedTripsOnlyAndBonusDoesNotCount() {
  promo(0);store.manual(150,10,"Viaje",true);store.manual(1100,0,"Premio",false);
  assertEquals(1,PromotionStore.get(c).completed);
 }
 @Test public void deleteAndRestoreChangeCount() {
  promo(0);String id=store.manual(150,10,"Viaje",true);
  store.delete(id);assertEquals(0,PromotionStore.get(c).completed);
  store.restore(id);assertEquals(1,PromotionStore.get(c).completed);
 }
 @Test public void manualBaselineDoesNotDoubleCountExistingTrips() {
  store.manual(150,10,"Viaje",true);promo(5);
  assertEquals(5,PromotionStore.get(c).completed);
  store.manual(150,10,"Viaje",true);
  assertEquals(6,PromotionStore.get(c).completed);
 }
 @Test public void nextSessionDoesNotInheritPromotion() {
  promo(5);store.stop();store.start();
  assertEquals(0,PromotionStore.get(c).target);
 }
 @Test public void promotionCanBePreparedWhileDisconnectedAndBindsToNextSession() {
  store.stop();
  long now=System.currentTimeMillis();
  PromotionStore.add(c,10,900,now-60000,now+4*3600000L,2);
  assertEquals(10,PromotionStore.get(c).target);
  assertEquals(2,PromotionStore.get(c).completed);
  store.start();
  assertEquals(10,PromotionStore.get(c).target);
  assertEquals(2,PromotionStore.get(c).completed);
 }
 @Test public void endIsExclusive() {
  promo(0);String id=store.manual(150,10,"Viaje",true);
  ContentValues values=new ContentValues();values.put("at",PromotionStore.get(c).end);
  store.getWritableDatabase().update("trips",values,"id=?",new String[]{id});
  assertEquals(0,PromotionStore.get(c).completed);
 }
 @Test public void savingGoalsKeepsOnlySelectedSource() {
  SettingsStore.Values v=new SettingsStore.Values();v.goalMode=0;v.weeklyGoal=33000;
  v.targetHoursDay=11;v.workDaysMask=63;SettingsStore.save(c,v);
  SettingsStore.Values loaded=SettingsStore.load(c);
  assertEquals(5500,loaded.dailyGoal,.001);assertEquals(500,loaded.realGoalHour,.001);
 assertEquals(loaded.realGoalHour,loaded.operationalGoalHour,0);
 }
 @Test public void eachWorkDayKeepsItsOwnHours() {
  SettingsStore.Values v=new SettingsStore.Values();
  v.goalMode=2;v.realGoalHour=500;v.workDaysMask=0x7f;
  v.workDayHours=new double[]{6,7,8,9,10,11,12};
  SettingsStore.save(c,v);
  SettingsStore.Values loaded=SettingsStore.load(c);
  for(int i=0;i<7;i++) assertEquals(6+i,SettingsStore.targetHoursForDay(loaded,i),.001);
  assertEquals(63,loaded.hoursWeek,.001);
 }
}
