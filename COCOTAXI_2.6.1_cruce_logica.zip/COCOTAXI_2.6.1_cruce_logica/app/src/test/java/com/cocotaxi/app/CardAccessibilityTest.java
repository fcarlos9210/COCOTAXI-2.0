package com.cocotaxi.app;

import static org.junit.Assert.*;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class CardAccessibilityTest {
  private AccessibilityNodeInfo node(String text, int top) {
    AccessibilityNodeInfo n = AccessibilityNodeInfo.obtain();
    n.setVisibleToUser(true);
    n.setEnabled(true);
    n.setText(text);
    n.setBoundsInScreen(new Rect(0, top, 400, top + 300));
    return n;
  }

  private void child(AccessibilityNodeInfo p, AccessibilityNodeInfo c) {
    Shadows.shadowOf(p).addChild(c);
  }

  private AccessibilityNodeInfo card(String fare, int top) {
    AccessibilityNodeInfo n = node("$" + fare + " en app\n3 min · 339 m\n9 min · 4.1 km", top);
    AccessibilityNodeInfo b = node("Aceptar", top + 5);
    b.setClickable(true);
    child(n, b);
    return n;
  }

  @Test
  public void twoCardsStaySeparateAndClickTargetsExactOffer() {
    AccessibilityNodeInfo root = node("", 0), first = card("188", 0), second = card("240", 350);
    child(root, first);
    child(root, second);
    List<Offer> offers = TextCollector.cards(root);
    assertEquals(2, offers.size());
    assertEquals(188, offers.get(0).fare, .001);
    assertEquals(240, offers.get(1).fare, .001);
    TextCollector.clickOffer(root, offers.get(1));
    assertEquals(0, Shadows.shadowOf(first.getChild(0)).getPerformedActions().size());
    assertEquals(
        Integer.valueOf(AccessibilityNodeInfo.ACTION_CLICK),
        Shadows.shadowOf(second.getChild(0)).getPerformedActions().get(0));
  }

  @Test
  public void listWithOneCompleteVisibleCardIsStillList() {
    AccessibilityNodeInfo root = node("", 0);
    root.setClassName("androidx.recyclerview.widget.RecyclerView");
    child(root, card("188", 0));
    child(root, node("$240 en app", 350));
    assertEquals(1, TextCollector.cards(root).size());
    assertTrue(TextCollector.isList(root));
  }

  @Test
  public void collectionMetadataIdentifiesListWithoutClassName() {
    AccessibilityNodeInfo root = card("188", 0);
    root.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(6, 1, false));
    assertTrue(TextCollector.isList(root));
  }

  @Test
  public void contentDescriptionAcceptSupportedAndDisabledButtonBlocked() {
    AccessibilityNodeInfo n = node(null, 0);
    n.setContentDescription("Aceptar");
    n.setClickable(true);
    assertTrue(TextCollector.hasAccept(n));
    n.setEnabled(false);
    assertFalse(TextCollector.hasAccept(n));
  }
}
