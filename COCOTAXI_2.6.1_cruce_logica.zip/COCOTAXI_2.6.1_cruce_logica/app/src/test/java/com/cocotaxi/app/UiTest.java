package com.cocotaxi.app;

import static org.junit.Assert.*;

import android.graphics.*;
import android.view.*;
import android.widget.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "w393dp-h852dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class UiTest {
  @Before
  public void before() {
    CocoStore.closeForTests();
    RuntimeEnvironment.getApplication().deleteDatabase("cocotaxi_v3.db");
    RuntimeEnvironment.getApplication()
        .getSharedPreferences(SettingsStore.PREFS, 0)
        .edit()
        .clear()
        .commit();
    PinStore.clear(RuntimeEnvironment.getApplication());
  }

  @After
  public void after() {
    CocoStore.closeForTests();
  }

  private TextView find(View v, String text) {
    if (v instanceof TextView && ((TextView) v).getText().toString().trim().equals(text))
      return (TextView) v;
    if (v instanceof ViewGroup) {
      ViewGroup g = (ViewGroup) v;
      for (int i = 0; i < g.getChildCount(); i++) {
        TextView r = find(g.getChildAt(i), text);
        if (r != null) return r;
      }
    }
    return null;
  }

  private void click(MainActivity a, String name) {
    TextView t = find(a.getWindow().getDecorView(), name);
    assertNotNull(name, t);
    View v = t;
    while (v != null && !v.hasOnClickListeners() && !v.isClickable())
      v = v.getParent() instanceof View ? (View) v.getParent() : null;
    assertNotNull(v);
    v.performClick();
  }

  private View findDescription(View v, String description) {
    if (description.equals(String.valueOf(v.getContentDescription()))) return v;
    if (v instanceof ViewGroup) {
      ViewGroup g = (ViewGroup) v;
      for (int i = 0; i < g.getChildCount(); i++) {
        View found = findDescription(g.getChildAt(i), description);
        if (found != null) return found;
      }
    }
    return null;
  }

  private void snapshot(MainActivity a, String name) throws Exception {
    View v = a.getWindow().getDecorView();
    int w = 1179, h = 2556;
    v.measure(
        View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
    v.layout(0, 0, w, h);
    Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    v.draw(new Canvas(b));
    java.io.File dir = new java.io.File("build/ui-preview");
    dir.mkdirs();
    try (java.io.FileOutputStream f =
        new java.io.FileOutputStream(new java.io.File(dir, name + ".png"))) {
      b.compress(Bitmap.CompressFormat.PNG, 100, f);
    }
    b.recycle();
  }

  @Test
  public void disconnectClearsDashboardAndPreservesHistory() throws Exception {
    CocoStore store = CocoStore.get(RuntimeEnvironment.getApplication());
    store.start();
    store.manual(180, 15, "Viaje anterior");
    String closedId = store.session().id;
    try (ActivityController<MainActivity> controller =
        Robolectric.buildActivity(MainActivity.class).setup()) {
      MainActivity activity = controller.get();
      click(activity, "■ Desconectar");
      assertFalse(store.session().active);
      assertEquals(180, store.session().money, .001);
      java.lang.reflect.Method method = MainActivity.class.getDeclaredMethod("dashboardSession");
      method.setAccessible(true);
      CocoStore.Session ready = (CocoStore.Session) method.invoke(activity);
      assertEquals(0, ready.money, .001);
      assertEquals(0, ready.minutes, .001);
      assertEquals(0, ready.trips);
      store.start();
      assertNotEquals(closedId, store.session().id);
      assertEquals(0, store.session().money, .001);
      assertEquals(2, store.sessions().size());
    }
  }

  @Test
  public void iconMinimizesOnlyResumedCoco() {
    try (ActivityController<MainActivity> controller =
        Robolectric.buildActivity(MainActivity.class).setup()) {
      MainActivity activity = controller.get();
      MainActivity.minimizeFromOverlay();
      controller.pause();
      assertFalse(MainActivity.minimizeFromOverlay());
    }
  }

  @Test
  public void fourTabsAndScreensRender() throws Exception {
    try (ActivityController<MainActivity> ac =
        Robolectric.buildActivity(MainActivity.class).setup()) {
      MainActivity a = ac.get();
      assertNotNull(find(a.getWindow().getDecorView(), "PROMEDIO · CONFIRMADO + ESTIMADO"));
      snapshot(a, "inicio");
      click(a, "Metas");
      assertNull(find(a.getWindow().getDecorView(), "COMPROBAR COBROS"));
      snapshot(a, "metas");
      click(a, "Sesión");
      assertNotNull(find(a.getWindow().getDecorView(), "＋ Registrar viaje manual"));
      snapshot(a, "sesion");
      click(a, "Ajustes");
      assertNotNull(find(a.getWindow().getDecorView(), "Guardar ajustes"));
      assertNull(find(a.getWindow().getDecorView(), "Horas objetivo"));
      assertNull(find(a.getWindow().getDecorView(), "Ventana flotante"));
      assertNull(find(a.getWindow().getDecorView(), "Sonido"));
      assertNotNull(find(a.getWindow().getDecorView(), "Liquidación"));
      assertNull(find(a.getWindow().getDecorView(), "Probar oferta"));
      assertNull(find(a.getWindow().getDecorView(), "Permisos"));
      assertNull(find(a.getWindow().getDecorView(), "Creado por Frank Carlos"));
      snapshot(a, "ajustes");
    }
  }

  @Test
  public void unsavedSettingsBlockNavigationUntilSaved() {
    try (ActivityController<MainActivity> ac =
        Robolectric.buildActivity(MainActivity.class).setup()) {
      MainActivity a = ac.get();
      click(a, "Ajustes");
      View vibration = findDescription(a.getWindow().getDecorView(), "Vibración");
      assertNotNull(vibration);
      vibration.performClick();

      click(a, "Inicio");
      assertNotNull(find(a.getWindow().getDecorView(), "Guardar ajustes"));
      assertNotNull(find(a.getWindow().getDecorView(), "Vibración"));

      View profile = findDescription(a.getWindow().getDecorView(), "Perfil");
      assertNotNull(profile);
      profile.performClick();
      assertNotNull(find(a.getWindow().getDecorView(), "Guardar ajustes"));

      click(a, "Guardar ajustes");
      click(a, "Inicio");
      assertNotNull(find(a.getWindow().getDecorView(), "PROMEDIO · CONFIRMADO + ESTIMADO"));
    }
  }

  @Test
  public void permissionsAndCreditLiveInProfile() {
    try (ActivityController<MainActivity> ac =
        Robolectric.buildActivity(MainActivity.class).setup()) {
      MainActivity a = ac.get();
      View profile = findDescription(a.getWindow().getDecorView(), "Perfil");
      assertNotNull(profile);
      profile.performClick();
      assertNotNull(find(a.getWindow().getDecorView(), "Permisos"));
      assertNotNull(find(a.getWindow().getDecorView(), "Creado por Frank Carlos"));
    }
  }
}
