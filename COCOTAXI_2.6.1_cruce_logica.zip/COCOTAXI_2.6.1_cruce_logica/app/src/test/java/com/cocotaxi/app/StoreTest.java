package com.cocotaxi.app;

import static org.junit.Assert.*;

import android.content.Context;
import java.time.Duration;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowSystemClock;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class StoreTest {
  Context c;
  CocoStore st;

  @Before
  public void setup() {
    c = RuntimeEnvironment.getApplication();
    CocoStore.closeForTests();
    c.deleteDatabase("cocotaxi_v3.db");
    st = CocoStore.get(c);
    st.start();
  }

  @After
  public void end() {
    CocoStore.closeForTests();
  }

  @Test
  public void startIdempotent() {
    String id = st.session().id;
    st.start();
    assertEquals(id, st.session().id);
  }

  @Test
  public void pauseStopsTime() {
    ShadowSystemClock.advanceBy(Duration.ofMinutes(10));
    st.pause();
    double m = st.session().minutes;
    ShadowSystemClock.advanceBy(Duration.ofMinutes(20));
    assertEquals(m, st.session().minutes, .0001);
    st.pause();
    ShadowSystemClock.advanceBy(Duration.ofMinutes(5));
    assertEquals(m + 5, st.session().minutes, .0001);
  }

  @Test
  public void doubleStopDoesNotAddTime() {
    ShadowSystemClock.advanceBy(Duration.ofMinutes(10));
    st.stop();
    st.stop();
    ShadowSystemClock.advanceBy(Duration.ofMinutes(10));
    assertEquals(10, st.session().minutes, .001);
  }

  @Test
  public void correctDoesNotDoubleIncome() {
    String id = st.manual(200, 10, "test");
    st.correct(id, 180, 10, false, 0);
    st.correct(id, 180, 10, false, 0);
    assertEquals(170, st.session().money, .001);
    assertEquals(1, st.session().trips);
  }

  @Test
  public void deleteAndRestore() {
    String id = st.manual(200, 10, "test");
    st.delete(id);
    assertEquals(0, st.session().money, .001);
    st.restore(id);
    assertEquals(200, st.session().money, .001);
  }

  @Test
  public void separateSessions() {
    st.manual(200, 10, "a");
    st.stop();
    ShadowSystemClock.advanceBy(Duration.ofSeconds(1));
    st.start();
    assertEquals(0, st.session().money, .001);
    assertEquals(2, st.sessions().size());
  }

  private String attempt() {
    Offer o = OfferParser.parse("Para ti $188\n3 min\n9 min\nAceptar", "com.cabify.driver");
    DecisionEngine.Result r = new DecisionEngine.Result();
    r.payout = 188;
    return st.attempt(o, r, true);
  }

  @Test
  public void photographedOriginConfirmsAssignmentOnlyOnce() {
    String id = attempt();
    String screen = "CABIFY Ir a origen Avenida Ingeniero 1595 Navegar Ver ruta Cata";
    st.observe(screen);
    assertEquals("ASIGNADO", st.find(id).status);
    st.observe(screen);
    assertEquals(id, st.activeTrip().id);
    assertEquals(188, st.session().money, .001);
    st.observe("Viaje finalizado");
    st.observe("Viaje finalizado");
    assertEquals(188, st.session().money, .001);
    assertEquals(1, st.session().trips);
  }

  @Test
  public void attemptedNotIncome() {
    attempt();
    assertEquals(0, st.session().money, .001);
    assertEquals(0, st.session().trips);
  }

  @Test
  public void confirmedAcceptanceStartsLiveServiceAndIncomeImmediately() {
    String id = attempt();
    assertTrue(st.confirmAccepted(id));
    assertEquals("ASIGNADO", st.find(id).status);
    assertEquals(188, st.session().money, .001);
    ShadowSystemClock.advanceBy(Duration.ofSeconds(90));
    CocoStore.Session s = st.session();
    assertEquals(1.5, s.service, .02);
    assertEquals(0, Math.max(0, s.minutes - s.service), .02);
  }

  @Test
  public void driverCanRemoveAndRestoreDefaultTripConfirmation() {
    String id = attempt();
    st.confirmAccepted(id);
    assertEquals(188, st.session().money, .001);
    st.unconfirm(id);
    assertEquals("SIN CONFIRMAR", st.find(id).status);
    assertEquals(0, st.session().money, .001);
    st.reconfirm(id);
    assertEquals("ASIGNADO", st.find(id).status);
    assertEquals(188, st.session().money, .001);
  }

  @Test
  public void otherDriverWins() {
    String id = attempt();
    st.observe("Otro conductor aceptó el viaje");
    assertEquals("NO ASIGNADO", st.find(id).status);
    assertNull(st.activeTrip());
    assertEquals(0, st.session().money, .001);
  }

  @Test
  public void finishButtonNotCompletion() {
    String id = attempt();
    st.observe("Ir a recoger al pasajero");
    st.observe("Finalizar viaje");
    assertEquals("ASIGNADO", st.find(id).status);
    assertEquals(188, st.session().money, .001);
  }

  @Test
  public void historyNotCompletion() {
    String id = attempt();
    st.observe("He llegado");
    st.observe("Historial de viajes");
    assertEquals("ASIGNADO", st.find(id).status);
  }

  @Test
  public void completedExactlyOnce() {
    String id = attempt();
    st.observe("He llegado");
    ShadowSystemClock.advanceBy(Duration.ofMinutes(12));
    st.observe("Viaje finalizado");
    st.observe("Viaje finalizado");
    assertEquals(188, st.session().money, .001);
    assertEquals(1, st.session().trips);
    assertFalse(st.complete(id));
  }

  @Test
  public void verificationBuildsWeightedFactor() {
    String id = attempt();
    st.correct(id, 170, 0, true, 170);
    assertEquals(170.0 / 188, st.calibration("PARA_TI").factor, .000001);
    st.delete(id);
    assertEquals(0, st.calibration("PARA_TI").count);
  }

  @Test
  public void duplicateDailySnapshotReplaces() {
    st.saveBilling("2026-09-17", 11010, 60, 0, 0, 11061.89);
    st.saveBilling("2026-09-17", 11010, 60, 0, 0, 11061.89);
    try (android.database.Cursor q =
        st.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM billing", null)) {
      q.moveToFirst();
      assertEquals(1, q.getInt(0));
    }
  }

  @Test
  public void pausedCannotAddManual() {
    st.pause();
    assertThrows(IllegalArgumentException.class, () -> st.manual(100, 1, "test"));
  }

  @Test
  public void extraDoesNotInventTrip() {
    st.manual(1300, 0, "Bono cobrado", false);
    assertEquals(1300, st.session().money, .001);
    assertEquals(0, st.session().trips);
  }

  @Test
  public void restartPausesUnobservedTime() {
    ShadowSystemClock.advanceBy(Duration.ofMinutes(1));
    st.session();
    int b =
        android.provider.Settings.Global.getInt(
            c.getContentResolver(), android.provider.Settings.Global.BOOT_COUNT, 0);
    android.provider.Settings.Global.putInt(
        c.getContentResolver(), android.provider.Settings.Global.BOOT_COUNT, b + 1);
    assertTrue(st.session().paused);
    assertEquals(1, st.session().minutes, .001);
  }

  @Test
  public void unfinishedRideCannotBlockNextSession() {
    String old = attempt();
    st.observe("He llegado");
    st.stop();
    st.start();
    assertNull(st.activeTrip());
    assertEquals("SIN CONFIRMAR", st.find(old).status);
    assertNotNull(attempt());
    assertEquals(0, st.session().money, .001);
  }

  @Test
  public void rebootWhilePausedInvalidatesOldTripClock() {
    String old = attempt();
    st.observe("He llegado");
    st.pause();
    android.provider.Settings.Global.putInt(
        c.getContentResolver(), android.provider.Settings.Global.BOOT_COUNT, 1234);
    assertTrue(st.session().paused);
    assertEquals("SIN CONFIRMAR", st.find(old).status);
    assertNull(st.activeTrip());
  }

  private String closedDay(int ago) {
    return java.time.LocalDate.now(CocoStore.ZONE).minusDays(ago).toString();
  }

  @Test
  public void dailySeedPredictsWithoutIndividualPaymentPairs() {
    CocoStore.Calibration k = st.dailyCalibration();
    assertTrue(k.provisional);
    assertTrue(k.usable());
    assertEquals(1.0, k.factor, .000001);
    SettingsStore.Values v = new SettingsStore.Values();
    v.payoutMode = 3;
    v.operationalGoalHour = 700;
    v.realGoalHour = 700;
    Offer o = OfferParser.parse("Aceptar\n$200 en app\n3 min\n9 min", "com.cabify.driver");
    DecisionEngine.Result r =
        DecisionEngine.evaluate(o, v, st.session(), 2, st.calibrationForOffer(o.kind, v));
    assertEquals(200, r.payout, .001);
    assertEquals(200 * 60 / r.minutes, r.hourly, .001);
    assertTrue(r.accept);
    assertTrue(r.provisional);
  }

  @Test
  public void completeDailyTotalsLearnWeightedFactorAndExcludeTipsBonusesTolls() {
    st.saveBilling(closedDay(1), 1100, 100, 50, 50, 1000, true);
    st.saveBilling(closedDay(2), 2500, 100, 0, 0, 3000, true);
    CocoStore.Calibration k = st.dailyCalibration();
    assertEquals(2, k.count);
    assertEquals(.825, k.factor, .000001);
    assertFalse(k.provisional);
    assertEquals(0, st.session().money, .001);
  }

  @Test
  public void partialAndOldClosuresCannotTrain() {
    st.saveBilling(closedDay(1), 2833, 0, 0, 0, 2471.59, false);
    st.saveBilling(closedDay(30), 100, 0, 0, 0, 200, true);
    assertTrue(st.dailyCalibration().provisional);
    assertEquals(1.0, st.dailyCalibration().factor, .000001);
  }

  @Test
  public void correctingClosureReplacesAndCanWithdrawTraining() {
    st.saveBilling(closedDay(1), 900, 0, 0, 0, 1000, true);
    st.saveBilling(closedDay(1), 800, 0, 0, 0, 1000, true);
    assertEquals(1, st.dailyCalibration().count);
    assertEquals(.8, st.dailyCalibration().factor, .000001);
    st.saveBilling(closedDay(1), 800, 0, 0, 0, 1000, false);
    assertTrue(st.dailyCalibration().provisional);
  }

  @Test
  public void todayCannotBeUsedAsClosedDay() {
    assertThrows(
        IllegalArgumentException.class,
        () -> st.saveBilling(closedDay(0), 100, 0, 0, 0, 100, true));
    st.saveBilling(closedDay(0), 100, 0, 0, 0, 100, false);
    assertTrue(st.dailyCalibration().provisional);
  }

  @Test
  public void migrationPreservesSessionsAndDoesNotTrustOldBillingAutomatically() {
    st.manual(200, 10, "antes");
    st.saveBilling(closedDay(1), 900, 0, 0, 0, 1000);
    android.database.sqlite.SQLiteDatabase db = st.getWritableDatabase();
    db.execSQL("ALTER TABLE billing RENAME TO billing_v2");
    db.execSQL(
        "CREATE TABLE billing(day TEXT PRIMARY KEY,total REAL,tips REAL,bonus REAL,tolls"
            + " REAL,history REAL)");
    db.execSQL("INSERT INTO billing SELECT day,total,tips,bonus,tolls,history FROM billing_v2");
    db.execSQL("DROP TABLE billing_v2");
    db.setVersion(1);
    CocoStore.closeForTests();
    st = CocoStore.get(c);
    assertEquals(200, st.session().money, .001);
    assertEquals(2, st.getReadableDatabase().getVersion());
    assertTrue(st.dailyCalibration().provisional);
  }

  @Test
  public void ayeryhoyFaresAccumulateUsingSameEngineAsLiveOffers() {
    double[] amounts = {
      181.36, 280.42, 316.01, 0, 300.77, 0, 216.2, 273.53, 210.64, 206.99, 213.22, 267.04, 348.63,
      181.36, 485.74, 272.99, 415.57, 228.39, 209.48, 183.84, 216.05, 188.66, 257.44, 0, 220.22,
      178.2, 224.47, 238.24, 178.2, 357.09, 444.91, 270.23, 255.93, 293.42, 369.91, 197.13, 240.04,
      245.81, 216.21, 178.2, 361.91, 311.99, 0, 232.42, 351.75, 241.28
    };
    SettingsStore.Values v = new SettingsStore.Values();
    v.payoutMode = 3;
    v.operationalGoalHour = 700;
    v.realGoalHour = 700;
    long sum = 0;
    for (double fare : amounts) {
      if (fare == 0) continue;
      Offer o =
          OfferParser.parse("Aceptar\n$" + fare + " en app\n3 min\n9 min", "com.cabify.driver");
      // Times only make a complete synthetic offer; this asserts payout, not historical
      // profitability.
      sum +=
          Money.cents(DecisionEngine.evaluate(o, v, st.session(), 2, st.dailyCalibration()).payout);
    }
    assertEquals(1095130, sum);
  }
}
