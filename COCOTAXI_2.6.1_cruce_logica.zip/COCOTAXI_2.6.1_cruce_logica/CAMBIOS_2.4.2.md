# COCOTAXI 2.4.2

## Cambios solicitados
- Eliminada la espera hipotética entre ofertas de la fórmula y de Ajustes. También se ignora cualquier valor guardado en versiones anteriores.
- Tiempo para valorar una oferta = recogida + recorrido + espera al pasajero configurada. Rendimiento = (cobro estimado − gastos configurados) × 60 / ese tiempo.
- La espera ya transcurrida permanece en el reloj y el promedio de sesión. No se añade como duración a la oferta. La recuperación gradual del objetivo después de una hora y los filtros de demanda siguen vigentes; ningún importe aislado obliga a aceptar un viaje de cualquier duración.
- Ejemplo verificado: meta 500/h, 10 minutos esperando, oferta 180, recogida + viaje 15 minutos y espera al pasajero cero. Rendimiento de oferta 720/h, promedio posterior 432/h: acepta en demanda media. La espera futura antigua de 120 minutos no altera el resultado.
- Pausar/reanudar conserva la sesión y excluye el tiempo pausado.
- Desconectar archiva la sesión existente sin borrar sus viajes. Inicio y meta de jornada muestran un estado nuevo a cero. Al conectar se crea el registro de la nueva sesión y comienza el reloj. Las metas configuradas y el acumulado semanal se conservan. No se implementa reanudación de sesiones cerradas, conforme a la nueva instrucción.
- Tocar el icono abre Coco; si Coco está en primer plano, otro toque minimiza su tarea. Arrastrar sigue moviendo el icono.
- La recomendación se oculta al intentar/confirmar la asignación y no reaparece por una lectura atrasada mientras haya viaje activo. Se conserva el icono para abrir/minimizar. Continúa la lectura de finalización por accesibilidad/OCR.
- Las promociones de una sesión cerrada dejan de aparecer activas. El planificador de promociones aún usa ciclos observados para estimar si se puede completar el premio antes de su fin; no añade el antiguo parámetro de espera futura al viaje actual.

## Validación y límites
30 comprobaciones del núcleo y 9 de señales de asignación ejecutadas. Análisis de sintaxis de 27 archivos Java principales. Pruebas Android adicionales suministradas, NO ejecutadas aquí. Sin verificación visual/dispositivo ni compilación Android: Gradle no se pudo descargar (Network is unreachable). No hay acceso remoto a la PC del usuario desde las herramientas de este chat.

Los cambios anteriores de 2.4.1 se mantienen. Las promociones múltiples del pedido previo siguen pendientes; no se presentan como implementadas. La calibración inicial 1,00 sigue siendo provisional.
