# COCOTAXI 2.5.2 — ventana de oferta compacta

- La ventana de oferta queda visible 4 segundos para que el conductor pueda leer el resultado incluso si Coco acepta automáticamente casi al instante.
- La confirmación de autoaceptación no desaparece al detectarse inmediatamente el viaje activo.
- Se añadió estado visual `ACEPTADO AUTOMÁTICAMENTE` y estado de fallo `NO SE PUDO ACEPTAR`, ambos visibles 4 s.
- Se eliminó el botón minimizar de la ventana expandida: el único control de acción visible es cerrar (X).
- Diseño más compacto, manteniendo el estilo oscuro/verde actual de COCOTAXI.
- Se priorizan visualmente tres datos: costo del viaje, `ACEPTABLE` y minutos totales.
- Costo en verde intenso, `ACEPTABLE` y total de minutos en amarillo para lectura inmediata.
- La fila secundaria conserva recogida, viaje y proyección después del viaje con menor jerarquía visual.
- No se cambió la fórmula de decisión ni los parámetros del motor de Coco.
