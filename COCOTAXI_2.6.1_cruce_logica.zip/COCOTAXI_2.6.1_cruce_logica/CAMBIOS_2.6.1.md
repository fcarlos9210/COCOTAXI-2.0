# COCOTAXI 2.6.1 — cruce de lógica de sesión y ganancias

- Se cruzó la lógica de COCOTAXI 2.4.5 con el camino rápido auditado de 2.6.0.
- Un viaje aceptado por Coco o manualmente queda `ASIGNADO`, entra inmediatamente en **Ganancias en App** como **estimado** y arranca **En servicio**.
- Al finalizar, el mismo registro pasa a `FINALIZADO`: sale del bloque estimado y pasa a **ganado**, sin sumar el importe por segunda vez.
- Si luego se corrige el pago real, sustituye la estimación del viaje finalizado; no crea otro ingreso.
- **En servicio** aumenta mientras hay un viaje `ASIGNADO`.
- **Sin viaje = tiempo conectado - tiempo en servicio**: conserva toda la espera acumulada antes del viaje y vuelve a crecer desde ese valor después de finalizar.
- Inicio: `OBJETIVO REAL` → `OBJETIVO`; `PROMEDIO CONFIRMADO` → `OBJETIVO REAL`; `OBJETIVO ACUM.` → `DEBERÍA TENER`; `GANADO` → `GANANCIAS EN APP`; `FALTA` → `PÉRDIDAS`.
- `Ganancias en App` y `Objetivo Real` usan el total de viajes realmente asignados/finalizados, nunca meras ofertas o intentos fallidos.
- Se conserva intacto el camino crítico 2.6.0 de captura y autoaceptación.
