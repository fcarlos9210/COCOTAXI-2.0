package com.cocotaxi.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

public final class LineIconView extends View {
  public static final int HOME = 1;
  public static final int CLOCK = 2;
  public static final int TARGET = 3;
  public static final int GEAR = 4;
  public static final int CAR = 5;
  public static final int WALLET = 6;
  public static final int CALENDAR = 7;
  public static final int CHART = 8;
  public static final int ROAD = 9;
  public static final int MONEY = 10;
  public static final int STOP = 11;

  private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final Path path = new Path();
  private int type;
  private int color = Color.rgb(105, 255, 58);

  public LineIconView(Context context, int type) {
    super(context);
    this.type = type;
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeJoin(Paint.Join.ROUND);
  }

  public void setIconColor(int color) {
    this.color = color;
    invalidate();
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    float w = getWidth();
    float h = getHeight();
    float s = Math.min(w, h);
    float cx = w / 2f;
    float cy = h / 2f;
    paint.setColor(color);
    paint.setStrokeWidth(Math.max(3f, s * 0.08f));
    paint.setStyle(Paint.Style.STROKE);
    path.reset();

    if (type == HOME) {
      path.moveTo(cx - s * .34f, cy);
      path.lineTo(cx, cy - s * .32f);
      path.lineTo(cx + s * .34f, cy);
      path.moveTo(cx - s * .23f, cy);
      path.lineTo(cx - s * .23f, cy + s * .28f);
      path.lineTo(cx + s * .23f, cy + s * .28f);
      path.lineTo(cx + s * .23f, cy);
      canvas.drawPath(path, paint);
    } else if (type == CLOCK) {
      canvas.drawCircle(cx, cy, s * .34f, paint);
      canvas.drawLine(cx, cy, cx, cy - s * .2f, paint);
      canvas.drawLine(cx, cy, cx + s * .16f, cy + s * .08f, paint);
    } else if (type == TARGET) {
      canvas.drawCircle(cx, cy, s * .34f, paint);
      canvas.drawCircle(cx, cy, s * .18f, paint);
      canvas.drawLine(cx, cy, cx + s * .38f, cy - s * .38f, paint);
      canvas.drawLine(cx + s * .22f, cy - s * .38f, cx + s * .38f, cy - s * .38f, paint);
      canvas.drawLine(cx + s * .38f, cy - s * .38f, cx + s * .38f, cy - s * .22f, paint);
    } else if (type == GEAR) {
      canvas.drawCircle(cx, cy, s * .25f, paint);
      canvas.drawCircle(cx, cy, s * .09f, paint);
      for (int i = 0; i < 8; i++) {
        double a = Math.PI * i / 4.0;
        canvas.drawLine(
            cx + (float) Math.cos(a) * s * .34f,
            cy + (float) Math.sin(a) * s * .34f,
            cx + (float) Math.cos(a) * s * .43f,
            cy + (float) Math.sin(a) * s * .43f,
            paint);
      }
    } else if (type == CAR) {
      RectF body = new RectF(cx - s * .34f, cy - s * .08f, cx + s * .34f, cy + s * .2f);
      canvas.drawRoundRect(body, s * .08f, s * .08f, paint);
      path.moveTo(cx - s * .22f, cy - s * .08f);
      path.lineTo(cx - s * .12f, cy - s * .24f);
      path.lineTo(cx + s * .16f, cy - s * .24f);
      path.lineTo(cx + s * .26f, cy - s * .08f);
      canvas.drawPath(path, paint);
      canvas.drawCircle(cx - s * .2f, cy + s * .23f, s * .06f, paint);
      canvas.drawCircle(cx + s * .2f, cy + s * .23f, s * .06f, paint);
    } else if (type == WALLET) {
      RectF r = new RectF(cx - s * .34f, cy - s * .23f, cx + s * .34f, cy + s * .24f);
      canvas.drawRoundRect(r, s * .08f, s * .08f, paint);
      canvas.drawLine(cx - s * .34f, cy - s * .07f, cx + s * .34f, cy - s * .07f, paint);
      canvas.drawCircle(cx + s * .2f, cy + s * .05f, s * .04f, paint);
    } else if (type == CALENDAR) {
      RectF r = new RectF(cx - s * .32f, cy - s * .28f, cx + s * .32f, cy + s * .3f);
      canvas.drawRoundRect(r, s * .05f, s * .05f, paint);
      canvas.drawLine(cx - s * .32f, cy - s * .12f, cx + s * .32f, cy - s * .12f, paint);
      canvas.drawLine(cx - s * .16f, cy - s * .36f, cx - s * .16f, cy - s * .2f, paint);
      canvas.drawLine(cx + s * .16f, cy - s * .36f, cx + s * .16f, cy - s * .2f, paint);
    } else if (type == CHART) {
      canvas.drawLine(cx - s * .28f, cy + s * .25f, cx - s * .28f, cy + s * .05f, paint);
      canvas.drawLine(cx, cy + s * .25f, cx, cy - s * .1f, paint);
      canvas.drawLine(cx + s * .28f, cy + s * .25f, cx + s * .28f, cy - s * .28f, paint);
    } else if (type == ROAD) {
      canvas.drawLine(cx - s * .22f, cy + s * .32f, cx - s * .05f, cy - s * .32f, paint);
      canvas.drawLine(cx + s * .22f, cy + s * .32f, cx + s * .05f, cy - s * .32f, paint);
      canvas.drawLine(cx, cy + s * .24f, cx, cy + s * .08f, paint);
      canvas.drawLine(cx, cy - s * .06f, cx, cy - s * .2f, paint);
    } else if (type == MONEY) {
      canvas.drawCircle(cx, cy, s * .34f, paint);
      paint.setStyle(Paint.Style.FILL);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTextSize(s * .48f);
      paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
      canvas.drawText("$", cx, cy + s * .18f, paint);
    } else if (type == STOP) {
      canvas.drawCircle(cx, cy, s * .32f, paint);
      canvas.drawLine(cx - s * .14f, cy, cx + s * .14f, cy, paint);
    }
  }
}
