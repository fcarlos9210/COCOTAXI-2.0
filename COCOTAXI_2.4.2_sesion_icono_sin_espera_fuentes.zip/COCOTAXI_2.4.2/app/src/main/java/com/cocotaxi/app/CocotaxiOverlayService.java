package com.cocotaxi.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public final class CocotaxiOverlayService extends Service {
  private static CocotaxiOverlayService instance;
  private WindowManager windows;
  private LinearLayout panel;
  private TextView summary, decision, pickup, journey, total, projected, amount, reason, close;
  private LinearLayout metrics, bottom;
  private String dismissedKey = "";
  private RoundedIconView icon;
  private TextView handle, minimize;
  private WindowManager.LayoutParams layout;
  private final Handler handler = new Handler(Looper.getMainLooper());
  private long shownAt;
  private String lastKey = "";
  private android.media.ToneGenerator tone;
  private final Runnable tick =
      new Runnable() {
        public void run() {
          CocoStore.Session s = CocoStore.get(CocotaxiOverlayService.this).session();
          if (!s.active) {
            stopSelf();
            return;
          }
          if (SystemClock.elapsedRealtime() - shownAt > 6000 || s.paused
              || CocoStore.get(CocotaxiOverlayService.this).activeTrip() != null) hideCard();
          handler.postDelayed(this, 1000);
        }
      };

  public static void update(
      DecisionEngine.Result r, int position, int count, int demand, boolean ocr) {
    if (instance != null) instance.display(r, position, count, demand, ocr);
  }

  public static void clearOffer() {
    if (instance != null) instance.hideCard();
  }

  @Override
  public void onCreate() {
    super.onCreate();
    instance = this;
    NotificationManager nm = getSystemService(NotificationManager.class);
    nm.createNotificationChannel(
        new NotificationChannel(
            "coco_session", "Sesión COCOTAXI", NotificationManager.IMPORTANCE_LOW));
    Intent open =
        new Intent(this, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
    PendingIntent pi =
        PendingIntent.getActivity(
            this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    Notification n =
        new Notification.Builder(this, "coco_session")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("COCOTAXI conectado")
            .setContentText("Toca para abrir tu sesión y pausar")
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
    startForeground(101, n);
    if (Settings.canDrawOverlays(this) && SettingsStore.load(this).floatingEnabled) createWindow();
    handler.post(tick);
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    if (!CocoStore.get(this).session().active) {
      stopSelf();
      return START_NOT_STICKY;
    }
    if (panel == null && Settings.canDrawOverlays(this) && SettingsStore.load(this).floatingEnabled)
      createWindow();
    return START_NOT_STICKY;
  }

  private int dp(float n) {
    return Math.round(n * getResources().getDisplayMetrics().density);
  }

  private TextView text(String t, int size, int color) {
    TextView v = new TextView(this);
    v.setText(t);
    v.setTextSize(size);
    v.setTextColor(color);
    v.setPadding(dp(5), dp(3), dp(5), dp(3));
    return v;
  }

  private GradientDrawable frame(int fill, int border, int radius) {
    GradientDrawable bg = new GradientDrawable();
    bg.setColor(fill);
    bg.setCornerRadius(dp(radius));
    bg.setStroke(dp(1), border);
    return bg;
  }

  private TextView metric(String title, LinearLayout row) {
    LinearLayout cell = new LinearLayout(this);
    cell.setOrientation(LinearLayout.VERTICAL);
    cell.setGravity(Gravity.CENTER);
    TextView label = text(title, 11, 0xffced8df);
    label.setGravity(Gravity.CENTER);
    cell.addView(label, new LinearLayout.LayoutParams(-1, dp(32)));
    TextView value = text("", 21, Color.WHITE);
    value.setGravity(Gravity.CENTER);
    value.setTypeface(null, android.graphics.Typeface.BOLD);
    value.setMaxLines(1);
    value.setAutoSizeTextTypeUniformWithConfiguration(10, 21, 1, 2);
    cell.addView(value, new LinearLayout.LayoutParams(-1, dp(32)));
    row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
    return value;
  }

  private void createWindow() {
    windows = getSystemService(WindowManager.class);
    panel = new LinearLayout(this);
    panel.setOrientation(LinearLayout.VERTICAL);
    panel.setPadding(dp(5), dp(5), dp(5), dp(5));
    GradientDrawable bg =
        new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xff00291d, 0xff000d10});
    bg.setCornerRadius(dp(18));
    bg.setStroke(dp(2), 0xff67ff37);
    panel.setBackground(bg);
    LinearLayout top = new LinearLayout(this);
    top.setGravity(Gravity.CENTER_VERTICAL);
    panel.addView(top);
    icon = new RoundedIconView(this);
    icon.setContentDescription("Abrir o minimizar COCOTAXI; arrastra para mover");
    top.addView(icon, new LinearLayout.LayoutParams(dp(56), dp(56)));
    handle = text("━━━━", 16, 0xff67ff37);
    handle.setGravity(Gravity.CENTER);
    top.addView(handle, new LinearLayout.LayoutParams(0, dp(44), 1));
    minimize = text("−", 25, Color.WHITE);
    minimize.setGravity(Gravity.CENTER);
    top.addView(minimize, new LinearLayout.LayoutParams(dp(44), dp(44)));
    minimize.setContentDescription("Minimizar recomendación");
    minimize.setOnClickListener(v -> hideCard());
    close = text("×", 28, Color.WHITE);
    close.setGravity(Gravity.CENTER);
    close.setContentDescription("Ocultar esta oferta");
    top.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
    close.setOnClickListener(v -> { dismissedKey = lastKey; hideCard(); });
    metrics = new LinearLayout(this);
    metrics.setPadding(dp(3), dp(6), dp(3), dp(6));
    metrics.setBackground(frame(0xff001516, 0xff12513a, 14));
    pickup = metric("Recogida", metrics);
    journey = metric("Viaje", metrics);
    total = metric("Total", metrics);
    projected = metric("Después\ndel viaje", metrics);
    panel.addView(metrics);
    bottom = new LinearLayout(this);
    bottom.setGravity(Gravity.CENTER_VERTICAL);
    bottom.setPadding(0, dp(6), 0, 0);
    amount = text("", 36, 0xff67ff37);
    amount.setTypeface(null, android.graphics.Typeface.BOLD);
    amount.setGravity(Gravity.CENTER);
    amount.setMaxLines(1);
    amount.setAutoSizeTextTypeUniformWithConfiguration(18, 36, 1, 2);
    bottom.addView(amount, new LinearLayout.LayoutParams(0, dp(72), 1));
    LinearLayout verdict = new LinearLayout(this);
    verdict.setOrientation(LinearLayout.VERTICAL);
    verdict.setGravity(Gravity.CENTER);
    verdict.setBackground(frame(0xff03291c, 0xff67ff37, 14));
    decision = text("", 21, 0xff67ff37);
    decision.setTypeface(null, android.graphics.Typeface.BOLD);
    decision.setGravity(Gravity.CENTER);
    decision.setMaxLines(1);
    decision.setAutoSizeTextTypeUniformWithConfiguration(14, 21, 1, 2);
    reason = text("", 10, Color.WHITE);
    reason.setGravity(Gravity.CENTER);
    verdict.addView(decision, new LinearLayout.LayoutParams(-1, dp(34)));
    verdict.addView(reason);
    bottom.addView(verdict, new LinearLayout.LayoutParams(0, dp(72), 1.2f));
    panel.addView(bottom);
    summary = text("", 10, 0xffced8df);
    summary.setGravity(Gravity.CENTER);
    panel.addView(summary);
    layout =
        new WindowManager.LayoutParams(
            dp(66),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
    layout.gravity = Gravity.TOP | Gravity.START;
    layout.x = dp(12);
    layout.y = dp(100);
    handle.setVisibility(View.GONE);
    minimize.setVisibility(View.GONE);
    summary.setVisibility(View.GONE);
    decision.setVisibility(View.GONE);
    close.setVisibility(View.GONE);
    metrics.setVisibility(View.GONE);
    bottom.setVisibility(View.GONE);
    icon.setVisibility(View.VISIBLE);
    icon.setOnClickListener(v -> openApp());
    drag(icon, true);
    drag(handle, false);
    try {
      windows.addView(panel, layout);
    } catch (RuntimeException e) {
      panel = null;
    }
  }

  private void openApp() {
    if (MainActivity.minimizeFromOverlay()) return;
    startActivity(
        new Intent(this, MainActivity.class)
            .addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP));
  }

  private void drag(View view, boolean clickable) {
    view.setOnTouchListener(
        new View.OnTouchListener() {
          float x, y;
          int px, py;
          boolean moved;
          final int slop = ViewConfiguration.get(CocotaxiOverlayService.this).getScaledTouchSlop();

          public boolean onTouch(View v, android.view.MotionEvent event) {
            switch (event.getActionMasked()) {
              case MotionEvent.ACTION_DOWN:
                x = event.getRawX();
                y = event.getRawY();
                px = layout.x;
                py = layout.y;
                moved = false;
                return true;
              case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - x, dy = event.getRawY() - y;
                if (Math.hypot(dx, dy) > slop) moved = true;
                if (moved) {
                  int width = getResources().getDisplayMetrics().widthPixels,
                      height = getResources().getDisplayMetrics().heightPixels;
                  layout.x = Math.max(0, Math.min(width - panel.getWidth(), px + (int) dx));
                  layout.y = Math.max(0, Math.min(height - panel.getHeight(), py + (int) dy));
                  windows.updateViewLayout(panel, layout);
                }
                return true;
              case MotionEvent.ACTION_UP:
                if (!moved && clickable) v.performClick();
                return true;
              case MotionEvent.ACTION_CANCEL:
                return true;
            }
            return false;
          }
        });
  }

  private void display(
      DecisionEngine.Result r, int position, int count, int demand, boolean fromOcr) {
    if (panel == null || !SettingsStore.load(this).floatingEnabled) return;
    CocoStore store = CocoStore.get(this);
    CocoStore.Session session = store.session();
    if (!session.active || session.paused || store.activeTrip() != null) {
      hideCard();
      return;
    }
    if (r.offer.key.equals(dismissedKey)) return;
    shownAt = SystemClock.elapsedRealtime();
    int width = getResources().getDisplayMetrics().widthPixels;
    layout.width = Math.min(dp(380), width - dp(16));
    layout.x = Math.max(0, Math.min(layout.x, width - layout.width));
    pickup.setText(fmt(r.offer.pickupMin) + " min");
    journey.setText(fmt(r.offer.tripMin) + " min");
    total.setText(fmt(r.minutes) + " min");
    projected.setText(Money.format(r.projected) + "/h");
    amount.setText(Money.format(r.payout));
    amount.setContentDescription("Cobro estimado " + Money.exact(r.payout));
    decision.setText(r.label());
    int color = r.accept ? 0xff67ff37 : 0xffff4258;
    decision.setTextColor(color);
    reason.setText(r.promoFeasible ? "PROMO CONDICIONADA"
        : r.accept ? (r.projected >= SettingsStore.resolveRealGoalHour(SettingsStore.load(this))
            ? "CUMPLE OBJETIVO" : "CUMPLE FILTRO") : "BAJO EL FILTRO");
    reason.setContentDescription(r.reason);
    summary.setText("Oferta " + position + " de " + count + " visibles · cobro estimado"
        + (r.minutes > r.offer.totalMinutes() ? " · total incluye esperas" : "")
        + (r.provisional ? " · provisional" : "")
        + (fromOcr ? " · OCR" : ""));
    icon.setVisibility(View.GONE);
    handle.setVisibility(View.VISIBLE);
    minimize.setVisibility(View.VISIBLE);
    close.setVisibility(View.VISIBLE);
    metrics.setVisibility(View.VISIBLE);
    bottom.setVisibility(View.VISIBLE);
    summary.setVisibility(View.VISIBLE);
    decision.setVisibility(View.VISIBLE);
    windows.updateViewLayout(panel, layout);
    if (!lastKey.equals(r.offer.key) && r.accept) {
      lastKey = r.offer.key;
      SettingsStore.Values v = SettingsStore.load(this);
      if (v.soundEnabled) {
        try {
          if (tone == null)
            tone =
                new android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 60);
          tone.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 120);
        } catch (RuntimeException ignored) {
        }
      }
      if (v.vibrate) {
        android.os.Vibrator vib = getSystemService(android.os.Vibrator.class);
        if (vib != null && vib.hasVibrator())
          vib.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
      }
    }
    lastKey = r.offer.key;
  }

  private static String fmt(double n) {
    return n == (int) n ? "" + (int) n : String.format(java.util.Locale.US, "%.1f", n);
  }

  private void hideCard() {
    if (panel == null) return;
    handle.setVisibility(View.GONE);
    minimize.setVisibility(View.GONE);
    summary.setVisibility(View.GONE);
    decision.setVisibility(View.GONE);
    close.setVisibility(View.GONE);
    metrics.setVisibility(View.GONE);
    bottom.setVisibility(View.GONE);
    icon.setVisibility(View.VISIBLE);
    layout.width = dp(66);
    try {
      windows.updateViewLayout(panel, layout);
    } catch (RuntimeException ignored) {
    }
  }

  @Override
  public IBinder onBind(Intent i) {
    return null;
  }

  @Override
  public void onDestroy() {
    handler.removeCallbacksAndMessages(null);
    if (panel != null)
      try {
        windows.removeView(panel);
      } catch (RuntimeException ignored) {
      }
    if (tone != null) tone.release();
    instance = null;
    super.onDestroy();
  }
}
