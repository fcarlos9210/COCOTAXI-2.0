package com.cocotaxi.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Native reference-inspired UI: live figures replace all illustrative values. */
public final class MainActivity extends Activity {
  private static java.lang.ref.WeakReference<MainActivity> foreground =
      new java.lang.ref.WeakReference<>(null);

  /** Only the resumed Coco activity can be minimized by its own floating icon. */
  public static boolean minimizeFromOverlay() {
    MainActivity activity = foreground.get();
    return activity != null && !activity.isFinishing() && !activity.isDestroyed()
        && activity.moveTaskToBack(true);
  }

  private CocoStore.Session dashboardSession() {
    CocoStore.Session session = CocoStore.get(this).session();
    return session.active ? session : new CocoStore.Session();
  }

  private static final int BG = 0xff000d10,
      PANEL = 0xff00251d,
      GREEN = 0xff67ff37,
      WHITE = 0xfff2f6fa,
      MUTED = 0xffb9c9d9,
      RED = 0xffff4258;
  private int tab = 0;
  private boolean advanced = false;
  private int historyPage;
  private boolean permissionDialog, permissionDeferred;
  private LinearLayout body;
  private SettingsStore.Values draft;
  private final Map<String, EditText> inputs = new LinkedHashMap<>();
  private final Map<String, String> draftText = new LinkedHashMap<>();
  private final Handler handler = new Handler(Looper.getMainLooper());
  private final List<Runnable> refreshers = new ArrayList<>();
  private String selectedSession = "";
  private ScreenOcrEngine ocr;
  private final Runnable tick =
      new Runnable() {
        public void run() {
          for (Runnable r : new ArrayList<>(refreshers)) r.run();
          handler.postDelayed(this, 2000);
        }
      };

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    LegacyImport.run(this);
    if (state != null) {
      tab = state.getInt("tab");
      advanced = state.getBoolean("advanced");
      draft = (SettingsStore.Values) state.getSerializable("values");
      selectedSession = state.getString("selected", "");
      Bundle b = state.getBundle("draft");
      if (b != null) for (String k : b.keySet()) draftText.put(k, b.getString(k));
    }
    render();
  }

  @Override
  public void onResume() {
    super.onResume();
    foreground = new java.lang.ref.WeakReference<>(this);
    if (tab != 3) render();
    handler.removeCallbacks(tick);
    handler.post(tick);
    handler.post(this::checkPermissions);
    if (CocoStore.get(this).session().active && Settings.canDrawOverlays(this))
      startForegroundService(new Intent(this, CocotaxiOverlayService.class));
  }

  @Override
  public void onPause() {
    if (foreground.get() == this) foreground.clear();
    super.onPause();
    handler.removeCallbacks(tick);
  }

  @Override
  public void onDestroy() {
    handler.removeCallbacksAndMessages(null);
    if (ocr != null) ocr.close();
    if (foreground.get() == this) foreground.clear();
    super.onDestroy();
  }

  @Override
  protected void onSaveInstanceState(Bundle b) {
    super.onSaveInstanceState(b);
    b.putInt("tab", tab);
    b.putBoolean("advanced", advanced);
    b.putSerializable("values", draft);
    b.putString("selected", selectedSession);
    if (tab == 3) {
      captureDraft();
      Bundle d = new Bundle();
      for (Map.Entry<String, String> e : draftText.entrySet())
        d.putString(e.getKey(), e.getValue());
      b.putBundle("draft", d);
    }
  }

  private int dp(float n) {
    return Math.round(n * getResources().getDisplayMetrics().density);
  }

  private LinearLayout col() {
    LinearLayout l = new LinearLayout(this);
    l.setOrientation(LinearLayout.VERTICAL);
    return l;
  }

  private LinearLayout row() {
    LinearLayout l = new LinearLayout(this);
    l.setGravity(Gravity.CENTER_VERTICAL);
    return l;
  }

  private GradientDrawable background(int color, int stroke) {
    GradientDrawable d =
        new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {color, BG});
    d.setCornerRadius(dp(16));
    d.setStroke(dp(1), stroke);
    return d;
  }

  private TextView text(String s, float size, int color) {
    TextView t = new TextView(this);
    t.setText(s);
    t.setTextSize(size);
    t.setTextColor(color);
    t.setIncludeFontPadding(false);
    t.setPadding(0, dp(3), 0, dp(3));
    return t;
  }

  private TextView bold(String s, float size, int color) {
    TextView t = text(s, size, color);
    t.setTypeface(null, Typeface.BOLD);
    return t;
  }

  private TextView button(String s, Runnable action) {
    TextView t = bold(s, 14, GREEN);
    t.setGravity(Gravity.CENTER);
    t.setMinHeight(dp(46));
    t.setPadding(dp(10), dp(8), dp(10), dp(8));
    t.setBackground(background(PANEL, 0xff24815c));
    t.setOnClickListener(v -> action.run());
    return t;
  }

  private LinearLayout card(LinearLayout parent, String title, int icon) {
    LinearLayout c = col();
    c.setPadding(dp(12), dp(10), dp(12), dp(10));
    c.setBackground(background(PANEL, 0xff219a65));
    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
    p.bottomMargin = dp(8);
    parent.addView(c, p);
    if (title != null) {
      LinearLayout h = row();
      LineIconView i = new LineIconView(this, icon);
      i.setIconColor(GREEN);
      h.addView(i, new LinearLayout.LayoutParams(dp(25), dp(25)));
      TextView t = bold("  " + title, 16, WHITE);
      h.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
      c.addView(h);
      gap(c, 5);
    }
    return c;
  }

  private void gap(LinearLayout l, int h) {
    View v = new View(this);
    l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
  }

  private void metric(LinearLayout row, String title, String value, int color) {
    LinearLayout c = col();
    c.setPadding(dp(3), dp(4), dp(3), dp(4));
    TextView label = text(title, 11, MUTED);
    label.setGravity(Gravity.CENTER);
    label.setMaxLines(2);
    c.addView(label);
    TextView v = bold(value, 23, color);
    v.setGravity(Gravity.CENTER);
    v.setMaxLines(1);
    v.setAutoSizeTextTypeUniformWithConfiguration(
        11, 23, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
    c.addView(v, new LinearLayout.LayoutParams(-1, dp(32)));
    row.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
  }

  private void compactMetric(LinearLayout r, String label, String value, int color) {
    metric(r, label, value, color);
    LinearLayout c = (LinearLayout) r.getChildAt(r.getChildCount() - 1);
    c.setPadding(dp(2), dp(1), dp(2), dp(1));
    TextView t = (TextView) c.getChildAt(1);
    t.getLayoutParams().height = dp(25);
    t.setAutoSizeTextTypeUniformWithConfiguration(10, 20, 1, 2);
  }

  private void updateMetrics(LinearLayout r, String[] values) {
    for (int i = 0; i < values.length; i++) {
      LinearLayout c = (LinearLayout) r.getChildAt(i);
      ((TextView) c.getChildAt(1)).setText(values[i]);
    }
  }

  private void line(LinearLayout c, String label, String value, int color) {
    LinearLayout r = row();
    TextView l = text(label, 13, MUTED);
    r.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
    TextView v = bold(value, 14, color);
    r.addView(v);
    c.addView(r);
  }

  private void progress(LinearLayout c, double value) {
    ProgressBar p = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
    p.setMax(1000);
    p.setProgress((int) Math.max(0, Math.min(1000, value * 1000)));
    p.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
    p.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1b3946));
    c.addView(p, new LinearLayout.LayoutParams(-1, dp(15)));
  }

  private void render() {
    refreshers.clear();
    inputs.clear();
    LinearLayout root = col();
    root.setBackgroundColor(BG);
    root.setPadding(dp(10), 0, dp(10), 0);
    root.setOnApplyWindowInsetsListener(
        (v, insets) -> {
          int top = insets.getSystemWindowInsetTop(), bottom = insets.getSystemWindowInsetBottom();
          v.setPadding(dp(10), top, dp(10), bottom);
          return insets;
        });
    LinearLayout header = row();
    header.setPadding(dp(3), dp(6), 0, dp(6));
    RoundedIconView logo = new RoundedIconView(this);
    logo.setContentDescription("El Coco");
    header.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
    LinearLayout brand = col();
    brand.setPadding(dp(9), 0, 0, 0);
    TextView name = bold("COCOTAXI", 27, WHITE);
    name.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
    android.text.SpannableString span = new android.text.SpannableString("COCOTAXI");
    span.setSpan(new android.text.style.ForegroundColorSpan(GREEN), 4, 8, 0);
    name.setText(span);
    brand.addView(name);
    TextView sub = text("C O N D U C T O R", 10, MUTED);
    brand.addView(sub);
    header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
    root.addView(header);
    ScrollView scroll = new ScrollView(this);
    scroll.setFillViewport(true);
    scroll.setClipToPadding(false);
    body = col();
    scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
    root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    if (tab == 0) home();
    else if (tab == 1) history();
    else if (tab == 2) goals();
    else settings();
    LinearLayout nav = row();
    String[] labels = {"Inicio", "Sesión", "Metas", "Ajustes"};
    int[] icons = {LineIconView.HOME, LineIconView.CLOCK, LineIconView.TARGET, LineIconView.GEAR};
    for (int n = 0; n < 4; n++) {
      final int target = n;
      LinearLayout item = col();
      item.setGravity(Gravity.CENTER);
      item.setPadding(0, dp(6), 0, dp(5));
      LineIconView i = new LineIconView(this, icons[n]);
      i.setIconColor(n == tab ? GREEN : MUTED);
      item.addView(i, new LinearLayout.LayoutParams(dp(25), dp(25)));
      TextView navLabel = text(labels[n], 12, n == tab ? GREEN : MUTED);
      navLabel.setGravity(Gravity.CENTER);
      item.addView(navLabel);
      View indicator = new View(this);
      indicator.setBackgroundColor(n == tab ? GREEN : BG);
      item.addView(indicator, new LinearLayout.LayoutParams(dp(42), dp(2)));
      item.setContentDescription(labels[n]);
      item.setOnClickListener(
          v -> {
            if (tab == 3) captureDraft();
            tab = target;
            render();
          });
      nav.addView(item, new LinearLayout.LayoutParams(0, dp(58), 1));
    }
    root.addView(nav);
    setContentView(root);
    root.requestApplyInsets();
  }

  private void home() {
    SettingsStore.Values v = SettingsStore.load(this);
    CocoStore.Session s = dashboardSession();
    LinearLayout controls = row();
    controls.addView(
        button(
            s.active && s.paused ? "▶ Reanudar" : "▶ Conectar",
            () -> {
              CocoStore st = CocoStore.get(this);
              if (st.session().paused) st.pause();
              else st.start();
              startOverlay();
              render();
            }),
        new LinearLayout.LayoutParams(0, -2, 1));
    controls.addView(
        button(
            "Ⅱ Pausar",
            () -> {
              if (CocoStore.get(this).session().active && !CocoStore.get(this).session().paused)
                CocoStore.get(this).pause();
              CocotaxiOverlayService.clearOffer();
              render();
            }),
        new LinearLayout.LayoutParams(0, -2, 1));
    controls.addView(button("■ Desconectar", this::stop), new LinearLayout.LayoutParams(0, -2, 1));
    body.addView(controls);
    gap(body, 8);
    LinearLayout status = card(body, null, 0);
    LinearLayout sr = row();
    metric(
        sr,
        s.active ? (s.paused ? "PAUSA" : "CONECTADO") : "DESCONECTADO",
        duration(s.minutes),
        GREEN);
    metric(sr, "OBJETIVO REAL", Money.format(v.realGoalHour) + "/h", WHITE);
    status.addView(sr);
    LinearLayout main = card(body, "PROMEDIO · CONFIRMADO + ESTIMADO", LineIconView.CHART);
    LinearLayout r = row();
    LinearLayout left = col();
    TextView avg = bold(Money.format(s.hourly()) + "/h", 42, GREEN);
    avg.setMaxLines(1);
    avg.setAutoSizeTextTypeUniformWithConfiguration(24, 42, 1, 2);
    left.addView(avg, new LinearLayout.LayoutParams(-1, dp(63)));
    TextView tag = text("", 12, WHITE);
    left.addView(tag);
    r.addView(left, new LinearLayout.LayoutParams(0, -2, 2));
    GaugeView gauge = new GaugeView(this, s.hourly() / v.realGoalHour);
    r.addView(gauge, new LinearLayout.LayoutParams(0, dp(80), 1.2f));
    main.addView(r);
    LinearLayout figures = row();
    metric(figures, "OBJETIVO ACUM.", Money.format(v.realGoalHour * s.minutes / 60), WHITE);
    metric(figures, "GANADO", Money.format(s.money), GREEN);
    metric(
        figures,
        "FALTA",
        Money.format(Math.max(0, v.realGoalHour * s.minutes / 60 - s.money)),
        RED);
    main.addView(figures);
    TextView pending = text("", 12, MUTED);
    main.addView(pending);
    LinearLayout session = card(body, "Tu sesión", LineIconView.CLOCK);
    LinearLayout stats = row();
    metric(stats, "Viajes", String.valueOf(s.trips), WHITE);
    
    metric(stats, "Sin viaje", duration(Math.max(0, s.minutes - s.service)), WHITE);
    metric(stats, "En servicio", duration(s.service), WHITE);
    session.addView(stats);
    progress(session, s.hourly() / v.realGoalHour);
    session.addView(
        button(
            "Ver y corregir viajes  ›",
            () -> {
              selectedSession = "";
              tab = 1;
              render();
            }));
    TextView pace = text("", 13, GREEN);
    session.addView(pace);
    TextView promoButton = button("", this::promotion);
    body.addView(promoButton);
    refreshers.add(
        () -> {
          CocoStore.Session live = dashboardSession();
          avg.setText(Money.format(live.hourly()) + "/h");
          gauge.setFraction(live.hourly() / v.realGoalHour);
          tag.setText(
              live.minutes == 0
                  ? "INICIA PARA MEDIR"
                  : live.hourly() >= v.realGoalHour ? "EN OBJETIVO" : "POR DEBAJO DEL OBJETIVO");
          tag.setTextColor(live.hourly() >= v.realGoalHour ? GREEN : RED);
          pending.setText(
              live.pending > 0
                  ? live.pending
                      + " pagos por confirmar · "
                      + Money.exact(live.estimated)
                      + " estimados · " + Money.exact(live.money-live.estimated) + " confirmados"
                  : "Ingresos confirmados · sin propinas");
          updateMetrics(
              sr, new String[] {duration(live.minutes), Money.format(v.realGoalHour) + "/h"});
          updateMetrics(
              figures,
              new String[] {
                Money.format(v.realGoalHour * live.minutes / 60),
                Money.format(live.money),
                Money.format(Math.max(0, v.realGoalHour * live.minutes / 60 - live.money))
              });
          updateMetrics(
              stats,
              new String[] {
                String.valueOf(live.trips),
                duration(Math.max(0, live.minutes - live.service)),
                duration(live.service)
              });
          double needed = PromotionMath.requiredHourly(v.dailyGoal, v.targetHoursDay, live.minutes, live.money);
          pace.setText(live.minutes >= v.targetHoursDay*60
              ? "Tiempo previsto agotado · faltan " + Money.format(Math.max(0,v.dailyGoal-live.money))
              : "Para tu meta diaria: " + Money.format(needed) + "/h desde ahora");
          promoButton.setText(PromotionStore.get(this).description() + "  ›");
        });
  }

  private void startOverlay() {
    if (Build.VERSION.SDK_INT >= 33
        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 91);
    startForegroundService(new Intent(this, CocotaxiOverlayService.class));
  }

  private void stop() {
    CocoStore.Trip t = CocoStore.get(this).activeTrip();
    if (t != null) {
      new AlertDialog.Builder(this)
          .setTitle("Viaje pendiente")
          .setMessage("Confirma si terminó antes de cerrar la sesión.")
          .setPositiveButton(
              "Ver viaje",
              (d, w) -> {
                tab = 1;
                render();
              })
          .setNegativeButton(
              "Cerrar sesión",
              (d, w) -> {
                CocoStore.get(this).status(t.id, "SIN CONFIRMAR");
                finishSession();
              })
          .show();
    } else finishSession();
  }

  private void finishSession() {
    CocoStore.get(this).stop();
    selectedSession = "";
    historyPage = 0;
    stopService(new Intent(this, CocotaxiOverlayService.class));
    stopService(new Intent(this, CaptureService.class));
    render();
  }

  private void history() {
    CocoStore store = CocoStore.get(this);
    CocoStore.Session current = store.session();
    String id = selectedSession.isEmpty() ? current.id : selectedSession;
    LinearLayout head = card(body, "Historial por sesión", LineIconView.CLOCK);
    head.addView(
        text(
            "Solo los viajes finalizados suman. Elimina un error o confirma el pago real sin"
                + " duplicarlo.",
            13,
            MUTED));
    head.addView(
        button(
            "Elegir sesión",
            () -> {
              List<CocoStore.Session> ss = store.sessions();
              String[] names = new String[ss.size()];
              for (int n = 0; n < ss.size(); n++)
                names[n] = stamp(ss.get(n).start) + " · " + Money.exact(ss.get(n).money);
              new AlertDialog.Builder(this)
                  .setTitle("Sesiones")
                  .setItems(
                      names,
                      (d, w) -> {
                        selectedSession = ss.get(w).id;
                        render();
                      })
                  .show();
            }));
    head.addView(button("＋ Registrar viaje manual", this::manualIncome));
    List<CocoStore.Trip> trips = store.trips(id);
    if (trips.isEmpty()) head.addView(text("Todavía no hay viajes en esta sesión.", 14, WHITE));
    int pages = Math.max(1, (trips.size()+1)/2);
    historyPage = Math.max(0,Math.min(historyPage,pages-1));
    LinearLayout pageControls = row();
    pageControls.addView(button("‹ Anterior", () -> { historyPage=Math.max(0,historyPage-1); render(); }),new LinearLayout.LayoutParams(0,-2,1));
    pageControls.addView(text((historyPage+1)+" / "+pages,14,WHITE));
    pageControls.addView(button("Siguiente ›", () -> { historyPage=Math.min(pages-1,historyPage+1); render(); }),new LinearLayout.LayoutParams(0,-2,1));
    head.addView(pageControls);
    for (CocoStore.Trip t : trips.subList(historyPage*2,Math.min(trips.size(),historyPage*2+2))) {
      LinearLayout card = card(body, stamp(t.at), LineIconView.CAR);
      line(
          card,
          t.deleted ? "ELIMINADO" : t.status,
          Money.exact(t.net()),
          t.deleted ? MUTED : GREEN);
      card.addView(
          text(
              (t.confirmed ? "Pago confirmado" : "Pago estimado")
                  + " · oferta "
                  + Money.exact(t.offered)
                  + "\n"
                  + t.label,
              12,
              MUTED));
      LinearLayout buttons = row();
      if (!t.deleted) {
        buttons.addView(
            button("Corregir / confirmar", () -> correct(t)),
            new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(
            button(
                "Eliminar",
                () -> {
                  store.delete(t.id);
                  render();
                }),
            new LinearLayout.LayoutParams(0, -2, 1));
      } else
        buttons.addView(
            button(
                "Deshacer eliminación",
                () -> {
                  store.restore(t.id);
                  render();
                }));
      card.addView(buttons);
    }
  }

  private LinearLayout form() {
    LinearLayout c = col();
    c.setPadding(dp(18), dp(5), dp(18), dp(5));
    return c;
  }

  private EditText field(LinearLayout c, String label, String value) {
    c.addView(text(label, 12, MUTED));
    EditText e = new EditText(this);
    e.setTextColor(WHITE);
    e.setSingleLine(true);
    e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
    e.setText(value);
    e.setSelectAllOnFocus(true);
    e.setMinHeight(dp(44));
    c.addView(e, new LinearLayout.LayoutParams(-1, -2));
    return e;
  }

  private double number(EditText e) {
    double n = Money.parse(e.getText().toString());
    if (!Double.isFinite(n) || n < 0) throw new IllegalArgumentException("Revisa " + e.getText());
    return n;
  }

  private String decimal(double n) {
    return String.format(Locale.US, "%.2f", n);
  }

  private AlertDialog dialog(String title, LinearLayout form, String action, Runnable save) {
    ScrollView s = new ScrollView(this);
    s.addView(form);
    AlertDialog d =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(s)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton(action, null)
            .create();
    d.setOnShowListener(
        v ->
            d.getButton(-1)
                .setOnClickListener(
                    b -> {
                      try {
                        save.run();
                        d.dismiss();
                        render();
                      } catch (Exception e) {
                        toast(e.getMessage());
                      }
                    }));
    d.show();
    return d;
  }

  private void manualIncome() {
    LinearLayout c = form();
    EditText amount = field(c, "Cobro real sin propina ni peajes (UYU)", ""),
        minutes = field(c, "Minutos de recogida y servicio", "0");
    Switch trip = new Switch(this);
    trip.setText("Cuenta como viaje (desactivar para bono o extra)");
    trip.setTextColor(WHITE);
    trip.setChecked(true);
    c.addView(trip);
    c.addView(
        text(
            "Para corregir un viaje existente, usa su botón Corregir. Los bonos se registran al"
                + " cobrarlos, nunca antes.",
            12,
            MUTED));
    dialog(
        "Registrar ingreso",
        c,
        "Guardar",
        () ->
            CocoStore.get(this)
                .manual(
                    number(amount),
                    number(minutes),
                    trip.isChecked() ? "Viaje manual" : "Extra cobrado",
                    trip.isChecked()));
  }

  private void correct(CocoStore.Trip t) {
    LinearLayout c = form();
    EditText
        amount =
            field(
                c, "Pago real sin propina ni peajes", decimal(t.confirmed ? t.actual : t.estimate)),
        cost = field(c, "Gastos del viaje", decimal(t.cost)),
        ordinary =
            field(
                c,
                "Pago ordinario sin bonos, propina ni peajes",
                decimal(t.ordinary > 0 ? t.ordinary : t.confirmed ? t.actual : t.estimate));
    Switch pair = new Switch(this);
    pair.setText("Oferta y pago verificados del mismo viaje");
    pair.setTextColor(WHITE);
    pair.setChecked(t.pair);
    pair.setEnabled(t.offered > 0);
    c.addView(pair);
    c.addView(
        text(
            "Confirmar marca el viaje como finalizado. El factor aprende solo de parejas"
                + " verificadas; no incluye ingresos manuales sin oferta.",
            12,
            MUTED));
    dialog(
        "Confirmar / corregir viaje",
        c,
        "Guardar",
        () ->
            CocoStore.get(this)
                .correct(t.id, number(amount), number(cost), pair.isChecked(), number(ordinary)));
  }

  private void goals() {
    CocoStore store = CocoStore.get(this);
    CocoStore.Session session = dashboardSession();
    SettingsStore.Values v = SettingsStore.load(this);
    CocoStore.Totals week = store.period(CocoStore.weekStart(System.currentTimeMillis()),System.currentTimeMillis()+1);
    LinearLayout day = card(body,"META DE LA JORNADA",LineIconView.TARGET);
    line(day,"Objetivo",Money.format(v.dailyGoal),GREEN);
    line(day,"Acumulado",Money.exact(session.money),WHITE);
    line(day,"Falta",Money.format(Math.max(0,v.dailyGoal-session.money)),RED);
    progress(day,session.money/v.dailyGoal);
    day.addView(text("La jornada continúa al cruzar medianoche. Incluye la espera entre viajes.",12,MUTED));
    LinearLayout weekly=card(body,"SEMANA · LUNES A DOMINGO",LineIconView.CALENDAR);
    line(weekly,"Objetivo",Money.format(v.weeklyGoal),GREEN);
    line(weekly,"Acumulado",Money.exact(week.money),WHITE);
    progress(weekly,week.money/v.weeklyGoal);
    weekly.addView(text(week.pending+" pagos estimados pendientes de confirmar",12,MUTED));
    LinearLayout payment=card(body,"COMPROBAR COBROS",LineIconView.WALLET);
    payment.addView(button("Registrar liquidación diaria",()->billing(null)));
    payment.addView(button("Registrar ingreso o premio cobrado",this::manualIncome));
    payment.addView(text("No sumes un premio si ya está incluido en los pagos registrados. Las propinas no se usan para predecir.",12,MUTED));
  }

  private void promotion() {
    if (!CocoStore.get(this).session().active) { toast("Inicia la sesión para configurar su promoción"); return; }
    PromotionStore.Snapshot old = PromotionStore.get(this);
    LinearLayout c=form();
    final AlertDialog[] promotionDialog={null};
    DateTimeFormatter fmt=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    LocalDateTime now=LocalDateTime.now(CocoStore.ZONE);
    EditText bonus=field(c,"Premio anunciado (UYU)",decimal(old.target>0?old.bonus:1100));
    EditText target=field(c,"Total de viajes exigidos",String.valueOf(old.target>0?old.target:13));
    EditText done=field(c,"Viajes válidos ya completados",String.valueOf(old.completed));
    EditText start=field(c,"Inicio · fecha y hora",old.target>0?Instant.ofEpochMilli(old.start).atZone(CocoStore.ZONE).format(fmt):now.format(fmt));
    EditText end=field(c,"Fin · fecha y hora",old.target>0?Instant.ofEpochMilli(old.end).atZone(CocoStore.ZONE).format(fmt):now.plusHours(4).format(fmt));
    start.setInputType(InputType.TYPE_CLASS_TEXT); end.setInputType(InputType.TYPE_CLASS_TEXT);
    LinearLayout presets=row();
    for(int h:new int[]{19,23,3}) {
      presets.addView(button(String.format(Locale.US,"%02d–%02d",h,(h+4)%24),()->{
        LocalDateTime from=now.toLocalDate().atTime(h,0);
        if(h==23 && now.getHour()<3) from=from.minusDays(1);
        if(!now.isBefore(from.plusHours(4))) from=from.plusDays(1);
        start.setText(from.format(fmt)); end.setText(from.plusHours(4).format(fmt));
      }),new LinearLayout.LayoutParams(0,-2,1));
    }
    c.addView(presets);
    c.addView(text(old.samples>=3?"Ritmo observado: "+decimal(old.cycle)+" min por viaje, incluyendo esperas":"Sin ritmo suficiente: previsión inicial de 15 min por viaje",12,MUTED));
    c.addView(text("Cuenta viajes finalizados dentro del horario. Corrige el contador según Cabify si su promoción usa otra condición. El premio no se suma hasta registrar su cobro.",12,MUTED));
    c.addView(button("Desactivar promoción",()->{PromotionStore.clear(this);if(promotionDialog[0]!=null)promotionDialog[0].dismiss();toast("Promoción desactivada");render();}));
    promotionDialog[0]=dialog("Promoción de esta sesión",c,"Guardar",()->{
      double n=number(target), d=number(done);
      if(n!=(int)n || d!=(int)d) throw new IllegalArgumentException("Introduce cantidades enteras");
      long a=LocalDateTime.parse(start.getText().toString().trim(),fmt).atZone(CocoStore.ZONE).toInstant().toEpochMilli();
      long b=LocalDateTime.parse(end.getText().toString().trim(),fmt).atZone(CocoStore.ZONE).toInstant().toEpochMilli();
      PromotionStore.set(this,(int)n,number(bonus),a,b,(int)d);
    });
  }

  private void settings() {
    if (draft == null) draft=SettingsStore.load(this);
    if (advanced) { advancedSettings(); return; }
    SettingsStore.normalizeGoals(draft);
    LinearLayout goals=card(body,"TU OBJETIVO",LineIconView.TARGET);
    String[] names={"Por semana","Por jornada","Por hora"};
    for(int i=0;i<3;i++) {
      final int mode=i;
      Switch toggle=new Switch(this);
      toggle.setText(names[i]+"   "+Money.format(i==0?draft.weeklyGoal:i==1?draft.dailyGoal:draft.realGoalHour));
      toggle.setTextColor(i==draft.goalMode?GREEN:MUTED);
      toggle.setMinHeight(dp(44)); toggle.setChecked(i==draft.goalMode);
      toggle.setOnCheckedChangeListener((v,on)->{if(on) {draft.goalMode=mode;SettingsStore.normalizeGoals(draft);render();} else if(mode==draft.goalMode) toggle.setChecked(true);});
      goals.addView(toggle);
    }
    goals.addView(button("Cambiar importe seleccionado",this::editGoals));
    LinearLayout schedule=card(body,"JORNADA Y SEMANA",LineIconView.CLOCK);
    line(schedule,"Duración",decimal(draft.targetHoursDay)+" h",GREEN);
    line(schedule,"Días por semana",""+Integer.bitCount(draft.workDaysMask),WHITE);
    schedule.addView(button("Editar duración y días",this::editSchedule));
    body.addView(button("Pago, demanda y permisos  ›",()->{advanced=true;render();}));
    body.addView(button("Guardar ajustes",this::persistDraft));
  }
  private void editGoals() {
    LinearLayout c=form();
    int mode=draft.goalMode;
    EditText amount=field(c,mode==0?"Meta semanal":mode==1?"Meta por jornada":"Meta por hora",
        decimal(mode==0?draft.weeklyGoal:mode==1?draft.dailyGoal:draft.realGoalHour));
    c.addView(text("Las otras dos metas se calculan automáticamente.",12,MUTED));
    dialog("Tu meta",c,"Aplicar",()->{
      double n=number(amount);
      if(n<=0 || n>1000000) throw new IllegalArgumentException("Importe entre 1 y 1.000.000");
      if(mode==0) draft.weeklyGoal=n; else if(mode==1) draft.dailyGoal=n; else draft.realGoalHour=n;
      SettingsStore.normalizeGoals(draft);
    });
  }
  private void editSchedule() {
    LinearLayout c=form();
    EditText hours=field(c,"Horas por jornada",decimal(draft.targetHoursDay));
    final int[] mask={draft.workDaysMask};
    String[] days={"Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"};
    for(int i=0;i<7;i++) {
      final int bit=i; CheckBox b=new CheckBox(this);b.setText(days[i]);b.setTextColor(WHITE);
      b.setChecked((mask[0]&(1<<i))!=0);
      b.setOnCheckedChangeListener((v,on)->{if(on)mask[0]|=1<<bit;else mask[0]&=~(1<<bit);});c.addView(b);
    }
    dialog("Horario previsto",c,"Aplicar",()->{
      double h=number(hours);if(h<1||h>18||mask[0]==0)throw new IllegalArgumentException("Elige 1–18 horas y al menos un día");
      draft.targetHoursDay=h;draft.workDaysMask=mask[0];SettingsStore.normalizeGoals(draft);
    });
  }

  private void persistDraft() {
    try {
      if (draft.autoAccept && draft.payoutMode == 0)
        throw new IllegalArgumentException(
            "Configura el pago antes de activar la aceptación automática");
      SettingsStore.save(this, draft);
      draft = null;
      draftText.clear();
      stopService(new Intent(this, CocotaxiOverlayService.class));
      if (CocoStore.get(this).session().active) startOverlay();
      toast("Ajustes guardados");
      render();
    } catch (Exception e) {
      toast(e.getMessage());
    }
  }

  private void advancedSettings() {
    body.addView(button("‹ Volver a Ajustes",()->{advanced=false;render();}));
    LinearLayout c=card(body,"PAGO Y RECOMENDACIONES",LineIconView.GEAR);
    c.addView(button("Estimación del cobro",this::editPayment));
    c.addView(button("Tiempos y límites",this::editTimes));
    c.addView(button("Demanda y aceptación",this::editAutomation));
    c.addView(button("Revisar permisos",()->{permissionDeferred=false;checkPermissions();}));
    c.addView(button("Registrar liquidación diaria",()->billing(null)));
    c.addView(button("Probar una oferta",this::demo));
    body.addView(button("Guardar ajustes",this::persistDraft));
  }
  private void editPayment() {
    LinearLayout c=form();
    final int[] mode={draft.payoutMode};
    spinner(c,"Modelo de pago",new String[]{"Sin calibrar","Factor manual","Parejas verificadas","Cierres diarios (provisional sin datos)"},mode[0],n->mode[0]=n);
    EditText factor=field(c,"Factor manual",decimal(draft.factor));
    EditText cost=field(c,"Gasto por km (0 para medir cobro)",decimal(draft.costKm));
    CocoStore.Calibration cal=CocoStore.get(this).dailyCalibration();
    c.addView(text("Factor diario: "+decimal(cal.factor)+(cal.provisional?" · provisional, precisión no validada":" · "+cal.count+" cierres")+". Usa el mismo período del historial y excluye propinas y premios.",12,MUTED));
    dialog("Cobro estimado",c,"Aplicar",()->{
      double f=number(factor),k=number(cost);if(f<.1||f>2||k>100)throw new IllegalArgumentException("Factor 0,1–2; gasto 0–100");
      draft.payoutMode=mode[0];draft.factor=f;draft.costKm=k;
    });
  }
  private void editTimes() {
    LinearLayout c=form();
    EditText wait=field(c,"Espera al pasajero (min)",decimal(draft.waitPassenger));
    c.addView(text("La espera real cuenta en tu sesión. No se añade una espera futura a las ofertas.",12,MUTED));
    EditText pickup=field(c,"Máxima recogida (min; 0 sin límite)",decimal(draft.maxPickupMin));
    EditText km=field(c,"Máxima recogida (km; 0 sin límite)",decimal(draft.maxPickupKm));
    dialog("Tiempos y recogida",c,"Aplicar",()->{
      double a=number(wait),d=number(pickup),e=number(km);
      if(a>60||d>60||e>30)throw new IllegalArgumentException("Revisa los límites de tiempo y distancia");
      draft.waitPassenger=a;draft.waitNext=0;draft.maxPickupMin=d;draft.maxPickupKm=e;
    });
  }
  private void editAutomation() {
    LinearLayout c=form();
    final int[] demand={draft.demandMode};
    final boolean[] flags={draft.mapDemand,draft.autoAccept,draft.floatingEnabled};
    spinner(c,"Demanda",new String[]{"Automática","Alta","Media","Baja"},demand[0],n->demand[0]=n);
    toggle(c,"Mostrar icono flotante","floating",flags[2],on->flags[2]=on);
    toggle(c,"Leer demanda del mapa","map",flags[0],on->flags[0]=on);
    toggle(c,"Aceptar oferta individual automáticamente","auto",flags[1],on->flags[1]=on);
    c.addView(text("En listas solo recomienda el mejor visible. Un intento fallido no suma. El premio de una promoción es condicionado, nunca ingreso anticipado.",12,MUTED));
    c.addView(button("Autorizar captura de respaldo",()->startActivityForResult(getSystemService(MediaProjectionManager.class).createScreenCaptureIntent(),92)));
    dialog("Demanda y aceptación",c,"Aplicar",()->{draft.demandMode=demand[0];draft.mapDemand=flags[0];draft.autoAccept=flags[1];draft.floatingEnabled=flags[2];});
  }

  private void checkPermissions() {
    if (isFinishing() || permissionDialog || permissionDeferred) return;
    Intent intent=null; String explanation="";
    if(!Settings.canDrawOverlays(this)) {
      intent=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));
      explanation="Activa Mostrar sobre otras aplicaciones para ver las recomendaciones de Coco.";
    } else {
      String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
      ComponentName own=new ComponentName(this,CocotaxiAccessibilityService.class);
      boolean found=false;
      if(enabled!=null)for(String entry:enabled.split(":"))if(own.equals(ComponentName.unflattenFromString(entry)))found=true;
      if(!found) {intent=new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);explanation="Activa COCOTAXI en Accesibilidad para leer las ofertas y reconocer viajes aceptados. La aceptación automática solo se activa en Ajustes.";}
    }
    if(intent==null) {
      if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED
          && !getPreferences(0).getBoolean("notificationAsked",false)) {
        getPreferences(0).edit().putBoolean("notificationAsked",true).apply();
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},91);
      }
      return;
    }
    permissionDialog=true; final Intent action=intent;
    new AlertDialog.Builder(this).setTitle("Preparar COCOTAXI").setMessage(explanation)
      .setPositiveButton("Autorizar",(d,w)->{permissionDialog=false;try{startActivity(action);}catch(Exception e){permissionDeferred=true;toast("Abre este permiso en los ajustes de Android");}})
      .setNegativeButton("Más tarde",(d,w)->{permissionDialog=false;permissionDeferred=true;})
      .setOnCancelListener(d->{permissionDialog=false;permissionDeferred=true;}).show();
  }

  private interface BoolChange {
    void set(boolean value);
  }

  private interface IntChange {
    void set(int value);
  }

  private void toggle(
      LinearLayout c, String label, String key, boolean initial, BoolChange action) {
    Switch s = new Switch(this);
    s.setText(label);
    s.setTextColor(WHITE);
    s.setTextSize(13);
    s.setPadding(0, dp(8), 0, dp(8));
    boolean value = draftText.containsKey(key) ? Boolean.parseBoolean(draftText.get(key)) : initial;
    s.setChecked(value);
    action.set(value);
    s.setOnCheckedChangeListener(
        (v, on) -> {
          action.set(on);
          draftText.put(key, String.valueOf(on));
        });
    c.addView(s, new LinearLayout.LayoutParams(-1, -2));
  }

  private void spinner(LinearLayout c, String title, String[] labels, int value, IntChange action) {
    c.addView(text(title, 12, MUTED));
    Spinner s = new Spinner(this);
    ArrayAdapter<String> a =
        new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels);
    s.setAdapter(a);
    s.setSelection(Math.max(0, Math.min(labels.length - 1, value)));
    s.setOnItemSelectedListener(
        new android.widget.AdapterView.OnItemSelectedListener() {
          public void onNothingSelected(android.widget.AdapterView<?> p) {}

          public void onItemSelected(android.widget.AdapterView<?> p, View v, int n, long id) {
            action.set(n);
          }
        });
    c.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
  }

  private void input(LinearLayout c, String key, String label, double value) {
    EditText e = field(c, label, draftText.getOrDefault(key, decimal(value)));
    inputs.put(key, e);
  }

  private void captureDraft() {
    for (Map.Entry<String, EditText> e : inputs.entrySet())
      draftText.put(e.getKey(), e.getValue().getText().toString());
  }

  private double value(String key, double min, double max) {
    double v = number(inputs.get(key));
    if (v < min || v > max)
      throw new IllegalArgumentException(key + ": debe estar entre " + min + " y " + max);
    return v;
  }

  private void billing(String raw) {
    LinearLayout c = form();
    c.addView(
        text(
            "Un registro por fecha; guardar otra vez lo reemplaza. El cierre enseña cuánto del"
                + " historial llega a ganancias. No añade ingresos por segunda vez. Stars queda"
                + " incluido; propinas y bonos extraordinarios se separan.",
            12,
            MUTED));
    EditText date = field(c, "Fecha (AAAA-MM-DD)", LocalDate.now(CocoStore.ZONE).toString());
    date.setInputType(InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_DATE);
    EditText total = field(c, "Total de ganancias", extract(raw, "total(?: de)? ganancias")),
        tips = field(c, "Propinas", "0"),
        bonus = field(c, "Bonos extraordinarios", "0"),
        tolls = field(c, "Peajes reembolsados incluidos", "0"),
        history = field(c, "Suma del historial del mismo día", "");
    Switch eligible = new Switch(this);
    eligible.setText("Día cerrado, historial completo y mismo importe que las ofertas");
    c.addView(eligible);
    c.addView(
        text(
            "Actívalo solo si coinciden día, conductor y todos los viajes. Los registros parciales"
                + " se guardan sin entrenar. No sumes Stars otra vez.",
            12,
            MUTED));
    if (raw != null) {
      c.addView(text("OCR para revisión:\n" + raw, 11, MUTED));
      String tip = extract(raw, "propinas?");
      if (!tip.isEmpty()) tips.setText(tip);
    }
    dialog(
        "Conciliar liquidación",
        c,
        "Guardar y comparar",
        () -> {
          double all = number(total),
              tip = number(tips),
              bon = number(bonus),
              toll = number(tolls),
              hist = number(history);
          CocoStore.get(this)
              .saveBilling(
                  date.getText().toString(), all, tip, bon, toll, hist, eligible.isChecked());
          new AlertDialog.Builder(this)
              .setTitle("Pago comparable: " + Money.exact(all - tip - bon - toll))
              .setMessage(
                  "Sin propinas, bonos extraordinarios ni reembolsos.\nFactor historial → pago: "
                      + (hist > 0
                          ? String.format(Locale.US, "%.6f", (all - tip - bon - toll) / hist)
                          : "sin suma de historial")
                      + (eligible.isChecked()
                          ? "\n"
                                + "Cierre incorporado al modelo diario. No es un cobro individual"
                                + " confirmado ni se suma otra vez a la sesión."
                          : "\nGuardado sin entrenar: cierre parcial o sin verificar."))
              .setPositiveButton("Entendido", null)
              .show();
        });
  }

  private String extract(String raw, String label) {
    if (raw == null) return "";
    java.util.regex.Matcher m =
        java.util.regex.Pattern.compile("(?:" + label + ")\\s*[:>]?\\s*\\$\\s*([0-9][0-9.,]*)")
            .matcher(OfferParser.normalize(raw));
    return m.find() ? decimal(Money.parse(m.group(1))) : "";
  }

  private void demo() {
    LinearLayout c = form();
    EditText e =
        field(c, "Texto de una tarjeta", "Para ti $188\n3 min · 339 m\n9 min · 4.1 km\nAceptar");
    e.setSingleLine(false);
    e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
    dialog(
        "Prueba sin registrar viajes",
        c,
        "Calcular",
        () -> {
          Offer o = OfferParser.parse(e.getText().toString(), "com.cabify.driver");
          CocoStore.Session s = CocoStore.get(this).session();
          s.active = true;
          s.paused = false;
          SettingsStore.Values v = SettingsStore.load(this);
          DecisionEngine.Result r =
              DecisionEngine.evaluate(
                  o, v, s, 2, CocoStore.get(this).calibrationForOffer(o.kind, v), PromotionStore.get(this));
          new AlertDialog.Builder(this)
              .setTitle("SIMULACIÓN · " + r.label())
              .setMessage(
                  r.reason
                      + "\nViaje: "
                      + Money.exact(r.hourly)
                      + "/h\nSesión después: "
                      + Money.exact(r.projected)
                      + "/h\nOferta mínima: "
                      + Money.exact(r.required))
              .setPositiveButton("Cerrar", null)
              .show();
        });
  }

  @Override
  protected void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (result != RESULT_OK || data == null) return;
    if (request == 92) {
      startForegroundService(
          new Intent(this, CaptureService.class).putExtra("code", result).putExtra("data", data));
      return;
    }
    if (request == 93 && data.getData() != null) {
      try {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
          BitmapFactory.decodeStream(in, null, options);
        }
        options.inSampleSize = Math.max(1, Math.max(options.outWidth, options.outHeight) / 2400);
        options.inJustDecodeBounds = false;
        Bitmap b;
        try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
          b = BitmapFactory.decodeStream(in, null, options);
        }
        if (b == null) throw new IllegalArgumentException("Imagen no válida");
        if (ocr == null) ocr = new ScreenOcrEngine();
        toast("Leyendo captura…");
        ocr.process(
            b,
            new ScreenOcrEngine.Callback() {
              public void onText(String t) {
                b.recycle();
                if (!isDestroyed()) billing(t);
              }

              public void onError(Exception e) {
                b.recycle();
                toast("No se pudo leer; introduce los datos manualmente");
              }
            });
      } catch (Exception e) {
        toast("No se pudo abrir la imagen");
      }
    }
  }

  private void toast(String s) {
    Toast.makeText(this, s == null ? "Revisa los datos" : s, Toast.LENGTH_LONG).show();
  }

  private static String duration(double minutes) {
    int m = (int) Math.max(0, minutes);
    return m < 60 ? m + " min" : m / 60 + " h " + m % 60;
  }

  private static String stamp(long time) {
    return DateTimeFormatter.ofPattern("dd/MM · HH:mm")
        .withZone(CocoStore.ZONE)
        .format(Instant.ofEpochMilli(time));
  }
}
