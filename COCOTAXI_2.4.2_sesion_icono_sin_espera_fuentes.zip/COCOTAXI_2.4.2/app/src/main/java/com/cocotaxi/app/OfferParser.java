package com.cocotaxi.app;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/** Parse one card only. Screen segmentation must happen before monetary extraction. */
public final class OfferParser {
  private static final Pattern PRICE =
      Pattern.compile("(?:\\$u?|u\\$|uyu)\\s*([0-9][0-9.,]*)", Pattern.CASE_INSENSITIVE);
  private static final Pattern MIN = Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*min(?:utos?)?\\b");
  private static final Pattern KM = Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*(km|m)\\b");

  public static String normalize(String s) {
    return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
        .replaceAll("\\p{M}", "")
        .toLowerCase(Locale.ROOT);
  }

  public static boolean isHistoryScreen(String text) {
    String s = normalize(text);
    return s.contains("historial")
        || s.contains("total ganancias")
        || s.contains("total a cobrar")
        || s.contains("precio base")
        || s.contains("comision reducida")
        || ((s.contains("billetera") || s.contains("promos")) && !DemandModel.isMapScreen(s));
  }

  public static boolean isLikelyOfferScreen(String text) {
    String s = normalize(text);
    return !isHistoryScreen(s)
        && (s.contains("aceptar")
            || s.contains("para ti")
            || s.contains("en app")
            || s.contains("viaje disponible"));
  }

  public static Offer parse(String text, String pkg) {
    Offer o = new Offer();
    o.rawText = text == null ? "" : text;
    o.platform = "Cabify";
    o.hasOfferSignal = isLikelyOfferScreen(text);
    String s = normalize(text);
    if (!o.hasOfferSignal) return o;
    o.kind = s.contains("para ti") ? "PARA_TI" : s.contains("en app") ? "EN_APP" : "UNKNOWN";
    String[] lines = s.split("\\n");
    List<Double> prices = new ArrayList<>();
    for (int i = 0; i < lines.length; i++) {
      String l = lines[i];
      Matcher m = PRICE.matcher(l);
      if (l.contains("peaje")) {
        if (m.find()) o.tolls = Money.parse(m.group(1));
        continue;
      }
      if (l.matches(".*(saldo|bono|extra|propina|incentivo|ganancias|/h|/km).*")) continue;
      while (m.find()) prices.add(Money.parse(m.group(1)));
    }
    if (prices.size() == 1) o.fare = prices.get(0);
    else if (prices.size() > 1) o.warning = "Más de un importe: tarjeta ambigua";
    Matcher m = MIN.matcher(s);
    List<double[]> legs = new ArrayList<>();
    List<Integer> starts = new ArrayList<>(), ends = new ArrayList<>();
    while (m.find()) {
      starts.add(m.start());
      ends.add(m.end());
      legs.add(new double[] {Money.metric(m.group(1)), -1});
    }
    for (int i = 0; i < legs.size(); i++) {
      String after = s.substring(ends.get(i), i + 1 < legs.size() ? starts.get(i + 1) : s.length());
      Matcher d = KM.matcher(after);
      if (d.find()) legs.get(i)[1] = Money.metric(d.group(1)) / (d.group(2).equals("m") ? 1000 : 1);
    }
    if (legs.size() == 2) {
      o.pickupMin = legs.get(0)[0];
      o.pickupKm = legs.get(0)[1];
      o.tripMin = legs.get(1)[0];
      o.tripKm = legs.get(1)[1];
    } else
      o.warning = legs.size() > 2 ? "Varias rutas: no mezclar tarjetas" : "Faltan los dos tiempos";
    o.key =
        o.kind
            + "|"
            + o.fare
            + "|"
            + o.pickupMin
            + "|"
            + o.tripMin
            + "|"
            + o.pickupKm
            + "|"
            + o.tripKm
            + "|"
            + s.replaceAll("\\s+", " ").trim();
    return o;
  }

  /** OCR fallback only accepts unambiguous cards separated by their Accept action. */
  public static List<Offer> parseVisible(String text) {
    List<Offer> out = new ArrayList<>();
    if (isHistoryScreen(text)) return out;
    String[] chunks = text.split("(?iu)(?<=aceptar)\\s*\\n");
    for (String chunk : chunks) {
      Offer o = parse(chunk, "com.cabify.driver");
      if (o.hasEnoughForDecision()) out.add(o);
    }
    return out;
  }
}
