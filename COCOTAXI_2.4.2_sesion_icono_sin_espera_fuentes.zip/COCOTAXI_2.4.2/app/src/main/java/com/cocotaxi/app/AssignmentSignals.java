package com.cocotaxi.app;

/** Assignment evidence from Cabify's pickup screen, not from generic map navigation. */
public final class AssignmentSignals {
  private AssignmentSignals() {}
  public static boolean isAssigned(String raw) {
    String text = OfferParser.normalize(raw);
    return !OfferParser.isHistoryScreen(text)
        && !text.contains("aceptar")
        && !text.contains("viaje cancelado")
        && !text.contains("otro conductor")
        && !text.contains("no se pudo aceptar")
        && text.contains("ir a origen")
        && text.contains("navegar")
        && text.contains("ver ruta");
  }
}
