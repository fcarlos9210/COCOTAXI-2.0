package com.cocotaxi.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.Locale;

public final class SettingsStore {
  public static final String PREFS = "cocotaxi_settings";

  public static final int MODE_AUTO = 0;
  public static final int MODE_HIGH = 1;
  public static final int MODE_MEDIUM = 2;
  public static final int MODE_LOW = 3;
  public static final int BASE_CONNECTED = 0;
  public static final int BASE_AVAILABLE = 1;
  public static final int BASE_DRIVING = 2;

  private static final String KEY_AUTO_CONFIG = "auto_config";
  private static final String KEY_WEEKLY_GOAL = "weekly_goal";
  private static final String KEY_REAL_GOAL_HOUR = "real_goal_hour";
  private static final String KEY_OPERATIONAL_GOAL_HOUR = "operational_goal_hour";
  private static final String KEY_OBJECTIVE_HOUR = "objective_hour";
  private static final String KEY_TARGET_HOURS_DAY = "target_hours_day";
  private static final String KEY_DAILY_GOAL = "daily_goal";
  private static final String KEY_HOURS_WEEK = "hours_week";
  private static final String KEY_MANUAL_MIN_HOUR = "manual_min_hour";
  private static final String KEY_MANUAL_MIN_KM = "manual_min_km";
  private static final String KEY_MAX_PICKUP_KM = "max_pickup_km";
  private static final String KEY_MAX_PICKUP_MIN = "max_pickup_min";
  private static final String KEY_EXCELLENT_MULTIPLIER = "excellent_multiplier";
  private static final String KEY_DEMAND_MODE = "demand_mode";
  private static final String KEY_WORK_DAYS = "work_days";
  private static final String KEY_TOLLS_ENABLED = "tolls_enabled";
  private static final String KEY_SOUND_ENABLED = "sound_enabled";
  private static final String KEY_FLOATING_ENABLED = "floating_enabled";
  private static final String KEY_BASE_MODE = "base_mode";

  private SettingsStore() {}

  public static Values load(Context context) {
    SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    Values values = new Values();
    values.autoConfig = prefs.getBoolean(KEY_AUTO_CONFIG, false);
    values.weeklyGoal = getDouble(prefs, KEY_WEEKLY_GOAL, 33600.0);
    values.realGoalHour = getDouble(prefs, KEY_REAL_GOAL_HOUR, 700.0);
    values.operationalGoalHour = getDouble(prefs, KEY_OPERATIONAL_GOAL_HOUR, 700.0);
    values.dailyGoal = getDouble(prefs, KEY_DAILY_GOAL, 5600.0);
    values.objectiveHour = getDouble(prefs, KEY_OBJECTIVE_HOUR, values.operationalGoalHour);
    values.targetHoursDay = getDouble(prefs, KEY_TARGET_HOURS_DAY, 11.0);
    values.hoursWeek = getDouble(prefs, KEY_HOURS_WEEK, 48.0);
    values.manualMinHour = getDouble(prefs, KEY_MANUAL_MIN_HOUR, 700.0);
    values.manualMinKm = getDouble(prefs, KEY_MANUAL_MIN_KM, 0.0);
    values.maxPickupKm = getDouble(prefs, KEY_MAX_PICKUP_KM, 4.0);
    values.maxPickupMin = getDouble(prefs, KEY_MAX_PICKUP_MIN, 10.0);
    values.excellentMultiplier = getDouble(prefs, KEY_EXCELLENT_MULTIPLIER, 1.35);
    values.demandMode = prefs.getInt(KEY_DEMAND_MODE, MODE_AUTO);
    values.workDaysMask = prefs.getInt(KEY_WORK_DAYS, 0x3F);
    values.tollsEnabled = prefs.getBoolean(KEY_TOLLS_ENABLED, true);
    values.soundEnabled = prefs.getBoolean(KEY_SOUND_ENABLED, true);
    values.floatingEnabled = prefs.getBoolean(KEY_FLOATING_ENABLED, true);
    values.baseMode = sanitizeBaseMode(prefs.getInt(KEY_BASE_MODE, BASE_CONNECTED));
    values.payoutMode = prefs.getInt("payout_mode", 3);
    if (values.payoutMode == 0 && !prefs.getBoolean("daily_model_v1", false)) values.payoutMode = 3;
    values.factor = getDouble(prefs, "factor", 1);
    values.costKm = getDouble(prefs, "cost_km", 0);
    values.waitPassenger = getDouble(prefs, "wait_passenger", 1);
    values.waitNext = 0; // Retired: never penalize offers with a hypothetical next wait.
    values.emptyKm = getDouble(prefs, "empty_km", 0);
    values.autoAccept = prefs.getBoolean("auto_accept", false);
    values.mapDemand = prefs.getBoolean("map_demand", false);
    values.vibrate = prefs.getBoolean("vibrate", false);
    values.recovery = prefs.getBoolean("recovery", true);
    values.deadStart = prefs.getInt("dead_start", 2);
    values.deadEnd = prefs.getInt("dead_end", 6);
    values.peakStart = prefs.getInt("peak_start", 17);
    values.peakEnd = prefs.getInt("peak_end", 23);
    values.goalMode = prefs.getInt("goal_mode", 1);
    normalizeGoals(values);
    return values;
  }

  public static void save(Context context, Values values) {
    normalizeGoals(values);
    SharedPreferences.Editor editor =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
    editor.putInt("goal_mode", values.goalMode);
    editor.putBoolean(KEY_AUTO_CONFIG, values.autoConfig);
    putDouble(editor, KEY_WEEKLY_GOAL, values.weeklyGoal);
    putDouble(editor, KEY_REAL_GOAL_HOUR, values.realGoalHour);
    putDouble(editor, KEY_OPERATIONAL_GOAL_HOUR, values.operationalGoalHour);
    putDouble(editor, KEY_DAILY_GOAL, values.dailyGoal);
    putDouble(editor, KEY_OBJECTIVE_HOUR, resolveObjectiveHour(values));
    putDouble(editor, KEY_TARGET_HOURS_DAY, clamp(values.targetHoursDay, 1.0, 18.0));
    putDouble(editor, KEY_HOURS_WEEK, values.hoursWeek);
    putDouble(editor, KEY_MANUAL_MIN_HOUR, values.manualMinHour);
    putDouble(editor, KEY_MANUAL_MIN_KM, clamp(values.manualMinKm, 0.0, 300.0));
    putDouble(editor, KEY_MAX_PICKUP_KM, clamp(values.maxPickupKm, 0.0, 30.0));
    putDouble(editor, KEY_MAX_PICKUP_MIN, clamp(values.maxPickupMin, 0.0, 60.0));
    putDouble(editor, KEY_EXCELLENT_MULTIPLIER, clamp(values.excellentMultiplier, 1.05, 3.0));
    editor.putInt(KEY_DEMAND_MODE, sanitizeMode(values.demandMode));
    editor.putInt(KEY_WORK_DAYS, values.workDaysMask & 0x7F);
    editor.putBoolean(KEY_TOLLS_ENABLED, values.tollsEnabled);
    editor.putBoolean(KEY_SOUND_ENABLED, values.soundEnabled);
    editor.putBoolean(KEY_FLOATING_ENABLED, values.floatingEnabled);
    editor.putInt(KEY_BASE_MODE, sanitizeBaseMode(values.baseMode));
    editor.putInt("payout_mode", values.payoutMode);
    editor.putBoolean("daily_model_v1", true);
    putDouble(editor, "factor", clamp(values.factor, .1, 2));
    putDouble(editor, "cost_km", clamp(values.costKm, 0, 100));
    putDouble(editor, "wait_passenger", clamp(values.waitPassenger, 0, 60));
    putDouble(editor, "wait_next", 0);
    putDouble(editor, "empty_km", clamp(values.emptyKm, 0, 100));
    editor
        .putBoolean("auto_accept", values.autoAccept)
        .putBoolean("map_demand", values.mapDemand)
        .putBoolean("vibrate", values.vibrate)
        .putBoolean("recovery", values.recovery);
    editor
        .putInt("dead_start", values.deadStart)
        .putInt("dead_end", values.deadEnd)
        .putInt("peak_start", values.peakStart)
        .putInt("peak_end", values.peakEnd);
    editor.apply();
  }

  public static void saveDemandMode(Context context, int mode) {
    context
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit()
        .putInt(KEY_DEMAND_MODE, sanitizeMode(mode))
        .apply();
  }

  public static int nextDemandMode(int current) {
    if (current == MODE_AUTO) return MODE_HIGH;
    if (current == MODE_HIGH) return MODE_MEDIUM;
    if (current == MODE_MEDIUM) return MODE_LOW;
    return MODE_AUTO;
  }

  public static int resolveDemandMode(Values values) {
    if (values.demandMode == MODE_AUTO) {
      return autoDemandMode(Calendar.getInstance());
    }
    return sanitizeMode(values.demandMode);
  }

  public static int autoDemandMode(Calendar calendar) {
    int day = calendar.get(Calendar.DAY_OF_WEEK);
    int hour = calendar.get(Calendar.HOUR_OF_DAY);

    if (day == Calendar.FRIDAY || day == Calendar.SATURDAY) {
      return MODE_HIGH;
    }
    if (day == Calendar.THURSDAY || day == Calendar.SUNDAY) {
      return MODE_MEDIUM;
    }
    return MODE_LOW;
  }

  public static String demandModeName(int mode) {
    int clean = sanitizeMode(mode);
    if (clean == MODE_AUTO) return "AUTO";
    if (clean == MODE_HIGH) return "ALTA";
    if (clean == MODE_MEDIUM) return "MEDIA";
    return "BAJA";
  }

  public static String resolvedDemandModeName(Values values) {
    if (values.demandMode == MODE_AUTO) {
      return "AUTO/" + demandModeName(resolveDemandMode(values));
    }
    return demandModeName(values.demandMode);
  }

  public static String money(double value) {
    return String.format(Locale.US, "$%.0f", value);
  }

  public static String signedMoney(double value) {
    if (value < 0) return String.format(Locale.US, "-$%.0f", Math.abs(value));
    return String.format(Locale.US, "$%.0f", value);
  }

  public static void normalizeGoals(Values v) {
    v.goalMode = Math.max(0, Math.min(2, v.goalMode));
    v.targetHoursDay = clamp(v.targetHoursDay, 1, 18);
    if ((v.workDaysMask & 127) == 0) v.workDaysMask = 63;
    int days = Integer.bitCount(v.workDaysMask & 127);
    double hourly = v.goalMode == 0 ? v.weeklyGoal / days / v.targetHoursDay
        : v.goalMode == 1 ? v.dailyGoal / v.targetHoursDay : v.realGoalHour;
    v.realGoalHour = clamp(hourly, 1, 50000);
    v.dailyGoal = v.realGoalHour * v.targetHoursDay;
    v.weeklyGoal = v.dailyGoal * days;
    v.operationalGoalHour = v.objectiveHour = v.manualMinHour = v.realGoalHour;
    v.hoursWeek = v.targetHoursDay * days;
    v.baseMode = BASE_CONNECTED;
  }

  public static double resolveObjectiveHour(Values v) { return resolveRealGoalHour(v); }
  public static double resolveRealGoalHour(Values v) {
    return clamp(v.realGoalHour > 0 ? v.realGoalHour : 500, 1, 50000);
  }

  public static double clamp(double value, double min, double max) {
    if (Double.isNaN(value) || Double.isInfinite(value)) return min;
    return Math.max(min, Math.min(max, value));
  }

  private static int sanitizeMode(int mode) {
    if (mode == MODE_HIGH || mode == MODE_MEDIUM || mode == MODE_LOW) return mode;
    return MODE_AUTO;
  }

  private static int sanitizeBaseMode(int mode) {
    if (mode == BASE_AVAILABLE || mode == BASE_DRIVING) return mode;
    return BASE_CONNECTED;
  }

  private static double getDouble(SharedPreferences prefs, String key, double fallback) {
    return Double.longBitsToDouble(prefs.getLong(key, Double.doubleToLongBits(fallback)));
  }

  private static void putDouble(SharedPreferences.Editor editor, String key, double value) {
    editor.putLong(key, Double.doubleToLongBits(value));
  }

  public static final class Values implements java.io.Serializable {
    public int goalMode = 1; // 0 weekly, 1 daily, 2 hourly; exclusive
    public int payoutMode, deadStart = 2, deadEnd = 6, peakStart = 17, peakEnd = 23;
    public double factor = 1, costKm, waitPassenger, waitNext, emptyKm;
    public boolean autoAccept, mapDemand, vibrate, recovery = true;
    public boolean autoConfig;
    public double weeklyGoal;
    public double realGoalHour;
    public double operationalGoalHour;
    public double dailyGoal;
    public double objectiveHour;
    public double targetHoursDay;
    public double hoursWeek;
    public double manualMinHour;
    public double manualMinKm;
    public double maxPickupKm;
    public double maxPickupMin;
    public double excellentMultiplier;
    public int demandMode;
    public int workDaysMask;
    public boolean tollsEnabled;
    public boolean soundEnabled;
    public boolean floatingEnabled;
    public int baseMode;
  }
}
