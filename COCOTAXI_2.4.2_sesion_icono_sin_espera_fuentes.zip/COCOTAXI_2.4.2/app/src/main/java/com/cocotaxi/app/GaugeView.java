package com.cocotaxi.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

public final class GaugeView extends View {
  private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final RectF arc = new RectF();
  private double fraction;

  public GaugeView(Context context, double fraction) {
    super(context);
    this.fraction = Math.max(0.0, Math.min(1.0, fraction));
  }

  public void setFraction(double fraction) {
    this.fraction = Math.max(0.0, Math.min(1.0, fraction));
    invalidate();
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    float w = getWidth();
    float h = getHeight();
    float s = Math.min(w, h);
    float stroke = Math.max(12f, s * 0.11f);
    float pad = stroke * 0.7f;

    arc.set(pad, pad, w - pad, h - pad);
    paint.setStyle(Paint.Style.STROKE);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeWidth(stroke);
    paint.setColor(Color.rgb(31, 63, 72));
    canvas.drawArc(arc, 135f, 270f, false, paint);
    if (fraction > 0.001) {
      paint.setColor(Color.rgb(103, 255, 55));
      canvas.drawArc(arc, 135f, (float) (270.0 * fraction), false, paint);
    }

    paint.setStyle(Paint.Style.FILL);
    paint.setTextAlign(Paint.Align.CENTER);
    paint.setTypeface(Typeface.DEFAULT_BOLD);
    paint.setColor(Color.rgb(103, 255, 55));
    paint.setTextSize(s * 0.23f);
    canvas.drawText(Math.round(fraction * 100.0) + "%", w / 2f, h * 0.5f, paint);

    paint.setTypeface(Typeface.DEFAULT);
    paint.setColor(Color.WHITE);
    paint.setTextSize(s * 0.105f);
    canvas.drawText("del objetivo", w / 2f, h * 0.66f, paint);
  }
}
