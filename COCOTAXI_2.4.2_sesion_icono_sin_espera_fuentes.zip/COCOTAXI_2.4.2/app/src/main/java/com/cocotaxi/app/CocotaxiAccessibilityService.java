package com.cocotaxi.app;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.Display;
import android.view.accessibility.*;
import java.util.*;

public final class CocotaxiAccessibilityService extends AccessibilityService {
  public static final String CABIFY = "com.cabify.driver";
  public static CocotaxiAccessibilityService instance;
  public static String diagnostic = "Activa Accesibilidad para leer Cabify";
  private final Handler handler = new Handler(Looper.getMainLooper());
  private ScreenOcrEngine ocr;
  private boolean processing;
  private boolean busy, destroyed;
  private long ocrAt, stableAt, clickedAt;
  private String stableKey = "";
  private final java.util.Map<String, Long> attemptedKeys = new java.util.HashMap<>();
  private List<Offer> previous = new ArrayList<>();
  private long previousAt;
  private Offer recentDetail;
  private String detailSession = "";
  private long detailAt;
  private boolean assignmentSeen;

  private void rememberDetail(List<Offer> cards, boolean individual) {
    // Never use the recommended card from a list as evidence of the user's selection.
    if (!individual || cards.size() != 1) {
      recentDetail = null;
      return;
    }
    recentDetail = cards.get(0);
    detailAt = SystemClock.elapsedRealtime();
    detailSession = CocoStore.get(this).session().id;
    assignmentSeen = false;
  }

  private void observeAssignment(String text) {
    CocoStore store = CocoStore.get(this);
    if (AssignmentSignals.isAssigned(text) && !assignmentSeen) {
      assignmentSeen = true;
      CocoStore.Session session = store.session();
      if (store.activeTrip() == null && recentDetail != null
          && session.id.equals(detailSession)
          && SystemClock.elapsedRealtime() - detailAt <= 45000) {
        SettingsStore.Values v = SettingsStore.load(this);
        DecisionEngine.Result r = DecisionEngine.evaluate(recentDetail, v, session,
            demand(v), store.calibrationForOffer(recentDetail.kind, v), PromotionStore.get(this));
        // Assignment is independent of the recommendation (including RECHAZAR).
        if (r.payout > 0) store.attempt(recentDetail, r, false);
      }
      recentDetail = null;
      if (store.activeTrip() == null)
        diagnostic = "Viaje asignado: importe no identificado; registra el viaje en Historial";
    }
    store.observe(text);
    if (AssignmentSignals.isAssigned(text) || store.activeTrip() != null)
      CocotaxiOverlayService.clearOffer();
  }
  private int mapSignal = -1;
  private long mapAt;
  private final Runnable poll =
      new Runnable() {
        public void run() {
          if (!destroyed) {
            inspect(null);
            handler.postDelayed(this, 1000);
          }
        }
      };

  @Override
  protected void onServiceConnected() {
    instance = this;
    handler.post(poll);
    diagnostic = "Accesibilidad conectada";
  }

  @Override
  public void onAccessibilityEvent(AccessibilityEvent event) {
    if (event == null) return;
    if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) manualClick(event);
    inspect(event);
  }

  private void manualClick(AccessibilityEvent e) {
    if (!CABIFY.contentEquals(e.getPackageName() == null ? "" : e.getPackageName())
        || SystemClock.elapsedRealtime() - clickedAt < 1500) return;
    AccessibilityNodeInfo n = e.getSource();
    if (n == null) return;
    try {
      String label =
          OfferParser.normalize(
                  String.valueOf(n.getText() == null ? n.getContentDescription() : n.getText()))
              .trim();
      if (!label.equals("aceptar") && !label.equals("aceptar viaje")) return;
      for (int i = 0; i < 8 && n != null; i++) {
        Offer o = OfferParser.parse(TextCollector.collect(n), CABIFY);
        if (o.hasEnoughForDecision()) {
          SettingsStore.Values v = SettingsStore.load(this);
          CocoStore store = CocoStore.get(this);
          DecisionEngine.Result r =
              DecisionEngine.evaluate(
                  o, v, store.session(), demand(v), store.calibrationForOffer(o.kind, v), PromotionStore.get(this));
          store.attempt(o, r, false);
          return;
        }
        AccessibilityNodeInfo parent = n.getParent();
        n.recycle();
        n = parent;
      }
    } finally {
      if (n != null) n.recycle();
    }
  }

  private int demand(SettingsStore.Values v) {
    return DemandModel.level(v, System.currentTimeMillis(), mapSignal, mapAt);
  }

  public boolean cabifyForeground() {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return false;
    try {
      return CABIFY.contentEquals(root.getPackageName() == null ? "" : root.getPackageName());
    } finally {
      root.recycle();
    }
  }

  private void inspect(AccessibilityEvent event) {
    CocoStore store = CocoStore.get(this);
    CocoStore.Session session = store.session();
    if (!session.active || session.paused) {
      CocotaxiOverlayService.clearOffer();
      return;
    }
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return;
    try {
      if (!CABIFY.contentEquals(root.getPackageName() == null ? "" : root.getPackageName())) {
        CocotaxiOverlayService.clearOffer();
        stableKey = "";
        return;
      }
      String text = TextCollector.collect(root);
      observeAssignment(text);
      if (AssignmentSignals.isAssigned(text) || OfferParser.isHistoryScreen(text)) {
        CocotaxiOverlayService.clearOffer();
        return;
      }
      if (store.activeTrip() != null) {
        CocotaxiOverlayService.clearOffer();
        // Keep observing lifecycle through OCR when Cabify exposes no accessible completion text.
        if (Build.VERSION.SDK_INT >= 30) requestScreenshot(root.getWindowId());
        return;
      }
      SettingsStore.Values v = SettingsStore.load(this);
      int signal = DemandModel.textSignal(text);
      if (signal >= 0) {
        mapSignal = signal;
        mapAt = System.currentTimeMillis();
      }
      List<Offer> cards = TextCollector.cards(root);
      if (!cards.isEmpty()) {
        rememberDetail(cards, !TextCollector.isList(root) && TextCollector.hasAccept(root));
        previous = cards;
        previousAt = SystemClock.elapsedRealtime();
        show(cards, false);
        maybeClick(root, cards, v);
        diagnostic = "Leyendo " + cards.size() + " ofertas visibles";
      } else {
        CocotaxiOverlayService.clearOffer();
        stableKey = "";

        if (Build.VERSION.SDK_INT >= 30) requestScreenshot(root.getWindowId());
        else if (!AssignmentSignals.isAssigned(text))
          diagnostic = "Texto no disponible: activa Captura de respaldo";
      }
    } finally {
      root.recycle();
    }
  }

  private DecisionEngine.Result best(List<Offer> cards) {
    CocoStore store = CocoStore.get(this);
    SettingsStore.Values v = SettingsStore.load(this);
    CocoStore.Session s = store.session();
    java.util.List<DecisionEngine.Result> results = new java.util.ArrayList<>();
    for (Offer o : cards)
      results.add(
          DecisionEngine.evaluate(o, v, s, demand(v), store.calibrationForOffer(o.kind, v), PromotionStore.get(this)));
    return OfferRanking.best(results);
  }

  private void show(List<Offer> cards, boolean fromOcr) {
    DecisionEngine.Result result = best(cards);
    if (result != null)
      CocotaxiOverlayService.update(
          result,
          cards.indexOf(result.offer) + 1,
          cards.size(),
          demand(SettingsStore.load(this)),
          fromOcr);
  }

  private void maybeClick(AccessibilityNodeInfo root, List<Offer> cards, SettingsStore.Values v) {
    if (cards.size() != 1 || TextCollector.isList(root) || !TextCollector.hasAccept(root)) {
      stableKey = "";
      return;
    }
    DecisionEngine.Result r = best(cards);
    if (!v.autoAccept || r == null || !r.accept || CocoStore.get(this).activeTrip() != null) return;
    long now = SystemClock.elapsedRealtime();
    // Wait for the same card and bounds in two observations; never tap stale OCR coordinates.
    String key = r.offer.key + "@" + r.offer.top;
    if (!stableKey.equals(key)) {
      stableKey = key;
      stableAt = now;
      return;
    }
    if (now - stableAt < 700
        || now - clickedAt < 12000
        || now - attemptedKeys.getOrDefault(r.offer.key, -300001L) < 300000) return;
    String id = CocoStore.get(this).attempt(r.offer, r, true);
    if (id == null) return;
    clickedAt = now;
    attemptedKeys.put(r.offer.key, now);
    boolean clicked = TextCollector.clickOffer(root, r.offer);
    if (!clicked) {
      CocoStore.get(this).status(id, "SIN BOTÓN ACCESIBLE");
      diagnostic = "Acepta manualmente: botón no accesible";
    } else diagnostic = "Pulsado; esperando asignación de Cabify";
    stableKey = "";
  }

  private void requestScreenshot(int window) {
    long now = SystemClock.elapsedRealtime();
    if (busy || now - ocrAt < 2500 || Build.VERSION.SDK_INT < 30) return;
    busy = true;
    ocrAt = now;
    TakeScreenshotCallback cb =
        new TakeScreenshotCallback() {
          public void onSuccess(ScreenshotResult result) {
            Bitmap copy = null, hardware = null;
            HardwareBuffer buffer = result.getHardwareBuffer();
            try {
              hardware = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
              if (hardware != null) copy = hardware.copy(Bitmap.Config.ARGB_8888, false);
            } catch (Exception e) {
              diagnostic = "Captura no disponible";
            } finally {
              if (hardware != null) hardware.recycle();
              buffer.close();
            }
            if (copy == null) {
              busy = false;
              return;
            }
            processBitmap(copy);
          }

          public void onFailure(int error) {
            busy = false;
            diagnostic = "OCR no disponible (" + error + "); usa captura de respaldo";
          }
        };
    try {
      if (Build.VERSION.SDK_INT >= 34) takeScreenshotOfWindow(window, getMainExecutor(), cb);
      else takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), cb);
    } catch (Exception e) {
      busy = false;
    }
  }

  public void processBitmap(Bitmap bitmap) {
    if (destroyed || processing || !cabifyForeground()) {
      bitmap.recycle();
      busy = false;
      return;
    }
    processing = true;
    final String captureSession = CocoStore.get(this).session().id;
    if (ocr == null) ocr = new ScreenOcrEngine();
    ocr.process(
        bitmap,
        new ScreenOcrEngine.Callback() {
          public void onText(String text) {
            try {
              CocoStore.Session s = CocoStore.get(CocotaxiAccessibilityService.this).session();
              if (!destroyed
                  && s.active
                  && !s.paused
                  && s.id.equals(captureSession)
                  && cabifyForeground()) {
                if (SettingsStore.load(CocotaxiAccessibilityService.this).mapDemand) {
                  int signal = DemandModel.textSignal(text);
                  if (signal >= 0) {
                    mapSignal = signal;
                    mapAt = System.currentTimeMillis();
                  }
                  sampleMap(bitmap, text);
                }
                observeAssignment(text);
                if (AssignmentSignals.isAssigned(text)
                    || CocoStore.get(CocotaxiAccessibilityService.this).activeTrip() != null) {
                  CocotaxiOverlayService.clearOffer();
                  return;
                }
                List<Offer> cards = OfferParser.parseVisible(text);
                if (!cards.isEmpty()) {
                  rememberDetail(cards, cards.size() == 1
                      && OfferParser.normalize(text).contains("aceptar")
                      && !OfferParser.normalize(text).contains("viajes disponibles"));
                  show(cards, true);
                  diagnostic = "OCR: " + cards.size() + " ofertas · aceptación manual";
                }
              }
            } finally {
              bitmap.recycle();
              busy = false;
              processing = false;
            }
          }

          public void onError(Exception e) {
            bitmap.recycle();
            busy = false;
            processing = false;
            diagnostic = "OCR: no se pudo leer";
          }
        });
  }

  private void sampleMap(Bitmap b, String text) {
    // Experimental visual signal only increases selectivity; never modifies predicted fare.
    if (!DemandModel.isMapScreen(text)) return;
    int red = 0, yellow = 0, total = 0;
    float[] hsv = new float[3];
    for (int y = b.getHeight() / 5; y < b.getHeight() * 3 / 5; y += 12)
      for (int x = b.getWidth() / 6; x < b.getWidth() * 5 / 6; x += 12) {
        android.graphics.Color.colorToHSV(b.getPixel(x, y), hsv);
        total++;
        if (hsv[1] > .55 && hsv[2] > .55) {
          if (hsv[0] < 20 || hsv[0] > 345) red++;
          if (hsv[0] > 35 && hsv[0] < 65) yellow++;
        }
      }
    if (total > 0 && (red / (double) total > .08 || yellow / (double) total > .15)) {
      int signal = red / (double) total > .08 ? 3 : 2;
      mapSignal = Math.max(signal, DemandModel.textSignal(text));
      mapAt = System.currentTimeMillis();
    }
  }

  @Override
  public void onInterrupt() {
    CocotaxiOverlayService.clearOffer();
  }

  @Override
  public void onDestroy() {
    destroyed = true;
    handler.removeCallbacksAndMessages(null);
    instance = null;
    if (ocr != null) ocr.close();
    CocotaxiOverlayService.clearOffer();
    super.onDestroy();
  }
}
