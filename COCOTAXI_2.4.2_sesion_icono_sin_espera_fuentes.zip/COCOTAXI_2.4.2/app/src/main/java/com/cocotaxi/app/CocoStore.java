package com.cocotaxi.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.os.SystemClock;
import android.provider.Settings;
import java.time.*;
import java.util.*;

/** Persistent sessions and trip ledger. Attempts, assignment and payment are separate facts. */
public final class CocoStore extends SQLiteOpenHelper {
  public static final ZoneId ZONE = ZoneId.of("America/Montevideo");
  private static CocoStore instance;
  private final Context context;

  private CocoStore(Context c) {
    super(c, "cocotaxi_v3.db", null, 2);
    context = c.getApplicationContext();
  }

  public static synchronized CocoStore get(Context c) {
    if (instance == null) instance = new CocoStore(c);
    return instance;
  }

  public static synchronized void closeForTests() {
    if (instance != null) instance.close();
    instance = null;
  }

  @Override
  public void onCreate(SQLiteDatabase d) {
    d.execSQL(
        "CREATE TABLE sessions(id TEXT PRIMARY KEY,start INTEGER,end INTEGER,active INTEGER,paused"
            + " INTEGER,elapsed INTEGER,wall INTEGER,boot INTEGER,ms INTEGER DEFAULT 0)");
    d.execSQL(
        "CREATE TABLE trips(id TEXT PRIMARY KEY,session TEXT,at INTEGER,status TEXT,offered"
            + " REAL,kind TEXT,estimate INTEGER,actual INTEGER,cost INTEGER,ordinary REAL,pair"
            + " INTEGER DEFAULT 0,minutes REAL,accepted INTEGER,key TEXT,label TEXT,deleted INTEGER"
            + " DEFAULT 0,trip INTEGER DEFAULT 1)");
    d.execSQL("CREATE INDEX trips_session ON trips(session,at)");
    d.execSQL("CREATE TABLE intervals(start INTEGER,end INTEGER,minutes REAL,session TEXT)");
    d.execSQL(
        "CREATE TABLE billing(day TEXT PRIMARY KEY,total REAL,tips REAL,bonus REAL,tolls"
            + " REAL,history REAL,eligible INTEGER DEFAULT 0)");
  }

  @Override
  public void onUpgrade(SQLiteDatabase d, int old, int next) {
    if (old < 2) d.execSQL("ALTER TABLE billing ADD COLUMN eligible INTEGER DEFAULT 0");
  }

  private int boot() {
    return Settings.Global.getInt(context.getContentResolver(), Settings.Global.BOOT_COUNT, 0);
  }

  public static long dayStart(long at) {
    return Instant.ofEpochMilli(at)
        .atZone(ZONE)
        .toLocalDate()
        .atStartOfDay(ZONE)
        .toInstant()
        .toEpochMilli();
  }

  public static long weekStart(long at) {
    LocalDate d = Instant.ofEpochMilli(at).atZone(ZONE).toLocalDate();
    return d.minusDays(d.getDayOfWeek().getValue() - 1)
        .atStartOfDay(ZONE)
        .toInstant()
        .toEpochMilli();
  }

  public synchronized Session session() {
    SQLiteDatabase d = getWritableDatabase();
    Session s = new Session();
    try (Cursor q =
        d.rawQuery(
            "SELECT id,start,end,active,paused,elapsed,wall,boot,ms FROM sessions ORDER BY start"
                + " DESC, rowid DESC LIMIT 1",
            null)) {
      if (!q.moveToFirst()) return s;
      s.id = q.getString(0);
      s.start = q.getLong(1);
      s.end = q.getLong(2);
      s.active = q.getInt(3) == 1;
      s.paused = q.getInt(4) == 1;
      long elapsed = q.getLong(5),
          wall = q.getLong(6),
          ms = q.getLong(8),
          now = System.currentTimeMillis(),
          mono = SystemClock.elapsedRealtime();
      if (s.active) {
        if (q.getInt(7) != boot() || mono < elapsed) {
          ContentValues v = new ContentValues();
          v.put("paused", 1);
          v.put("boot", boot());
          v.put("elapsed", mono);
          d.update("sessions", v, "id=?", new String[] {s.id});
          invalidatePending(s.id);
          s.paused = true;
        } else if (!s.paused) {
          long delta = mono - elapsed;
          s.minutes = (ms + delta) / 60000.0;
          if (delta >= 1000) {
            d.beginTransaction();
            try {
              long from = Math.abs(now - wall - delta) > 60000 ? now - delta : wall;
              ContentValues interval = new ContentValues();
              interval.put("start", from);
              interval.put("end", now);
              interval.put("minutes", delta / 60000.0);
              interval.put("session", s.id);
              d.insertOrThrow("intervals", null, interval);
              ContentValues v = new ContentValues();
              v.put("ms", ms + delta);
              v.put("elapsed", mono);
              v.put("wall", now);
              d.update("sessions", v, "id=?", new String[] {s.id});
              d.setTransactionSuccessful();
            } finally {
              d.endTransaction();
            }
          }
        }
      }
      if (!s.active || s.paused) s.minutes = ms / 60000.0;
    }
    Totals t = totals("session=?", new String[] {s.id});
    s.money = t.money;
    s.estimated = t.estimated;
    s.trips = t.trips;
    s.service = t.service;
    s.pending = t.pending;
    return s;
  }

  public synchronized void start() {
    if (session().active) return;
    ContentValues v = new ContentValues();
    v.put("id", UUID.randomUUID().toString());
    v.put("start", System.currentTimeMillis());
    v.put("end", 0);
    v.put("active", 1);
    v.put("paused", 0);
    v.put("elapsed", SystemClock.elapsedRealtime());
    v.put("wall", System.currentTimeMillis());
    v.put("boot", boot());
    getWritableDatabase().insertOrThrow("sessions", null, v);
  }

  public synchronized void pause() {
    Session s = session();
    if (!s.active) return;
    checkpointRemainder(s);
    ContentValues v = new ContentValues();
    v.put("paused", s.paused ? 0 : 1);
    v.put("elapsed", SystemClock.elapsedRealtime());
    v.put("wall", System.currentTimeMillis());
    v.put("boot", boot());
    getWritableDatabase().update("sessions", v, "id=?", new String[] {s.id});
  }

  private void checkpointRemainder(Session s) {
    if (!s.active || s.paused) return;
    SQLiteDatabase d = getWritableDatabase();
    try (Cursor q =
        d.rawQuery("SELECT elapsed,wall,ms FROM sessions WHERE id=?", new String[] {s.id})) {
      if (q.moveToFirst()) {
        long now = System.currentTimeMillis(),
            mono = SystemClock.elapsedRealtime(),
            delta = Math.max(0, mono - q.getLong(0));
        if (delta == 0) return;
        d.beginTransaction();
        try {
          ContentValues i = new ContentValues();
          i.put("start", now - delta);
          i.put("end", now);
          i.put("minutes", delta / 60000.0);
          i.put("session", s.id);
          d.insertOrThrow("intervals", null, i);
          ContentValues v = new ContentValues();
          v.put("ms", q.getLong(2) + delta);
          v.put("elapsed", mono);
          v.put("wall", now);
          d.update("sessions", v, "id=?", new String[] {s.id});
          d.setTransactionSuccessful();
        } finally {
          d.endTransaction();
        }
      }
    }
  }

  public synchronized void stop() {
    Session s = session();
    if (!s.active) return;
    checkpointRemainder(s);
    ContentValues v = new ContentValues();
    v.put("active", 0);
    v.put("paused", 0);
    v.put("end", System.currentTimeMillis());
    getWritableDatabase().update("sessions", v, "id=?", new String[] {s.id});
    invalidatePending(s.id);
  }

  private void invalidatePending(String sessionId) {
    ContentValues v = new ContentValues();
    v.put("status", "SIN CONFIRMAR");
    getWritableDatabase()
        .update(
            "trips", v, "session=? AND status IN ('INTENTO','ASIGNADO')", new String[] {sessionId});
  }

  public synchronized String attempt(Offer o, DecisionEngine.Result result, boolean automatic) {
    Session s = session();
    if (!s.active || s.paused || activeTrip() != null) return null;
    String id = UUID.randomUUID().toString();
    ContentValues v = new ContentValues();
    v.put("id", id);
    v.put("session", s.id);
    v.put("at", System.currentTimeMillis());
    v.put("status", "INTENTO");
    v.put("offered", o.fare);
    v.put("kind", o.kind);
    v.put("estimate", Money.cents(result.payout));
    v.put("cost", Money.cents(result.cost));
    v.put("minutes", 0);
    v.put("accepted", 0);
    v.put("key", o.key);
    v.put("label", automatic ? "Aceptación automática" : "Selección manual detectada");
    getWritableDatabase().insertOrThrow("trips", null, v);
    return id;
  }

  public synchronized void observe(String raw) {
    Session s = session();
    if (!s.active || s.paused) return;
    Trip t = activeTrip();
    if (t == null) return;
    String text = OfferParser.normalize(raw);
    if (OfferParser.isHistoryScreen(text)) return;
    if (text.contains("viaje cancelado")
        || text.contains("otro conductor")
        || text.contains("ya no esta disponible")
        || text.contains("no se pudo aceptar")
        || text.contains("error al aceptar")) {
      status(t.id, "NO ASIGNADO");
      return;
    }
    if (t.status.equals("INTENTO")) {
      if (System.currentTimeMillis() - t.at > 45000) {
        status(t.id, "SIN CONFIRMAR");
        return;
      }
      boolean assigned =
          AssignmentSignals.isAssigned(text)
              || text.contains("ir a recoger")
              || text.contains("he llegado")
              || text.contains("iniciar viaje")
              || text.contains("recoger al pasajero");
      if (assigned && !text.contains("aceptar")) {
        ContentValues v = new ContentValues();
        v.put("status", "ASIGNADO");
        v.put("accepted", SystemClock.elapsedRealtime());
        getWritableDatabase().update("trips", v, "id=?", new String[] {t.id});
      }
    } else if (t.status.equals("ASIGNADO")
        && (text.contains("viaje finalizado")
            || text.contains("viaje terminado")
            || text.contains("califica el viaje"))) complete(t.id);
  }

  public synchronized boolean complete(String id) {
    Trip t = find(id);
    if (t == null || !t.status.equals("ASIGNADO")) return false;
    ContentValues v = new ContentValues();
    v.put("status", "FINALIZADO");
    v.put("at", System.currentTimeMillis());
    v.put("minutes", Math.max(0, (SystemClock.elapsedRealtime() - t.accepted) / 60000.0));
    getWritableDatabase().update("trips", v, "id=? AND status='ASIGNADO'", new String[] {id});
    return true;
  }

  public void status(String id, String status) {
    ContentValues v = new ContentValues();
    v.put("status", status);
    getWritableDatabase().update("trips", v, "id=?", new String[] {id});
  }

  public String manual(double payout, double minutes, String label) {
    return manual(payout, minutes, label, true);
  }

  public String manual(double payout, double minutes, String label, boolean trip) {
    Session s = session();
    if (!s.active
        || s.paused
        || !Double.isFinite(payout)
        || payout < 0
        || !Double.isFinite(minutes)
        || minutes < 0)
      throw new IllegalArgumentException("Inicia o reanuda la sesión; revisa los importes");
    String id = UUID.randomUUID().toString();
    ContentValues v = new ContentValues();
    v.put("id", id);
    v.put("session", s.id);
    v.put("at", System.currentTimeMillis());
    v.put("status", "FINALIZADO");
    v.put("offered", 0);
    v.put("kind", "UNKNOWN");
    v.put("estimate", 0);
    v.put("actual", Money.cents(payout));
    v.put("cost", 0);
    v.put("minutes", minutes);
    v.put("label", label);
    v.put("trip", trip ? 1 : 0);
    getWritableDatabase().insertOrThrow("trips", null, v);
    return id;
  }

  public void correct(String id, double actual, double cost, boolean pair, double ordinary) {
    if (!Double.isFinite(actual)
        || actual < 0
        || !Double.isFinite(cost)
        || cost < 0
        || pair && (!Double.isFinite(ordinary) || ordinary <= 0))
      throw new IllegalArgumentException("Importes no válidos");
    Trip t = find(id);
    if (t == null) return;
    ContentValues v = new ContentValues();
    v.put("actual", Money.cents(actual));
    v.put("cost", Money.cents(cost));
    v.put("ordinary", ordinary);
    v.put("pair", pair && t.offered > 0 ? 1 : 0);
    v.put("status", "FINALIZADO");
    getWritableDatabase().update("trips", v, "id=?", new String[] {id});
  }

  public void delete(String id) {
    ContentValues v = new ContentValues();
    v.put("deleted", 1);
    getWritableDatabase().update("trips", v, "id=?", new String[] {id});
  }

  public void restore(String id) {
    ContentValues v = new ContentValues();
    v.put("deleted", 0);
    getWritableDatabase().update("trips", v, "id=?", new String[] {id});
  }

  public Trip activeTrip() {
    ContentValues expired = new ContentValues();
    expired.put("status", "SIN CONFIRMAR");
    getWritableDatabase()
        .update(
            "trips",
            expired,
            "status='INTENTO' AND at<?",
            new String[] {"" + (System.currentTimeMillis() - 45000)});
    Session current = session();
    List<Trip> ts =
        query(
            "session=? AND deleted=0 AND status IN ('INTENTO','ASIGNADO')",
            new String[] {current.id});
    return ts.isEmpty() ? null : ts.get(0);
  }

  public Trip find(String id) {
    List<Trip> ts = query("id=?", new String[] {id});
    return ts.isEmpty() ? null : ts.get(0);
  }

  public List<Trip> trips(String session) {
    return query("session=?", new String[] {session});
  }

  private List<Trip> query(String where, String[] args) {
    List<Trip> out = new ArrayList<>();
    try (Cursor q =
        getReadableDatabase()
            .rawQuery(
                "SELECT"
                    + " id,session,at,status,offered,kind,estimate,actual,cost,ordinary,pair,minutes,accepted,key,label,deleted"
                    + " FROM trips WHERE "
                    + where
                    + " ORDER BY at DESC",
                args)) {
      while (q.moveToNext()) {
        Trip t = new Trip();
        t.id = q.getString(0);
        t.session = q.getString(1);
        t.at = q.getLong(2);
        t.status = q.getString(3);
        t.offered = q.getDouble(4);
        t.kind = q.getString(5);
        t.estimate = q.getLong(6) / 100.0;
        t.confirmed = !q.isNull(7);
        t.actual = q.getLong(7) / 100.0;
        t.cost = q.getLong(8) / 100.0;
        t.ordinary = q.getDouble(9);
        t.pair = q.getInt(10) == 1;
        t.minutes = q.getDouble(11);
        t.accepted = q.getLong(12);
        t.key = q.getString(13);
        t.label = q.getString(14);
        t.deleted = q.getInt(15) == 1;
        out.add(t);
      }
    }
    return out;
  }

  public List<Session> sessions() {
    List<Session> out = new ArrayList<>();
    try (Cursor q =
        getReadableDatabase()
            .rawQuery(
                "SELECT id,start,end,ms FROM sessions ORDER BY start DESC, rowid DESC", null)) {
      while (q.moveToNext()) {
        Session s = new Session();
        s.id = q.getString(0);
        s.start = q.getLong(1);
        s.end = q.getLong(2);
        s.minutes = q.getLong(3) / 60000.0;
        Totals t = totals("session=?", new String[] {s.id});
        s.money = t.money;
        s.trips = t.trips;
        out.add(s);
      }
    }
    return out;
  }

  public Totals period(long from, long to) {
    return totals("at>=? AND at<?", new String[] {"" + from, "" + to});
  }

  private Totals totals(String where, String[] args) {
    Totals t = new Totals();
    try (Cursor q =
        getReadableDatabase()
            .rawQuery(
                "SELECT COALESCE(SUM(COALESCE(actual,estimate)-cost),0),COALESCE(SUM(CASE WHEN"
                    + " actual IS NULL THEN estimate-cost ELSE 0"
                    + " END),0),COALESCE(SUM(trip),0),COALESCE(SUM(minutes),0),COALESCE(SUM(CASE"
                    + " WHEN actual IS NULL THEN 1 ELSE 0 END),0) FROM trips WHERE deleted=0 AND"
                    + " status='FINALIZADO' AND "
                    + where,
                args)) {
      if (q.moveToFirst()) {
        t.money = q.getLong(0) / 100.0;
        t.estimated = q.getLong(1) / 100.0;
        t.trips = q.getInt(2);
        t.service = q.getDouble(3);
        t.pending = q.getInt(4);
      }
    }
    return t;
  }

  public double periodMinutes(long from, long to) {
    session();
    double sum = 0;
    try (Cursor q =
        getReadableDatabase()
            .rawQuery(
                "SELECT start,end,minutes FROM intervals WHERE start<? AND end>?",
                new String[] {"" + to, "" + from})) {
      while (q.moveToNext()) {
        long a = q.getLong(0), b = q.getLong(1);
        if (b > a) sum += q.getDouble(2) * (Math.min(b, to) - Math.max(a, from)) / (b - a);
      }
    }
    return sum;
  }

  public Calibration calibration(String kind) {
    Calibration c = new Calibration();
    try (Cursor q =
        getReadableDatabase()
            .rawQuery(
                "SELECT COUNT(*),SUM(offered),SUM(ordinary) FROM trips WHERE deleted=0 AND pair=1"
                    + " AND status='FINALIZADO' AND offered>0 AND ordinary>0 AND kind=? AND at>=?",
                new String[] {kind, "" + (System.currentTimeMillis() - 28L * 86400000)})) {
      if (q.moveToFirst()) {
        c.count = q.getInt(0);
        c.offered = q.getDouble(1);
        c.paid = q.getDouble(2);
        c.factor = c.offered > 0 ? c.paid / c.offered : 1;
      }
    }
    return c;
  }

  public void saveBilling(
      String day, double total, double tips, double bonus, double tolls, double history) {
    saveBilling(day, total, tips, bonus, tolls, history, false);
  }

  public void saveBilling(
      String day,
      double total,
      double tips,
      double bonus,
      double tolls,
      double history,
      boolean eligible) {
    LocalDate.parse(day);
    for (double x : new double[] {total, tips, bonus, tolls, history})
      if (!Double.isFinite(x) || x < 0) throw new IllegalArgumentException("Importes no válidos");
    if (tips + bonus + tolls > total)
      throw new IllegalArgumentException("Exclusiones mayores que el total");
    if (eligible) {
      if (!LocalDate.parse(day).isBefore(LocalDate.now(ZONE)))
        throw new IllegalArgumentException("Espera al cierre del día; hoy aún es parcial");
      double ratio = history > 0 ? (total - tips - bonus - tolls) / history : 0;
      if (!Double.isFinite(ratio) || ratio < .1 || ratio > 2)
        throw new IllegalArgumentException("Revisa la suma completa del historial y el total");
    }
    ContentValues v = new ContentValues();
    v.put("day", day);
    v.put("total", total);
    v.put("tips", tips);
    v.put("bonus", bonus);
    v.put("tolls", tolls);
    v.put("history", history);
    v.put("eligible", eligible ? 1 : 0);
    getWritableDatabase().insertWithOnConflict("billing", null, v, SQLiteDatabase.CONFLICT_REPLACE);
  }

  public Calibration calibrationForOffer(String kind, SettingsStore.Values values) {
    return values.payoutMode == 3 ? dailyCalibration() : calibration(kind);
  }

  public Calibration dailyCalibration() {
    Calibration c = new Calibration();
    c.daily = true;
    LocalDate today = LocalDate.now(ZONE);
    try (Cursor q =
        getReadableDatabase()
            .rawQuery(
                "SELECT COUNT(*),SUM(history),SUM(total-tips-bonus-tolls) FROM billing"
                    + " WHERE eligible=1 AND history>0 AND day>=? AND day<?",
                new String[] {today.minusDays(28).toString(), today.toString()})) {
      if (q.moveToFirst()) {
        c.count = q.getInt(0);
        c.offered = q.getDouble(1);
        c.paid = q.getDouble(2);
      }
    }
    // Initial factor after reconciling midnight carryovers and excluding tips on both sides.
    // History reconciliation is not proof of every original offer-to-payment pair.
    c.provisional = c.count == 0;
    c.factor = c.offered > 0 ? c.paid / c.offered : 1.0;
    return c;
  }

  public static class Totals {
    public double money, estimated, service;
    public int trips, pending;
  }

  public static class Session extends Totals {
    public String id = "";
    public long start, end;
    public boolean active, paused;
    public double minutes;

    public double hourly() {
      return minutes > 0 ? money * 60 / minutes : 0;
    }
  }

  public static class Trip {
    public String id, session, status, kind, key, label;
    public long at, accepted;
    public boolean confirmed, pair, deleted;
    public double offered, estimate, actual, cost, ordinary, minutes;

    public double net() {
      return (confirmed ? actual : estimate) - cost;
    }
  }

  public static class Calibration {
    public int count;
    public double offered, paid, factor = 1;
    public boolean daily, provisional;

    public boolean usable() {
      return (daily ? count >= 1 || provisional : count >= 5)
          && Double.isFinite(factor)
          && factor >= .1
          && factor <= 2;
    }
  }
}
