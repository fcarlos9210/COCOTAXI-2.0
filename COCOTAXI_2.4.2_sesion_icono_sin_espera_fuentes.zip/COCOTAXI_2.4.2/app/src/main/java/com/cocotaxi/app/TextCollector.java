package com.cocotaxi.app;

import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;

public final class TextCollector {
  public static String collect(AccessibilityNodeInfo root) {
    StringBuilder b = new StringBuilder();
    walk(root, b, 0, new int[] {0});
    return b.toString();
  }

  private static void walk(AccessibilityNodeInfo n, StringBuilder b, int depth, int[] count) {
    if (n == null || depth > 30 || count[0]++ > 600 || !n.isVisibleToUser()) return;
    CharSequence t = n.getText(), d = n.getContentDescription();
    if (t != null && !t.toString().trim().isEmpty()) b.append(t).append('\n');
    else if (d != null && !d.toString().trim().isEmpty()) b.append(d).append('\n');
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        walk(c, b, depth + 1, count);
        c.recycle();
      }
    }
  }

  public static List<Offer> cards(AccessibilityNodeInfo root) {
    List<Offer> out = new ArrayList<>();
    walkCards(root, out, 0, new int[] {0});
    out.sort(Comparator.comparingInt(o -> o.top));
    return out;
  }

  private static void walkCards(AccessibilityNodeInfo n, List<Offer> out, int depth, int[] count) {
    if (n == null || !n.isVisibleToUser() || depth > 25 || count[0]++ > 500) return;
    Offer o = OfferParser.parse(collect(n), "com.cabify.driver");
    if (o.hasEnoughForDecision()) {
      android.graphics.Rect b = new android.graphics.Rect();
      n.getBoundsInScreen(b);
      o.top = b.top;
      o.bottom = b.bottom;
      boolean duplicate = false;
      for (Offer a : out) if (a.key.equals(o.key) && a.top == o.top) duplicate = true;
      if (!duplicate) out.add(o);
      return;
    }
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        walkCards(c, out, depth + 1, count);
        c.recycle();
      }
    }
  }

  public static boolean isList(AccessibilityNodeInfo root) {
    String text = OfferParser.normalize(collect(root));
    if (text.contains("viajes disponibles") || text.contains("lista de viajes")) return true;
    return listNode(root, 0);
  }

  private static boolean listNode(AccessibilityNodeInfo n, int depth) {
    if (n == null || depth > 25) return false;
    CharSequence cl = n.getClassName();
    String name = cl == null ? "" : cl.toString();
    if (n.isVisibleToUser()
        && (name.contains("RecyclerView")
            || name.contains("ListView")
            || n.getCollectionInfo() != null && n.getCollectionInfo().getRowCount() > 1))
      return true;
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        boolean yes = listNode(c, depth + 1);
        c.recycle();
        if (yes) return true;
      }
    }
    return false;
  }

  public static boolean hasAccept(AccessibilityNodeInfo root) {
    return hasButton(root, 0);
  }

  private static boolean hasButton(AccessibilityNodeInfo n, int depth) {
    if (n == null || depth > 25 || !n.isVisibleToUser()) return false;
    String t =
        OfferParser.normalize(
                String.valueOf(n.getText() == null ? n.getContentDescription() : n.getText()))
            .trim();
    if ((t.equals("aceptar") || t.equals("aceptar viaje")) && n.isEnabled() && n.isClickable())
      return true;
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        boolean yes = hasButton(c, depth + 1);
        c.recycle();
        if (yes) return true;
      }
    }
    return false;
  }

  public static boolean clickOffer(AccessibilityNodeInfo root, Offer wanted) {
    return clickCard(root, wanted, 0);
  }

  private static boolean clickCard(AccessibilityNodeInfo n, Offer wanted, int depth) {
    if (n == null || depth > 25 || !n.isVisibleToUser()) return false;
    Offer o = OfferParser.parse(collect(n), "com.cabify.driver");
    android.graphics.Rect rect = new android.graphics.Rect();
    n.getBoundsInScreen(rect);
    if (o.hasEnoughForDecision() && o.key.equals(wanted.key) && rect.top == wanted.top)
      return acceptButton(n, 0);
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        boolean ok = clickCard(c, wanted, depth + 1);
        c.recycle();
        if (ok) return true;
      }
    }
    return false;
  }

  private static boolean acceptButton(AccessibilityNodeInfo n, int depth) {
    if (depth > 20) return false;
    String t =
        OfferParser.normalize(
                String.valueOf(n.getText() == null ? n.getContentDescription() : n.getText()))
            .trim();
    if ((t.equals("aceptar") || t.equals("aceptar viaje"))
        && n.isVisibleToUser()
        && n.isEnabled()
        && n.isClickable()) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = n.getChild(i);
      if (c != null) {
        boolean ok = acceptButton(c, depth + 1);
        c.recycle();
        if (ok) return true;
      }
    }
    return false;
  }
}
