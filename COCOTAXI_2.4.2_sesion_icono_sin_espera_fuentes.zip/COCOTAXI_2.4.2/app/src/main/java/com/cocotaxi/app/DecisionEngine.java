package com.cocotaxi.app;

/** Monetary prediction and acceptance are kept independent of screen/click state. */
public final class DecisionEngine {
  public static Result evaluate(
      Offer o,
      SettingsStore.Values v,
      CocoStore.Session s,
      int demand,
      CocoStore.Calibration learned) {
    return evaluate(o,v,s,demand,learned,null);
  }
  public static Result evaluate(Offer o, SettingsStore.Values v, CocoStore.Session s,
      int demand, CocoStore.Calibration learned, PromotionStore.Snapshot promo) {
    Result r = new Result();
    r.offer = o;
    if (o == null || !o.hasEnoughForDecision()) {
      r.reason = "Datos incompletos o ambiguos";
      return r;
    }
    if (!s.active || s.paused) {
      r.reason = s.paused ? "Sesión en pausa" : "Conecta COCOTAXI";
      return r;
    }
    if (v.costKm > 0 || v.manualMinKm > 0) {
      if (o.pickupKm < 0 || o.tripKm < 0) {
        r.reason = "Faltan kilómetros";
        return r;
      }
    }
    r.factor = 1;
    if (v.payoutMode == 1) {
      r.factor = v.factor;
      r.calibrated = Double.isFinite(v.factor) && v.factor >= .1 && v.factor <= 2;
    }
    if (v.payoutMode == 2 && learned != null && learned.usable()) {
      r.factor = learned.factor;
      r.calibrated = true;
    }
    if (v.payoutMode == 3 && learned != null && learned.daily && learned.usable()) {
      r.factor = learned.factor;
      r.calibrated = true;
      r.provisional = learned.provisional;
    }
    if (!Double.isFinite(r.factor) || r.factor <= 0) {
      r.reason = "Factor inválido";
      return r;
    }
    r.payout = Money.round(o.fare * r.factor);
    r.cost = Money.round(v.costKm * (o.totalKm() + v.emptyKm));
    r.net = r.payout - r.cost;
    r.minutes = o.totalMinutes() + v.waitPassenger;
    if (!Double.isFinite(r.minutes) || r.minutes <= 0 || r.cost < 0) {
      r.reason = "Revisa tiempos y gastos";
      return r;
    }
    r.hourly = r.net * 60 / r.minutes;
    r.projected = (s.money + r.net) * 60 / (s.minutes + r.minutes);
    double goal = SettingsStore.resolveRealGoalHour(v),
        operative = SettingsStore.resolveObjectiveHour(v);
    double multiplier = demand == 3 ? 1.15 : demand == 1 ? .9 : demand == 0 ? .75 : 1;
    double deficit = Math.max(0, goal * s.minutes / 60 - s.money);
    // Recover gradually; one offer need not repay all past idle time.
    double needed = v.dailyGoal > 0 && v.targetHoursDay*60 > s.minutes
        ? PromotionMath.requiredHourly(v.dailyGoal,v.targetHoursDay,s.minutes,s.money)
        : goal + deficit*60/120;
    double recovery = v.recovery && s.minutes >= 60
        ? Math.min(goal*.20,Math.max(0,needed-goal)) : 0;
    r.threshold = operative * multiplier + (demand >= 2 ? recovery : 0);
    r.required = (r.threshold * r.minutes / 60 + r.cost) / r.factor;
    r.recoverAll = Math.max(0, (goal * (s.minutes + r.minutes) / 60 - s.money + r.cost) / r.factor);
    if (v.maxPickupMin > 0 && o.pickupMin > v.maxPickupMin
        || v.maxPickupKm > 0 && o.pickupKm > v.maxPickupKm) {
      r.reason = "Recogida fuera de tu límite";
      return r;
    }
    if (v.manualMinKm > 0 && r.net / Math.max(.001, o.totalKm() + v.emptyKm) < v.manualMinKm) {
      r.reason = "Por debajo de tu mínimo/km";
      return r;
    }
    if (r.net <= 0) {
      r.reason = "No cubre gastos";
      return r;
    }
    if (!r.calibrated) {
      r.reason = "Confirma el factor de pago en Ajustes";
      return r;
    }
    r.neededHourly = PromotionMath.requiredHourly(v.dailyGoal, v.targetHoursDay, s.minutes, s.money);
    r.score = r.hourly;
    r.accept = r.hourly + 1e-7 >= r.threshold;
    if (promo != null && promo.active()) {
      // Do not plan beyond the configured shift, even if the promotion ends later.
      double left = Math.min((promo.end-promo.now)/60000.0, v.targetHoursDay*60-s.minutes);
      double cycle = Math.max(promo.cycle, v.waitPassenger + 8);
      PromotionMath.Plan plan = PromotionMath.plan(promo.target-promo.completed,
          promo.bonus, left, r.minutes, cycle, r.net, Math.max(goal,r.threshold));
      r.promoFeasible = plan.feasible;
      if (plan.feasible) {
        r.promoCredit = plan.credit;
        r.score = plan.hourly;
        r.accept = true;
      }
    }
    r.reason =
        r.accept
            ? (r.projected >= goal
                ? "Cumple el objetivo de sesión"
                : "Cumple filtro; sesión aún bajo meta")
            : "No alcanza el filtro de esta demanda";
    if (r.promoFeasible) r.reason = "Promo viable · " + Money.format(r.score)
        + "/h con premio condicionado; sin abonar";
    else if (promo != null && promo.active()) r.reason += " · sin apoyo de promo para esta oferta";
    if (r.provisional) r.reason += " · estimación inicial Ayeryhoy";
    return r;
  }

  public static final class Result {
    public Offer offer;
    public boolean accept, calibrated, provisional, promoFeasible;
    public double score, promoCredit, neededHourly;
    public String reason = "Sin oferta";
    public double factor = 1,
        payout,
        cost,
        net,
        minutes,
        hourly,
        projected,
        threshold,
        required,
        recoverAll;

    public String label() {
      return accept ? "ACEPTAR" : "RECHAZAR";
    }
  }
}
