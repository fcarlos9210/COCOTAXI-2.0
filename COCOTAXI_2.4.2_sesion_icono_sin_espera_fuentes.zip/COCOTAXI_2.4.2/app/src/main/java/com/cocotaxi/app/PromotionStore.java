package com.cocotaxi.app;

import android.content.*;
import android.database.Cursor;
import java.util.*;

/** One promotion per session. Completed trips, corrections and deletions are read live. */
public final class PromotionStore {
  private static SharedPreferences prefs(Context c) {
    return c.getSharedPreferences("coco_verified_promotion", 0);
  }
  public static void set(Context c, int target, double bonus, long end) {
    set(c, target, bonus, System.currentTimeMillis(), end, 0);
  }
  public static void set(Context c, int target, double bonus, long start, long end, int completed) {
    CocoStore.Session session = CocoStore.get(c).session();
    if (!session.active) throw new IllegalArgumentException("Inicia una sesión primero");
    if (target < 1 || target > 500 || !Double.isFinite(bonus) || bonus <= 0
        || start >= end || end <= System.currentTimeMillis() || end - start > 86400000L
        || completed < 0 || completed > target)
      throw new IllegalArgumentException("Revisa premio, viajes y horario (máximo 24 h)");
    int automatic = count(c, session.id, start, end);
    prefs(c).edit().putString("session", session.id).putInt("target", target)
        .putLong("bonus", Money.cents(bonus)).putLong("start", start).putLong("end", end)
        .putInt("adjustment", completed - automatic).apply();
  }
  private static int count(Context c, String session, long start, long end) {
    try (Cursor q = CocoStore.get(c).getReadableDatabase().rawQuery(
        "SELECT COUNT(*) FROM trips WHERE session=? AND deleted=0 AND trip=1 "
        + "AND status='FINALIZADO' AND at>=? AND at<?",
        new String[]{session, ""+start, ""+end})) {
      return q.moveToFirst() ? q.getInt(0) : 0;
    }
  }
  public static Snapshot get(Context c) {
    SharedPreferences p = prefs(c);
    Snapshot s = new Snapshot();
    CocoStore.Session session = CocoStore.get(c).session();
    if (!session.active || !session.id.equals(p.getString("session", "")) || session.id.isEmpty()) return s;
    s.target = p.getInt("target", 0);
    s.bonus = p.getLong("bonus", 0) / 100.0;
    s.start = p.getLong("start", 0);
    s.end = p.getLong("end", 0);
    s.completed = Math.max(0, count(c, session.id, s.start, s.end) + p.getInt("adjustment", 0));
    s.now = System.currentTimeMillis();
    // Completion-to-completion intervals include pickup, service and idle waiting.
    List<Double> cycles = new ArrayList<>();
    try (Cursor q = CocoStore.get(c).getReadableDatabase().rawQuery(
        "SELECT at FROM trips WHERE session=? AND deleted=0 AND trip=1 "
        + "AND status='FINALIZADO' ORDER BY at DESC LIMIT 9", new String[]{session.id})) {
      long previous = 0;
      while(q.moveToNext()) {
        long at=q.getLong(0);
        if(previous>at) cycles.add((previous-at)/60000.0);
        previous=at;
      }
    }
    s.samples=cycles.size();
    if(s.samples>=3) {
      Collections.sort(cycles);
      s.cycle=Math.max(1,cycles.get((int)Math.ceil(cycles.size()*.8)-1));
    }
    return s;
  }
  public static void clear(Context c) { prefs(c).edit().clear().apply(); }
  public static class Snapshot {
    public int target, completed, samples;
    public double bonus, cycle = 15;
    public long start, end, now;
    public boolean active() { return target>completed && now>=start && now<end; }
    public String description() {
      if(target==0) return "Sin promoción · configurar";
      if(completed>=target) return "Meta de promo completada · confirma el abono";
      if(now<start) return "Programada · " + completed + "/" + target + " viajes";
      if(now>=end) return "Promo terminada · " + completed + "/" + target;
      double left=(end-now)/60000.0;
      boolean reachable=(target-completed)*cycle+Math.max(5,left*.1)<=left;
      return completed + "/" + target + " viajes · " + (long)left + " min"
          + (reachable ? " · en seguimiento" : " · necesita viajes más rápidos");
    }
  }
}
