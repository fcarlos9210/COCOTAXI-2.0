package com.cocotaxi.app;

import java.time.*;
import java.util.regex.*;

public final class DemandModel {
  public static int level(SettingsStore.Values v, long now, int signal, long signalAt) {
    if (v.demandMode != 0) return v.demandMode == 1 ? 3 : v.demandMode == 3 ? 1 : 2;
    ZonedDateTime z = Instant.ofEpochMilli(now).atZone(CocoStore.ZONE);
    int hour = z.getHour(), day = z.getDayOfWeek().getValue();
    int base =
        inRange(hour, v.deadStart, v.deadEnd)
            ? 0
            : (day == 5 || day == 6) && inRange(hour, v.peakStart, v.peakEnd)
                ? 3
                : day == 4 || day == 7 ? 2 : 1;
    return v.mapDemand && now - signalAt < 30000 && now >= signalAt ? Math.max(base, signal) : base;
  }

  public static boolean inRange(int hour, int start, int end) {
    return start == end
        ? false
        : start < end ? hour >= start && hour < end : hour >= start || hour < end;
  }

  public static String name(int level) {
    return new String[] {"MUERTA", "BAJA", "MEDIA", "ALTA"}[Math.max(0, Math.min(3, level))];
  }

  public static int textSignal(String raw) {
    String t = OfferParser.normalize(raw);
    if (!isMapScreen(t)) return -1;
    // Cabify's actual heatmap badges show +10%, +20%, etc. They are not fares.
    Pattern badge = Pattern.compile("\\+\\s*[1-6]0\\s*%|\\bx\\s*(1[.,][1-6]|[1-6]0)\\b");
    for (String line : t.split("\\n")) {
      if (line.matches(".*(bono|extra|incentivo|propina|comision|descuento).*")) continue;
      if (badge.matcher(line).find()) return 3;
    }
    return -1;
  }

  public static boolean isMapScreen(String raw) {
    String t = OfferParser.normalize(raw);
    if (t.contains("historial")
        || t.contains("total ganancias")
        || t.contains("precio base")
        || t.contains("total a cobrar")
        || t.contains("comision reducida")
        || t.contains("aceptar")) return false;
    return t.contains("mapa")
        || t.contains("mapa de demanda")
        || t.contains("buscando viajes")
        || t.contains("viajes disponibles para ti");
  }
}
