package com.cocotaxi.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;

/** Explicit MediaProjection fallback; Android owns the consent dialog. */
public final class CaptureService extends Service {
  private MediaProjection projection;
  private VirtualDisplay display;
  private ImageReader reader;
  private long last;
  private final Handler handler = new Handler(Looper.getMainLooper());

  @Override
  public int onStartCommand(Intent i, int flags, int id) {
    if (i != null && "STOP".equals(i.getAction())) {
      stopSelf();
      return START_NOT_STICKY;
    }
    if (i == null || projection != null) return START_NOT_STICKY;
    NotificationManager nm = getSystemService(NotificationManager.class);
    nm.createNotificationChannel(
        new NotificationChannel(
            "coco_capture", "Captura de respaldo", NotificationManager.IMPORTANCE_LOW));
    PendingIntent stop =
        PendingIntent.getService(
            this,
            2,
            new Intent(this, CaptureService.class).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE);
    if ("STOP".equals(i.getAction())) {
      stopSelf();
      return START_NOT_STICKY;
    }
    startForeground(
        102,
        new Notification.Builder(this, "coco_capture")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("COCO: captura de respaldo")
            .setContentText("Solo procesa Cabify durante una sesión")
            .addAction(new Notification.Action.Builder(null, "Detener", stop).build())
            .build());
    try {
      Intent data = i.getParcelableExtra("data");
      if (data == null) {
        stopSelf();
        return START_NOT_STICKY;
      }
      projection =
          getSystemService(MediaProjectionManager.class)
              .getMediaProjection(i.getIntExtra("code", Activity.RESULT_CANCELED), data);
      projection.registerCallback(
          new MediaProjection.Callback() {
            @Override
            public void onStop() {
              stopSelf();
            }
          },
          handler);
      android.util.DisplayMetrics m = getResources().getDisplayMetrics();
      int width = m.widthPixels, height = m.heightPixels;
      reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
      reader.setOnImageAvailableListener(
          r -> {
            Image image = r.acquireLatestImage();
            if (image == null) return;
            try {
              CocotaxiAccessibilityService a = CocotaxiAccessibilityService.instance;
              CocoStore.Session s = CocoStore.get(this).session();
              long now = SystemClock.elapsedRealtime();
              if (a == null || !s.active || s.paused || now - last < 3500 || !a.cabifyForeground())
                return;
              last = now;
              Image.Plane p = image.getPlanes()[0];
              int stride = p.getPixelStride(),
                  padding = p.getRowStride() - stride * image.getWidth();
              Bitmap padded =
                  Bitmap.createBitmap(
                      image.getWidth() + padding / stride,
                      image.getHeight(),
                      Bitmap.Config.ARGB_8888);
              padded.copyPixelsFromBuffer(p.getBuffer());
              Bitmap bitmap =
                  Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
              if (bitmap != padded) padded.recycle();
              a.processBitmap(bitmap);
            } finally {
              image.close();
            }
          },
          handler);
      display =
          projection.createVirtualDisplay(
              "CocoCapture",
              width,
              height,
              m.densityDpi,
              DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
              reader.getSurface(),
              null,
              handler);
    } catch (RuntimeException e) {
      CocotaxiAccessibilityService.diagnostic = "Captura no iniciada; vuelve a autorizar";
      stopSelf();
    }
    return START_NOT_STICKY;
  }

  @Override
  public IBinder onBind(Intent i) {
    return null;
  }

  @Override
  public void onDestroy() {
    if (display != null) display.release();
    if (reader != null) reader.close();
    if (projection != null) {
      MediaProjection p = projection;
      projection = null;
      p.stop();
    }
    handler.removeCallbacksAndMessages(null);
    super.onDestroy();
  }
}
