> Versión actual: **2.4.2**. Lee `CAMBIOS_2.4.2.md` y `PARA_CODEX_PC.md`; las notas inferiores describen versiones anteriores. Sin APK compilada en este entorno.

> Actualización 2.4.1: el factor inicial es **1,00 provisional**. La conciliación posterior con viajes que cruzan medianoche sustituye la hipótesis antigua 0,99. Revisar `CAMBIOS_2.4.1.md`.

# COCOTAXI 2.4.0 — proyecto Android para Codex

Esta entrega contiene cambios reales de código. NO incluye una APK 2.4.0 compilada.
La compilación local quedó bloqueada al descargar Gradle: `Network is unreachable`.
No se ha probado esta versión en un teléfono ni con Cabify real.

## Cambios

- Una meta editable: semanal, por jornada u horaria; las otras se derivan. 11 horas por defecto en instalaciones nuevas; conserva la duración configurada al actualizar.
- Recuperación gradual según dinero pendiente y tiempo restante de la jornada. La jornada no se reinicia a medianoche.
- Promoción manual de sesión: premio, total de viajes, contador corregible, inicio y final con fecha. Accesos 19–23, 23–03 y 03–07.
- Promoción integrada en el motor y en la comparación de ofertas visibles. Abandona el crédito promocional cuando una oferta no deja tiempo suficiente o no cubre el objetivo por hora.
- Solo viajes finalizados cuentan para la promoción; las eliminaciones y restauraciones actualizan el contador. Bonos no son viajes. El premio condicionado nunca altera el pago estimado de un viaje ni el acumulado.
- Ajustes compactos y edición por diálogos; retirados Conexión con Cabify, Pausas y preferencias y Base de cálculo. Historial paginado de dos viajes.
- Inicio guiado de permisos Android, recuperable desde Ajustes. Captura OCR de respaldo se autoriza explícitamente en Demanda y aceptación.
- Icono flotante con el componente redondeado de la base original COCO.zip; tocar abre Coco y arrastrar lo mueve. Minimizado muestra solo el icono.

Inicio, Metas y Ajustes se compactaron para el teléfono de referencia. Se conserva desplazamiento de respaldo para pantallas pequeñas, fuente grande y formularios; no se ocultan controles para forzar que entren.

## Precisión del dinero

El factor inicial 1,00 es provisional: la conciliación de historiales no demuestra cada pareja oferta/cobro. Usa cierres completos del MISMO período de los viajes, sin propinas ni premios; las devoluciones ordinarias quedan incluidas. No entrenar mezclando una jornada que cruza medianoche con un total de otro período.

El promedio principal combina pagos confirmados y estimaciones y los identifica. Para medir exclusivamente cobro de Cabify, deja gastos por km en cero. Un premio cobrado se registra una sola vez como ingreso que no cuenta como viaje.

## Validación de esta entrega

- 25 comprobaciones ejecutadas de clases Java reales de cálculo y decisión: todas pasan (`validation/CORE_CHECKS_2.4.0.txt`). Las dependencias Android se sustituyen únicamente en este arnés, no en la app.
- Análisis de sintaxis de 26 archivos Java sin errores. No equivale a compilar Android.
- Se añaden 6 pruebas Robolectric de promoción, contador, sesiones y metas; pendientes de ejecución con Gradle. Se actualizan las pruebas de UI e icono.
- Pruebas antiguas y capturas anteriores están etiquetadas en `docs/historico_2.3.1`; no acreditan la versión nueva.

Para compilar y verificar en el PC: **INSTRUCCIONES_CODEX.md**.
La fórmula y sus límites están en **docs/FORMULA.md**.
