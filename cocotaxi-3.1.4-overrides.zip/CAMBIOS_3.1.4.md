# COCOTAXI 3.1.4 Core — correcciones de auditoría

Base: fuentes completas 3.1.3, `versionCode 54`. Esta entrega requiere pruebas unitarias y compilación Android antes de instalarla.

## Viajes manuales

- Una sesión activa o pausada mantiene su tiempo conectado y registra de golpe los minutos terminados en «En servicio». Si el total de servicio supera el tiempo conectado, agrega solamente los minutos faltantes de cobertura.
- Una sesión cerrada suma el viaje completo a Conectado y En servicio de esa sesión; el ingreso y el número de viajes quedan allí asociados.
- Cada viaje guarda `connected_delta`, la adición real a Conectado. Corregir, borrar y restaurar revierten exactamente ese delta. Migración SQLite 6→7 conserva los ajustes completos de las versiones antiguas.
- Un viaje manual permanece `FINALIZADO` y no enciende el cronómetro vivo. El formulario muestra la sesión destinataria.

## Captura y recuperación

- El parser une una coma decimal y dos cifras entregadas en el nodo adyacente. Si OCR lee los centavos y Accesibilidad sólo un importe entero compatible, la fusión conserva los centavos. Cuando ambos canales sólo ven un entero, no hay evidencia para adivinar los centavos.
- El parser considera etiquetas de peajes, bonos y saldo cercanas a cada importe en un árbol aplanado.
- Corregir el pago de un viaje `ASIGNADO` cierra su tramo de servicio, anula anclas y promueve el siguiente en la misma transacción. Se sincronizan las correcciones y los cambios de estado.
- «Otro conductor» y errores de aceptación sólo descalifican un `INTENTO`; una asignación vigente exige señal de cancelación.
- Al reiniciar sin viaje activo, una sesión que estaba corriendo vuelve a correr sin contar tiempo de apagado. Una pausa manual permanece pausada.
- Tras desbloquear el PIN, se inicia la ventana flotante cuando hay sesión activa y permiso.

## Pruebas añadidas o adaptadas

- Viaje de $200 / 10 min tras 20 s: 10 min conectados, 10 min de servicio y 1200/h; borrarlo devuelve 20 s y restaurarlo repone 10 min.
- Sesión en marcha durante 25 min, sesión pausada durante 30 min, corrección de minutos, sesión cerrada, viaje activo con `SIGUIENTE`, reinicio sin viaje, importe `$398,97` dividido y fusión de Accesibilidad/OCR.

## Límite de la auditoría

Las pruebas de Android no sustituyen una captura real de la pantalla que mostró `$398` sin centavos. La calidad de las lecturas OCR y las transiciones de Cabify se debe comprobar en el Galaxy A55 antes de usar aceptación automática.
