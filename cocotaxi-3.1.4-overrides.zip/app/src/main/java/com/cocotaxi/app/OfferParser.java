package com.cocotaxi.app;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/** Parse Cabify offer cards from Accessibility/OCR without mixing header balances or $/h metrics. */
public final class OfferParser {
  private static final Pattern PRICE =
      Pattern.compile("(?:\\$u?|u\\$|uyu)\\s*([0-9](?:[0-9]|[.,]\\s*[0-9])*)", Pattern.CASE_INSENSITIVE);
  private static final Pattern MIN = Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*min(?:utos?)?\\b");
  private static final Pattern KM = Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*(km|m)\\b");
  private static final Pattern WS = Pattern.compile("\\s+");
  private static final Pattern ACCEPT_ACTION =
      Pattern.compile("(?iu)aceptar(?:\\s+(?:viaje|carrera))?");
  // Accessibility may expose the integer and the decimal separator in adjacent text nodes.
  private static final Pattern SPLIT_CENTS =
      Pattern.compile("(?i)((?:\\$u?|u\\$|uyu)\\s*[0-9][0-9.]*)\\s*\\n\\s*([,.])\\s*([0-9]{2})\\b");

  private OfferParser() {}

  /** Unicode normalization without recompiling a regex on every call. */
  public static String normalize(String s) {
    if (s == null || s.isEmpty()) return "";
    String decomposed = Normalizer.normalize(s, Normalizer.Form.NFD);
    StringBuilder out = new StringBuilder(decomposed.length());
    for (int i = 0; i < decomposed.length(); i++) {
      char c = decomposed.charAt(i);
      int type = Character.getType(c);
      if (type != Character.NON_SPACING_MARK
          && type != Character.COMBINING_SPACING_MARK
          && type != Character.ENCLOSING_MARK) out.append(Character.toLowerCase(c));
    }
    return out.toString();
  }

  public static boolean isHistoryScreen(String text) {
    return isHistoryNormalized(normalize(text));
  }

  public static boolean isHistoryNormalized(String s) {
    if (s == null) return false;
    return s.contains("historial")
        || s.contains("total ganancias")
        || s.contains("total a cobrar")
        || s.contains("precio base")
        || s.contains("comision reducida");
  }

  public static boolean isLikelyOfferScreen(String text) {
    return isLikelyOfferNormalized(normalize(text));
  }

  public static boolean isLikelyOfferNormalized(String s) {
    if (s == null || isHistoryNormalized(s)) return false;
    return s.contains("aceptar")
        || s.contains("para ti")
        || s.contains("en app")
        || s.contains("viaje disponible");
  }

  public static Offer parse(String text, String pkg) {
    return parseNormalized(text, normalize(text), pkg);
  }

  /** Parse when the caller already normalized the same accessibility/OCR frame. */
  public static Offer parseNormalized(String rawText, String normalized, String pkg) {
    Offer o = new Offer();
    o.rawText = rawText == null ? "" : rawText;
    o.platform = "Cabify";
    String s = normalized == null ? "" : SPLIT_CENTS.matcher(normalized).replaceAll("$1$2$3");
    o.hasOfferSignal = isLikelyOfferNormalized(s);
    if (!o.hasOfferSignal) return o;
    o.kind = s.contains("para ti") ? "PARA_TI" : s.contains("en app") ? "EN_APP" : "UNKNOWN";

    PricePick fare = pickFare(s);
    if (fare != null) o.fare = fare.value;
    o.tolls = pickTolls(s);

    Matcher m = MIN.matcher(s);
    List<double[]> legs = new ArrayList<>();
    List<Integer> starts = new ArrayList<>(), ends = new ArrayList<>();
    while (m.find()) {
      starts.add(m.start());
      ends.add(m.end());
      legs.add(new double[] {Money.metric(m.group(1)), -1});
    }
    for (int i = 0; i < legs.size(); i++) {
      String after = s.substring(ends.get(i), i + 1 < legs.size() ? starts.get(i + 1) : s.length());
      Matcher d = KM.matcher(after);
      if (d.find()) legs.get(i)[1] = Money.metric(d.group(1)) / (d.group(2).equals("m") ? 1000 : 1);
    }
    if (legs.size() == 2) {
      o.pickupMin = legs.get(0)[0];
      o.pickupKm = legs.get(0)[1];
      o.tripMin = legs.get(1)[0];
      o.tripKm = legs.get(1)[1];
      o.pickupArea = cleanArea(s.substring(ends.get(0), starts.get(1)));
      o.destinationArea = cleanArea(s.substring(ends.get(1)));
    } else {
      o.warning = legs.size() > 2 ? "Varias rutas: no mezclar tarjetas" : "Faltan los dos tiempos";
    }

    if (!o.hasFare() && o.warning.isEmpty()) o.warning = "Falta el importe del viaje";
    rebuildKey(o, s);
    return o;
  }

  /**
   * Select the real offer fare even when Cabify puts header balance, $/km and $/h in the same
   * accessibility line. Per-km/per-hour amounts are rejected individually instead of discarding the
   * whole line. Markers such as "para ti" and "en app" strongly win over unrelated balances.
   */
  private static PricePick pickFare(String s) {
    List<PricePick> candidates = new ArrayList<>();
    Matcher m = PRICE.matcher(s);
    while (m.find()) {
      // Use the local price context: a flattened tree can also contain unrelated tolls, bonuses
      // and balances far away from the actual fare on the same line.
      String context = s.substring(Math.max(0, m.start() - 18), Math.min(s.length(), m.end() + 12));
      if (context.contains("peaje") || excludedPriceContext(context)) continue;
      String line = lineAt(s, m.start());
      int end = Math.min(s.length(), m.end() + 18);
      String suffix = s.substring(m.end(), end);
      if (suffix.matches("(?s)^\\s*(?:/|por\\s+)(?:h|hora|km)\\b.*")) continue;
      double value = Money.parse(m.group(1));
      if (!Double.isFinite(value) || value <= 0) continue;
      int score = 0;
      String before = s.substring(Math.max(0, m.start() - 24), m.start());
      String after = s.substring(m.end(), Math.min(s.length(), m.end() + 24));
      String around = s.substring(Math.max(0, m.start() - 32), Math.min(s.length(), m.end() + 40));
      // Direct adjacency is strong evidence. This distinguishes "$392 para ti" from a wallet
      // balance that merely happens to be earlier on the same flattened accessibility line.
      if (after.matches("(?s)^\\s*(?:para ti|en app)\\b.*")
          || before.matches("(?s).*(?:para ti|en app)\\s*$")) score += 16;
      else {
        if (around.contains("para ti")) score += 4;
        if (around.contains("en app")) score += 3;
      }
      if (around.contains("pago en la app") || around.contains("pago en efectivo")) score += 7;
      if (around.contains("aceptar")) score += 2;
      String prefix = s.substring(Math.max(0, m.start() - 18), m.start());
      if (prefix.contains("saldo") || prefix.contains("billetera") || prefix.contains("ganancias")) score -= 12;
      candidates.add(new PricePick(value, score, m.start()));
    }
    if (candidates.isEmpty()) return null;
    candidates.sort((a, b) -> a.score != b.score ? Integer.compare(b.score, a.score) : Integer.compare(b.pos, a.pos));
    PricePick best = candidates.get(0);
    if (candidates.size() == 1) return best.score >= 0 ? best : null;
    PricePick second = candidates.get(1);
    // With an explicit Cabify offer marker, a clearly better candidate is safe. Without one, refuse
    // to guess between two unrelated monetary amounts.
    return best.score >= 7 && best.score > second.score ? best : null;
  }

  private static double pickTolls(String s) {
    Matcher label = Pattern.compile("\\bpeajes?\\b").matcher(s);
    while (label.find()) {
      Matcher after = PRICE.matcher(s.substring(label.end(), Math.min(s.length(), label.end() + 25)));
      if (after.find()) return Math.max(0, Money.parse(after.group(1)));
      int from = Math.max(0, label.start() - 25);
      Matcher before = PRICE.matcher(s.substring(from, label.start()));
      double value = 0;
      while (before.find()) value = Money.parse(before.group(1));
      if (value > 0) return value;
    }
    return 0;
  }

  private static String lineAt(String s, int at) {
    int start = s.lastIndexOf('\n', Math.max(0, at - 1));
    int end = s.indexOf('\n', at);
    if (start < 0) start = 0; else start++;
    if (end < 0) end = s.length();
    return s.substring(start, end);
  }

  private static boolean excludedPriceContext(String l) {
    return l.contains("bono")
        || l.contains("extra")
        || l.contains("propina")
        || l.contains("incentivo")
        || l.contains("comision")
        || l.contains("descuento");
  }

  private static final class PricePick {
    final double value;
    final int score, pos;
    PricePick(double value, int score, int pos) { this.value = value; this.score = score; this.pos = pos; }
  }

  /**
   * Fuse Accessibility and OCR readings only when they describe the same visible offer.
   * Accessibility remains authoritative for click geometry; OCR fills fields Android omitted.
   */
  public static Offer merge(Offer primary, Offer secondary) {
    if (primary == null) return copy(secondary);
    if (secondary == null) return copy(primary);
    if (!compatible(primary, secondary)) return copy(primary);

    Offer out = copy(primary);
    if (!out.hasFare() && secondary.hasFare()) out.fare = secondary.fare;
    else if (out.hasFare() && secondary.hasFare()
        && Math.abs(out.fare - Math.rint(out.fare)) < .001
        && secondary.fare > out.fare && secondary.fare < out.fare + 1)
      out.fare = secondary.fare; // OCR saw cents that the accessibility tree omitted.
    if (!out.hasPickup() && secondary.hasPickup()) out.pickupMin = secondary.pickupMin;
    if (!out.hasTrip() && secondary.hasTrip()) out.tripMin = secondary.tripMin;
    if (out.pickupKm < 0 && secondary.pickupKm >= 0) out.pickupKm = secondary.pickupKm;
    if (out.tripKm < 0 && secondary.tripKm >= 0) out.tripKm = secondary.tripKm;
    if (out.tolls <= 0 && secondary.tolls > 0) out.tolls = secondary.tolls;
    if (out.pickupArea.isEmpty()) out.pickupArea = secondary.pickupArea;
    if (out.destinationArea.isEmpty()) out.destinationArea = secondary.destinationArea;
    out.hasOfferSignal |= secondary.hasOfferSignal;
    if ((out.warning.startsWith("Faltan") || out.warning.startsWith("Falta el importe") || out.warning.isEmpty())
        && out.hasFare() && out.hasPickup() && out.hasTrip()) out.warning = "";
    if (out.rawText.isEmpty()) out.rawText = secondary.rawText;
    rebuildKey(out, normalize(out.rawText));
    return out;
  }

  private static boolean compatible(Offer a, Offer b) {
    if (a.hasFare() && b.hasFare() && Math.abs(a.fare - b.fare) > 1.01) return false;
    if (a.hasPickup() && b.hasPickup() && Math.abs(a.pickupMin - b.pickupMin) > 3.01) return false;
    if (a.hasTrip() && b.hasTrip() && Math.abs(a.tripMin - b.tripMin) > 4.01) return false;
    return true;
  }

  private static Offer copy(Offer a) {
    if (a == null) return null;
    Offer o = new Offer();
    o.kind = a.kind;
    o.warning = a.warning;
    o.key = a.key;
    o.top = a.top;
    o.bottom = a.bottom;
    o.platform = a.platform;
    o.rawText = a.rawText;
    o.pickupArea = a.pickupArea;
    o.destinationArea = a.destinationArea;
    o.pickupHeat = a.pickupHeat;
    o.destinationHeat = a.destinationHeat;
    o.zoneEvidence = a.zoneEvidence;
    o.fare = a.fare;
    o.pickupKm = a.pickupKm;
    o.pickupMin = a.pickupMin;
    o.tripKm = a.tripKm;
    o.tripMin = a.tripMin;
    o.tolls = a.tolls;
    o.hasOfferSignal = a.hasOfferSignal;
    return o;
  }

  private static String cleanArea(String segment) {
    if (segment == null || segment.isEmpty()) return "";
    StringBuilder out = new StringBuilder();
    for (String raw : segment.split("\n")) {
      String line = KM.matcher(raw).replaceAll(" ").trim();
      line = PRICE.matcher(line).replaceAll(" ").trim();
      line = line.replaceAll("(?iu)(?:/|por\\s+)(?:h|hora|km)\\b", " ");
      line = line.replaceAll("(?iu)\\b[0-9]+%\\b", " ");
      line = truncateAreaNoise(line);
      line = line.replace('·', ' ').replaceAll("^[|,:;\\-\\s]+|[|,:;\\-\\s]+$", "").trim();
      if (line.isEmpty() || areaNoiseOnly(line)) continue;
      if (out.length() > 0) out.append(" ");
      out.append(line);
      if (out.length() > 180) break;
    }
    return WS.matcher(out.toString()).replaceAll(" ").trim();
  }

  /**
   * Flattened Accessibility trees can put the address and UI actions on the same physical line.
   * Truncate only the UI suffix instead of discarding the complete line (and therefore the area).
   */
  private static String truncateAreaNoise(String line) {
    if (line == null || line.isEmpty()) return "";
    String lower = line.toLowerCase(Locale.ROOT);
    String[] markers = {
      " aceptar viaje", " aceptar carrera", " aceptar servicio", " aceptar",
      " detalle del viaje", " viajes realizados", " valoracion", " usuario",
      " metodo de pago", " reserva", " promos", " billetera"
    };
    int cut = line.length();
    for (String marker : markers) {
      int at = lower.indexOf(marker);
      if (at >= 0 && at < cut) cut = at;
    }
    return line.substring(0, cut).trim();
  }

  private static boolean areaNoiseOnly(String l) {
    String x = l == null ? "" : l.trim();
    return x.isEmpty()
        || x.equals("cabify")
        || x.equals("para ti")
        || x.equals("en app")
        || x.equals("privado")
        || x.equals("mapa");
  }

  private static void rebuildKey(Offer o, String normalized) {
    String basis = normalized == null ? "" : normalized;
    o.key =
        o.kind
            + "|"
            + o.fare
            + "|"
            + o.pickupMin
            + "|"
            + o.tripMin
            + "|"
            + o.pickupKm
            + "|"
            + o.tripKm
            + "|"
            + o.pickupArea
            + "|"
            + o.destinationArea
            + "|"
            + WS.matcher(basis).replaceAll(" ").trim();
  }

  /** Parse one or more visible offer cards from OCR/accessibility text. */
  public static List<Offer> parseVisible(String text) {
    return parseVisibleNormalized(normalize(text));
  }

  public static List<Offer> parseVisibleNormalized(String normalizedText) {
    List<Offer> out = new ArrayList<>();
    String normalized = normalizedText == null ? "" : normalizedText;
    if (isHistoryNormalized(normalized)) return out;

    Matcher countMatcher = ACCEPT_ACTION.matcher(normalized);
    int actionCount = 0;
    while (countMatcher.find()) actionCount++;

    // A single visible offer may expose Aceptar before, after or in the middle of the card.
    // Parsing the whole screen avoids splitting its price from its times.
    if (actionCount <= 1) {
      Offer o = parseNormalized(normalized, normalized, "com.cabify.driver");
      if (o.hasEnoughForDecision()) out.add(o);
      return out;
    }

    // Multi-card Accessibility normally uses TextCollector.cards(). Keep a conservative text/OCR
    // fallback here: parse chunks ending at each Accept and also the final tail, deduplicating keys.
    Matcher actions = ACCEPT_ACTION.matcher(normalized);
    int start = 0;
    while (actions.find()) {
      addVisibleChunk(out, normalized.substring(start, actions.end()));
      start = actions.end();
    }
    if (start < normalized.length()) addVisibleChunk(out, normalized.substring(start));
    return out;
  }

  private static void addVisibleChunk(List<Offer> out, String chunk) {
    Offer o = parseNormalized(chunk, chunk, "com.cabify.driver");
    if (!o.hasEnoughForDecision()) return;
    for (Offer existing : out) if (existing.key.equals(o.key)) return;
    out.add(o);
  }
}
