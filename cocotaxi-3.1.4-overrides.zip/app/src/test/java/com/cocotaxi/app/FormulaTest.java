package com.cocotaxi.app;

import static org.junit.Assert.*;

import org.junit.Test;

public class FormulaTest {
  private SettingsStore.Values values() {
    SettingsStore.Values v = new SettingsStore.Values();
    v.realGoalHour = 700;
    v.operationalGoalHour = 700;
    v.payoutMode = 1;
    v.factor = 1;
    v.maxPickupKm = 0;
    v.maxPickupMin = 0;
    return v;
  }

  private CocoStore.Session session() {
    CocoStore.Session s = new CocoStore.Session();
    s.active = true;
    return s;
  }

  private Offer offer(double fare, int pickup, int trip) {
    return OfferParser.parse(
        "Para ti $" + fare + "\n" + pickup + " min · 339 m\n" + trip + " min · 4.1 km\nAceptar",
        "com.cabify.driver");
  }

  @Test
  public void example188() {
    DecisionEngine.Result r =
        DecisionEngine.evaluate(offer(188, 3, 9), values(), session(), 2, null);
    assertEquals(940, r.hourly, .001);
    assertTrue(r.accept);
  }

  @Test
  public void projection160() {
    CocoStore.Session s = session();
    s.minutes = 60;
    s.money = 480;
    DecisionEngine.Result r = DecisionEngine.evaluate(offer(160, 3, 7), values(), s, 2, null);
    assertEquals(548.571428, r.projected, .00001);
    assertEquals(336.666666, r.recoverAll, .00001);
  }

  @Test
  public void projection400() {
    CocoStore.Session s = session();
    s.minutes = 60;
    s.money = 480;
    assertEquals(
        754.285714,
        DecisionEngine.evaluate(offer(400, 3, 7), values(), s, 2, null).projected,
        .00001);
  }

  @Test
  public void pickupCounts() {
    assertEquals(
        1231.25,
        DecisionEngine.evaluate(offer(985, 7, 41), values(), session(), 2, null).hourly,
        .001);
  }

  @Test
  public void tollsNotProfit() {
    Offer o = offer(188, 3, 9);
    o.tolls = 167;
    assertEquals(188, DecisionEngine.evaluate(o, values(), session(), 2, null).net, .001);
  }

  @Test
  public void factorAppliedExactlyOnce() {
    SettingsStore.Values v = values();
    v.factor = .9;
    assertEquals(
        169.20, DecisionEngine.evaluate(offer(188, 3, 9), v, session(), 2, null).payout, .001);
  }

  @Test
  public void zeroFareNotOffer() {
    assertFalse(offer(0, 3, 9).hasEnoughForDecision());
  }

  @Test
  public void calibrationRequired() {
    SettingsStore.Values v = values();
    v.payoutMode = 0;
    assertFalse(DecisionEngine.evaluate(offer(999, 3, 9), v, session(), 2, null).accept);
  }

  @Test
  public void missingTimeFailsClosed() {
    assertFalse(
        OfferParser.parse("Para ti $188\n9 min\nAceptar", "com.cabify.driver")
            .hasEnoughForDecision());
  }

  @Test
  public void historyNotOffer() {
    assertFalse(
        OfferParser.parse("Historial\nPara ti $188\n3 min\n9 min\nAceptar", "com.cabify.driver")
            .hasEnoughForDecision());
  }

  @Test
  public void lowMorePermissive() {
    Offer o = offer(130, 3, 9);
    assertTrue(DecisionEngine.evaluate(o, values(), session(), 1, null).accept);
    assertFalse(DecisionEngine.evaluate(o, values(), session(), 3, null).accept);
  }

  @Test
  public void deadHoursMorePermissive() {
    assertTrue(DecisionEngine.evaluate(offer(110, 3, 9), values(), session(), 0, null).accept);
    assertFalse(DecisionEngine.evaluate(offer(110, 3, 9), values(), session(), 2, null).accept);
  }

  @Test
  public void pauseRejects() {
    CocoStore.Session s = session();
    s.paused = true;
    assertFalse(DecisionEngine.evaluate(offer(999, 3, 9), values(), s, 2, null).accept);
  }

  @Test
  public void recoveryNotBefore60() {
    SettingsStore.Values v = values();
    v.recovery = true;
    CocoStore.Session s = session();
    s.minutes = 59;
    s.money = 0;
    assertEquals(700, DecisionEngine.evaluate(offer(200, 3, 9), v, s, 2, null).threshold, .001);
    s.minutes = 60;
    assertEquals(840, DecisionEngine.evaluate(offer(200, 3, 9), v, s, 2, null).threshold, .001);
  }

  @Test
  public void hypotheticalNextWaitDoesNotPenalizeCurrentOffer() {
    SettingsStore.Values v = values();
    v.waitNext = 8;
    assertEquals(
        940, DecisionEngine.evaluate(offer(188, 3, 9), v, session(), 2, null).hourly, .001);
  }

  @Test
  public void costsAndEmptyDistance() {
    SettingsStore.Values v = values();
    v.costKm = 10;
    v.emptyKm = 1;
    DecisionEngine.Result r = DecisionEngine.evaluate(offer(188, 3, 9), v, session(), 2, null);
    assertEquals(54.39, r.cost, .001);
    assertEquals(133.61, r.net, .001);
  }

  @Test
  public void moneyLocales() {
    assertEquals(1442, Money.parse("1.442"), .001);
    assertEquals(275.04, Money.parse("275,04"), .001);
    assertEquals(1234.56, Money.parse("1.234,56"), .001);
    assertEquals(1234.56, Money.parse("1,234.56"), .001);
  }

  @Test
  public void splitAccessibilityCentsAndOcrMergeKeepRealFare() {
    String legs = "\n5 min · 2 km\n10 min · 4 km\nAceptar viaje";
    Offer split = OfferParser.parse("$398\n,97 para ti" + legs, "com.cabify.driver");
    assertEquals(398.97, split.fare, .001);
    Offer integer = OfferParser.parse("$398 para ti" + legs, "com.cabify.driver");
    Offer ocr = OfferParser.parse("$398,97 para ti" + legs, "com.cabify.driver");
    assertEquals(398.97, OfferParser.merge(integer, ocr).fare, .001);
    assertEquals("$398,97", Money.format(OfferParser.merge(integer, ocr).fare));
  }

  @Test
  public void cabifyFareKeepsCentsIncludingSpacedDecimalSeparator() {
    Offer compact =
        OfferParser.parse("Aceptar\n$180,99 en app\n3 min · 1 km\n10 min · 4 km", "com.cabify.driver");
    Offer spaced =
        OfferParser.parse("Aceptar\n$ 180, 99 en app\n3 min · 1 km\n10 min · 4 km", "com.cabify.driver");
    assertEquals(180.99, compact.fare, .0001);
    assertEquals(180.99, spaced.fare, .0001);
    assertEquals("$180,99", Money.format(180.99));
  }

  @Test
  public void kilometerDecimal() {
    assertEquals(.339, offer(188, 3, 9).pickupKm, .00001);
    assertEquals(4.1, offer(188, 3, 9).tripKm, .00001);
  }

  @Test
  public void twoCardsNotMixed() {
    String t =
        "Para ti $188\n"
            + "3 min · 339 m\n"
            + "9 min · 4.1 km\n"
            + "Aceptar\n"
            + "Para ti $300\n"
            + "2 min · 1 km\n"
            + "10 min · 5 km\n"
            + "Aceptar";
    assertEquals(2, OfferParser.parseVisible(t).size());
    assertFalse(OfferParser.parse(t, "com.cabify.driver").hasEnoughForDecision());
  }

  @Test
  public void unknownMultipliersNotMoney() {
    assertEquals(-1, DemandModel.textSignal("Oferta $188 x20\n3 min\n9 min"));
    assertEquals(3, DemandModel.textSignal("Mapa de demanda x20"));
  }

  @Test
  public void hoursCrossMidnight() {
    assertTrue(DemandModel.inRange(1, 23, 6));
    assertFalse(DemandModel.inRange(7, 23, 6));
  }

  @Test
  public void learnedFivePairsRequired() {
    SettingsStore.Values v = values();
    v.payoutMode = 2;
    CocoStore.Calibration c = new CocoStore.Calibration();
    c.factor = .9;
    c.count = 4;
    assertFalse(DecisionEngine.evaluate(offer(300, 3, 9), v, session(), 2, c).accept);
    c.count = 5;
    assertTrue(DecisionEngine.evaluate(offer(300, 3, 9), v, session(), 2, c).accept);
  }

  @Test
  public void rankingChoosesSecondVisible() {
    DecisionEngine.Result
        a = DecisionEngine.evaluate(offer(188, 3, 9), values(), session(), 2, null),
        b = DecisionEngine.evaluate(offer(300, 2, 10), values(), session(), 2, null);
    assertSame(b, OfferRanking.best(java.util.Arrays.asList(a, b)));
  }

  @Test
  public void higherFareNotNecessarilyBetter() {
    DecisionEngine.Result
        a = DecisionEngine.evaluate(offer(188, 3, 9), values(), session(), 2, null),
        b = DecisionEngine.evaluate(offer(300, 10, 40), values(), session(), 2, null);
    assertSame(a, OfferRanking.best(java.util.Arrays.asList(a, b)));
  }


  @Test
  public void singleSaldoCandidateCannotBecomeFare() {
    Offer o =
        OfferParser.parse(
            "Saldo $500\nAceptar\n3 min · 1 km\n9 min · 4 km",
            "com.cabify.driver");
    assertFalse(o.hasEnoughForDecision());
    assertFalse(o.hasFare());
  }

  @Test
  public void offerWithPersistentPromosWalletFooterIsNotHistory() {
    String screen =
        "Cabify\n$188 en app\n3 min · 1 km\n9 min · 4 km\nAceptar\n"
            + "Inicio Reservas Promos Billetera";
    assertFalse(OfferParser.isHistoryScreen(screen));
    Offer o = OfferParser.parse(screen, "com.cabify.driver");
    assertTrue(o.hasEnoughForDecision());
    assertEquals(188, o.fare, .001);
  }

  @Test
  public void parseVisibleSupportsAcceptBeforeFare() {
    String screen =
        "CABIFY\nAceptar\n$188 en app\n$44/km\n3 min · 339 m\n"
            + "Buceo - Ramos, 4431\n9 min · 4.1 km\nCarrasco Norte - Avenida Italia, 5775";
    java.util.List<Offer> offers = OfferParser.parseVisible(screen);
    assertEquals(1, offers.size());
    assertEquals(188, offers.get(0).fare, .001);
    assertEquals(12, offers.get(0).totalMinutes(), .001);
  }

  @Test
  public void actualPhoto188EnApp() {
    Offer o =
        OfferParser.parse(
            "CABIFY\n"
                + "Aceptar\n"
                + "$188 en app\n"
                + "$44/km\n"
                + "37 viajes · 100%\n"
                + "3 min · 339 m\n"
                + "Buceo - Ramos, 4431\n"
                + "9 min · 4.1 km\n"
                + "Carrasco Norte - Avenida Italia, 5775",
            "com.cabify.driver");
    assertTrue(o.hasEnoughForDecision());
    assertEquals("EN_APP", o.kind);
    assertEquals(188, o.fare, .001);
    assertEquals(12, o.totalMinutes(), .001);
  }

  @Test
  public void realMapPercentagesAndFooterAreDemandNotWallet() {
    String map =
        "Google\n"
            + "+10%\n"
            + "+20%\n"
            + "Buscando viajes...\n"
            + "Hasta $U 2.000 extra\n"
            + "$U 1.000 si haces 10 viajes en 3 dias y 2 h\n"
            + "Sigue la demanda en el Mapa\n"
            + "Inicio Reservas Promos Billetera";
    assertEquals(3, DemandModel.textSignal(map));
    assertFalse(OfferParser.isHistoryScreen(map));
    assertTrue(OfferParser.parseVisible(map).isEmpty());
  }

  @Test
  public void availableTripsMapNeedsNoLiteralMapLabel() {
    assertEquals(
        3, DemandModel.textSignal("$10.999\nGoogle\n+10%\n+20%\n2 viajes disponibles para ti"));
  }

  @Test
  public void bonusPercentageAndHistoryDoNotActivateDemand() {
    assertEquals(-1, DemandModel.textSignal("Mapa\nBono +20% extra"));
    assertEquals(-1, DemandModel.textSignal("Historial\nMapa +20%"));
    assertEquals(-1, DemandModel.textSignal("Aceptar\n$188 en app\n+20%\n3 min\n9 min"));
  }

  @Test
  public void demandRaisesFilterWithoutAddingPercentToFare() {
    DecisionEngine.Result low =
        DecisionEngine.evaluate(offer(188, 3, 9), values(), session(), 1, null);
    DecisionEngine.Result high =
        DecisionEngine.evaluate(
            offer(188, 3, 9), values(), session(), DemandModel.textSignal("Mapa\n+20%"), null);
    assertEquals(low.payout, high.payout, .001);
    assertTrue(high.threshold > low.threshold);
  }
  @Test
  public void eightHundredPerHourUsesTotalMinutesNotFareSize() {
    SettingsStore.Values v = values();
    v.goalMode = 2;
    v.realGoalHour = 800;
    v.operationalGoalHour = 800;
    v.objectiveHour = 800;
    v.waitPassenger = 0;
    CocoStore.Session s = session();
    DecisionEngine.Result a = DecisionEngine.evaluate(offer(600, 0, 60), v, s, 2, null);
    assertEquals(600, a.hourly, .001);
    assertFalse(a.accept);
    DecisionEngine.Result b = DecisionEngine.evaluate(offer(200, 0, 20), v, s, 2, null);
    assertEquals(600, b.hourly, .001);
    assertFalse(b.accept);
    DecisionEngine.Result c = DecisionEngine.evaluate(offer(200, 0, 15), v, s, 2, null);
    assertEquals(800, c.hourly, .001);
    assertTrue(c.accept);
  }


  @Test
  public void mapSignalExpiresAndCanBeDisabled() {
    SettingsStore.Values v = values();
    v.mapDemand = true;
    long now =
        java.time.ZonedDateTime.of(2026, 9, 14, 3, 0, 0, 0, CocoStore.ZONE)
            .toInstant()
            .toEpochMilli();
    assertEquals(3, DemandModel.level(v, now, 3, now - 1000));
    assertEquals(0, DemandModel.level(v, now, 3, now - 30001));
    v.mapDemand = false;
    assertEquals(0, DemandModel.level(v, now, 3, now));
  }
  @Test
  public void currentObjectiveUsesMoneyMissingOverJornadaTimeRemaining() {
    assertEquals(850, PromotionMath.requiredHourly(8000, 10, 120, 1200), .001);
    assertEquals(812.5, PromotionMath.requiredHourly(8000, 10, 120, 1500), .001);
  }


  @Test
  public void realFieldTreeWithFarePerKmAndPerHourParses392() {
    String field =
        "cabify $ 392 para ti $ 39/km · $ 1.383/h 5 min · 2 km parque rodo | "
            + "doctor joaquin requena, 1094 17 min · 10 km tres ombues, victoria | "
            + "calera de las huerfanas, 4320 aceptar viaje detalle del viaje";
    Offer o = OfferParser.parse(field, "com.cabify.driver");
    assertTrue(o.hasEnoughForDecision());
    assertEquals(392, o.fare, .001);
    assertEquals(5, o.pickupMin, .001);
    assertEquals(17, o.tripMin, .001);
    assertEquals(2, o.pickupKm, .001);
    assertEquals(10, o.tripKm, .001);
    assertTrue(o.pickupArea.contains("parque rodo"));
    assertTrue(o.pickupArea.contains("doctor joaquin requena"));
    assertTrue(o.destinationArea.contains("tres ombues"));
    assertTrue(o.destinationArea.contains("calera de las huerfanas"));
  }

  @Test
  public void headerBalanceDoesNotBeatFareNearParaTi() {
    Offer o = OfferParser.parse(
        "$ 10.999\nCabify\n$392 para ti\n$39/km · $1.383/h\n5 min · 2 km\n17 min · 10 km\nAceptar viaje",
        "com.cabify.driver");
    assertTrue(o.hasEnoughForDecision());
    assertEquals(392, o.fare, .001);
  }

}
